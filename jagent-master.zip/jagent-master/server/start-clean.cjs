// 以"干净"环境启动桥接服务：剥离 WorkBuddy 沙箱注入的 CODEBUDDY_* 环境变量，
// 让 SDK CLI 使用自己的默认配置目录（~/.codebuddy）与公网登录态。
const { spawn } = require("child_process");
const path = require("path");

const env = {};
for (const [k, v] of Object.entries(process.env)) {
  if (/^CODEBUDDY_/i.test(k)) continue;        // 剥离所有 CODEBUDDY_* 注入变量
  if (/^BASH_FUNC_/i.test(k)) continue;        // 剥离沙箱 shell 函数
  env[k] = v;
}
// 显式保证公网环境
env.CODEBUDDY_INTERNET_ENVIRONMENT = "internal";

const child = spawn(process.execPath, [path.join(__dirname, "index.js")], {
  cwd: __dirname,
  env,
  stdio: "inherit",
  windowsHide: true,
});

child.on("exit", (code) => process.exit(code ?? 0));
