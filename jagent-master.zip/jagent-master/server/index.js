/**
 * CodeBuddy Agent SDK 桥接服务
 * 为 JavaFX 客户端提供 HTTP + SSE 接口，桥接 @tencent-ai/agent-sdk
 *
 * 接口：
 *   GET  /api/health              健康检查
 *   GET  /api/check-login         检查 CodeBuddy 登录状态
 *   GET  /api/models              获取可用模型列表
 *   POST /api/chat                发送消息（SSE 流式返回）
 *   POST /api/permission-response 工具权限审批结果
 *   POST /api/config              保存 API Key 等配置（写入 .env）
 *   POST /api/abort               中断当前会话的流式响应
 */
import express from "express";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { fileURLToPath } from "url";
import { query, unstable_v2_createSession, unstable_v2_authenticate } from "@tencent-ai/agent-sdk";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3210;

app.use(express.json({ limit: "10mb" }));

// 加载 .env（简易解析，避免额外依赖）
function loadEnvFile() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, "utf-8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m || line.trim().startsWith("#")) continue;
    const key = m[1];
    let val = m[2];
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = val;
  }
}
loadEnvFile();

const PROJECT_ROOT = path.resolve(__dirname, "..");
const DEFAULT_CWD = process.env.AGENT_CWD || PROJECT_ROOT;
const AUTH_ENV = process.env.CODEBUDDY_ENV || "external"; // external | internal | ioa | cloudhosted
const defaultModel = process.env.DEFAULT_MODEL || "claude-sonnet-4";

// ============ 内存状态 ============
let cachedModels = [];
let sdkSessionIds = new Map();     // conversationId -> sdk session_id
const pendingPermissions = new Map(); // requestId -> { resolve, input }
const PERMISSION_TIMEOUT = 5 * 60 * 1000;

// 当前活跃的 SSE 响应（conversationId -> res），用于中断
const activeStreams = new Map();

const log = (...args) => console.log("[Bridge]", ...args);

// ============ 健康检查 ============
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "codebuddy-agent-bridge", timestamp: new Date().toISOString() });
});

// ============ 登录状态 ============
function withTimeout(promise, ms, fallback) {
  return Promise.race([
    promise,
    new Promise((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);
}

app.get("/api/check-login", async (req, res) => {
  const response = {
    isLoggedIn: false,
    method: "none",
    envConfigured: false,
    cliConfigured: false,
    envVars: {},
  };

  const apiKey = process.env.CODEBUDDY_API_KEY;
  const authToken = process.env.CODEBUDDY_AUTH_TOKEN;
  const internetEnv = process.env.CODEBUDDY_INTERNET_ENVIRONMENT;
  const baseUrl = process.env.CODEBUDDY_BASE_URL;

  if (apiKey || authToken) {
    response.envConfigured = true;
    if (apiKey) {
      response.envVars.apiKey = apiKey.length > 12 ? apiKey.slice(0, 8) + "****" + apiKey.slice(-4) : "****";
    }
    if (authToken) {
      response.envVars.authToken = authToken.length > 12 ? authToken.slice(0, 8) + "****" + authToken.slice(-4) : "****";
    }
    if (internetEnv) response.envVars.internetEnv = internetEnv;
    if (baseUrl) response.envVars.baseUrl = baseUrl;
  }

  try {
    let needsLogin = false;
    // 20 秒内未完成即视为未登录（未登录时 authenticate 会一直等待用户完成浏览器登录）
    const result = await withTimeout(
        unstable_v2_authenticate({
          environment: AUTH_ENV,
          onAuthUrl: async (authState) => {
            needsLogin = true;
            response.error = "未登录，请点击登录完成 CodeBuddy 授权";
          },
        }),
        20000,
        null
    );

    if (!needsLogin && result?.userinfo) {
      response.isLoggedIn = true;
      response.cliConfigured = true;
      response.method = response.envConfigured ? "env" : "cli";
      response.user = result.userinfo.userName;
      log("已登录用户:", result.userinfo.userName);
    } else if (!needsLogin && result === null && !response.error) {
      // 超时且未触发登录回调 —— 状态未知，保守认为已配置（避免误报）
      response.isLoggedIn = response.envConfigured;
      response.cliConfigured = response.envConfigured;
      response.method = response.envConfigured ? "env" : "none";
    } else if (!needsLogin) {
      response.isLoggedIn = true;
      response.cliConfigured = true;
      response.method = response.envConfigured ? "env" : "cli";
    }
  } catch (error) {
    log("认证检查失败:", error?.message || String(error));
    if (response.envConfigured) {
      response.isLoggedIn = true;
      response.method = "env";
    } else {
      response.isLoggedIn = false;
      response.error = "未登录，请点击登录完成 CodeBuddy 授权";
    }
  }

  res.json(response);
});

// ============ 登录流程：返回浏览器登录 URL ============
let loginFlow = null; // { promise, authUrl }

app.post("/api/login", async (req, res) => {
  // 已有进行中的流程且拿到 URL → 直接复用
  if (loginFlow?.authUrl) {
    return res.json({ authUrl: loginFlow.authUrl, message: "请继续在浏览器中完成登录" });
  }
  // 先快速确认是否已登录
  try {
    let needsLogin = false;
    const result = await withTimeout(
        unstable_v2_authenticate({
          environment: AUTH_ENV,
          onAuthUrl: async (s) => { needsLogin = true; },
        }),
        15000,
        null
    );
    if (!needsLogin && result?.userinfo) {
      return res.json({ alreadyLoggedIn: true, user: result.userinfo.userName });
    }
  } catch (e) { /* 继续登录流程 */ }

  // 启动新的登录流程，等待 authUrl（最多 20 秒）
  loginFlow = { promise: null, authUrl: null };
  try {
    loginFlow.promise = unstable_v2_authenticate({
      environment: AUTH_ENV,
      onAuthUrl: async (authState) => {
        // 重写为中文域名（www.codebuddy.cn），浏览器登录页面为中文
        loginFlow.authUrl = authState.authUrl.replace(
            /^https?:\/\/www\.codebuddy\.cn\//,
            "https://www.codebuddy.cn/"
        );
        log("登录 URL:", loginFlow.authUrl);
      },
    });
    const deadline = Date.now() + 20000;
    while (!loginFlow.authUrl && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 300));
      // 流程提前结束（可能已登录）
      try {
        const r = await Promise.race([loginFlow.promise, new Promise((_, rej) => setTimeout(rej, 50))]);
        if (r?.userinfo) {
          loginFlow = null;
          return res.json({ alreadyLoggedIn: true, user: r.userinfo.userName });
        }
      } catch (e) { /* 还在进行 */ }
    }
    if (loginFlow.authUrl) {
      res.json({ authUrl: loginFlow.authUrl });
    } else {
      loginFlow = null;
      res.status(503).json({ error: "获取登录链接超时，请稍后重试" });
    }
  } catch (error) {
    loginFlow = null;
    res.status(500).json({ error: error?.message || "登录流程启动失败" });
  }
});

// ============ 保存配置 ============
app.post("/api/config", (req, res) => {
  const { apiKey, authToken, internetEnv, baseUrl } = req.body || {};
  if (!apiKey && !authToken && !internetEnv && !baseUrl) {
    return res.status(400).json({ error: "没有需要保存的配置项" });
  }

  const lines = [];
  if (apiKey !== undefined) lines.push(`CODEBUDDY_API_KEY=${apiKey || ""}`);
  if (authToken !== undefined) lines.push(`CODEBUDDY_AUTH_TOKEN=${authToken || ""}`);
  if (internetEnv !== undefined) lines.push(`CODEBUDDY_INTERNET_ENVIRONMENT=${internetEnv || ""}`);
  if (baseUrl !== undefined) lines.push(`CODEBUDDY_BASE_URL=${baseUrl || ""}`);

  // 合并已有 .env（保留其他键）
  const envPath = path.join(__dirname, ".env");
  const existing = fs.existsSync(envPath) ? fs.readFileSync(envPath, "utf-8") : "";
  const keepKeys = new Set(lines.map((l) => l.split("=")[0]));
  const kept = existing
      .split(/\r?\n/)
      .filter((l) => {
        const m = l.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/);
        return m && !keepKeys.has(m[1]) && l.trim() !== "";
      });
  fs.writeFileSync(envPath, [...kept, ...lines].join("\n") + "\n", "utf-8");

  // 立即生效
  if (apiKey) process.env.CODEBUDDY_API_KEY = apiKey;
  if (authToken) process.env.CODEBUDDY_AUTH_TOKEN = authToken;
  if (internetEnv) process.env.CODEBUDDY_INTERNET_ENVIRONMENT = internetEnv;
  if (baseUrl) process.env.CODEBUDDY_BASE_URL = baseUrl;
  cachedModels = [];

  res.json({ success: true, message: "配置已保存到 server/.env（已生效）" });
});

// ============ 模型列表 ============
app.get("/api/models", async (req, res) => {
  try {
    if (cachedModels.length === 0) {
      const session = await unstable_v2_createSession({ cwd: DEFAULT_CWD, environment: AUTH_ENV });
      const models = await session.getAvailableModels();
      if (Array.isArray(models)) cachedModels = models;
      log("获取到模型数:", cachedModels.length);
    }
    res.json({
      models: cachedModels.length > 0 ? cachedModels : [
        { modelId: defaultModel, name: "Claude Sonnet 4" },
      ],
      defaultModel,
    });
  } catch (error) {
    log("获取模型失败:", error?.message);
    res.json({
      models: [
        { modelId: "claude-sonnet-4", name: "Claude Sonnet 4" },
        { modelId: "claude-opus-4", name: "Claude Opus 4" },
      ],
      defaultModel,
      error: error?.message || String(error),
    });
  }
});

// ============ 权限审批 ============
app.post("/api/permission-response", (req, res) => {
  const { requestId, behavior, message } = req.body || {};
  log("权限响应:", requestId, behavior);
  const pending = pendingPermissions.get(requestId);
  if (!pending) {
    return res.status(404).json({ error: "权限请求不存在或已超时" });
  }
  pendingPermissions.delete(requestId);
  if (behavior === "allow") {
    pending.resolve({ behavior: "allow", updatedInput: pending.input });
  } else {
    pending.resolve({ behavior: "deny", message: message || "用户拒绝了此操作" });
  }
  res.json({ success: true });
});

// ============ 中断流式响应 ============
app.post("/api/abort", (req, res) => {
  const { conversationId } = req.body || {};
  if (conversationId && activeStreams.has(conversationId)) {
    try {
      const sse = activeStreams.get(conversationId);
      sse.write(`data: ${JSON.stringify({ type: "aborted" })}\n\n`);
      sse.end();
    } catch (e) { /* ignore */ }
    activeStreams.delete(conversationId);
  }
  res.json({ success: true });
});

// ============ 聊天（SSE） ============
app.post("/api/chat", async (req, res) => {
  const {
    conversationId,
    message,
    model,
    systemPrompt,
    systemPromptAppend,
    cwd,
    permissionMode,
    resume,
  } = req.body || {};

  if (!message) {
    return res.status(400).json({ error: "消息不能为空" });
  }

  const convId = conversationId || crypto.randomUUID();
  let workingDir = cwd || DEFAULT_CWD;
  if (!fs.existsSync(workingDir)) {
    log("工作目录不存在，回退到默认:", workingDir);
    workingDir = DEFAULT_CWD;
  }
  const selectedModel = model || defaultModel;
  const resumeId = resume || sdkSessionIds.get(convId) || null;

  log(`chat conv=${convId.slice(0, 8)} model=${selectedModel} resume=${resumeId ? "yes" : "no"} cwd=${workingDir}`);

  // SSE 头
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const send = (obj) => {
    try { res.write(`data: ${JSON.stringify(obj)}\n\n`); } catch (e) { /* ignore */ }
  };

  activeStreams.set(convId, res);
  req.on("close", () => activeStreams.delete(convId));

  let closed = false;
  res.on("close", () => { closed = true; activeStreams.delete(convId); });

  const defaultSystemPrompt =
      "你是 CodeBuddy Agent，一个专业友好的 AI 助手。请用简洁清晰的中文回答问题。";

  try {
    const canUseTool = async (toolName, input) => {
      if (permissionMode === "bypassPermissions") {
        return { behavior: "allow", updatedInput: input };
      }
      const requestId = crypto.randomUUID();
      send({
        type: "permission_request",
        requestId,
        toolName,
        input,
        conversationId: convId,
      });
      return new Promise((resolve) => {
        pendingPermissions.set(requestId, {
          resolve,
          input,
          toolName,
        });
        setTimeout(() => {
          if (pendingPermissions.has(requestId)) {
            pendingPermissions.delete(requestId);
            send({ type: "permission_denied", requestId, reason: "timeout" });
            resolve({ behavior: "deny", message: "权限请求超时（5 分钟）" });
          }
        }, PERMISSION_TIMEOUT);
      });
    };

    send({ type: "init", conversationId: convId, model: selectedModel });

    const stream = query({
      prompt: message,
      options: {
        environment: AUTH_ENV,
        cwd: workingDir,
        model: selectedModel,
        maxTurns: 10,
        systemPrompt: systemPromptAppend ? { append: systemPromptAppend } : (systemPrompt || defaultSystemPrompt),
        permissionMode: permissionMode || "default",
        canUseTool,
        includePartialMessages: true,
        ...(resumeId ? { resume: resumeId } : {}),
      },
    });

    let currentToolId = null;
    let streamedText = false;
    let streamedThinking = false;
    const blockToolIds = new Map(); // content_block index -> tool_use id

    for await (const msg of stream) {
      if (closed) break;

      if (msg.type === "system" && msg.subtype === "init") {
        if (msg.session_id) {
          sdkSessionIds.set(convId, msg.session_id);
          send({ type: "session", sdkSessionId: msg.session_id });
        }

      } else if (msg.type === "stream_event") {
        // 流式：逐 token 下发文本 / 思考 / 工具入参增量
        const ev = msg.event;
        if (!ev) continue;
        if (ev.type === "content_block_start") {
          const cb = ev.content_block;
          if (cb && cb.type === "tool_use") {
            blockToolIds.set(ev.index, cb.id || crypto.randomUUID());
          }
        } else if (ev.type === "content_block_delta" && ev.delta) {
          if (ev.delta.type === "text_delta") {
            streamedText = true;
            send({ type: "text", content: ev.delta.text });
          } else if (ev.delta.type === "thinking_delta") {
            streamedThinking = true;
            send({ type: "thinking", content: ev.delta.thinking });
          } else if (ev.delta.type === "input_json_delta") {
            send({
              type: "tool_input_delta",
              toolId: blockToolIds.get(ev.index) || currentToolId,
              partialJson: ev.delta.partial_json,
            });
          }
        }

      } else if (msg.type === "assistant") {
        // 完整消息：文本若已通过 stream_event 流式下发则跳过，仅兜底旧 CLI 或下发工具调用
        const content = msg.message?.content;
        if (typeof content === "string") {
          if (!streamedText) send({ type: "text", content });
        } else if (Array.isArray(content)) {
          for (const block of content) {
            if (block.type === "text") {
              if (!streamedText) send({ type: "text", content: block.text });
            } else if (block.type === "thinking") {
              // 完整消息里的思考块：流式已下发则跳过，仅兜底旧 CLI / 非流式场景
              if (!streamedThinking) send({ type: "thinking", content: block.thinking });
            } else if (block.type === "tool_use") {
              currentToolId = block.id || crypto.randomUUID();
              send({
                type: "tool",
                id: currentToolId,
                name: block.name,
                input: block.input || {},
                status: "running",
              });
            }
          }
        }

      } else if (msg.type === "user") {
        // 工具执行结果以 user 消息返回，content 为 tool_result 内容块数组
        const userContent = msg.message?.content;
        if (Array.isArray(userContent)) {
          for (const block of userContent) {
            if (block.type === "tool_result") {
              const toolId = block.tool_use_id || currentToolId;
              const isError = block.is_error || false;
              let content = block.content;
              if (typeof content !== "string") content = JSON.stringify(content);
              send({ type: "tool_result", toolId, content, isError });
              currentToolId = null;
            }
          }
        }

      } else if (msg.type === "result") {
        send({
          type: "done",
          duration: msg.duration,
          cost: msg.cost,
          sdkSessionId: sdkSessionIds.get(convId) || null,
        });
      }
    }

    send({
      type: "done",
      sdkSessionId: sdkSessionIds.get(convId) || null,
    });
  } catch (error) {
    const message = error?.message || "处理请求时发生错误";
    log("chat 错误:", message);
    if (/Authentication required|未登录|not logged in|请.*登录/i.test(message)) {
      send({ type: "error", code: "AUTH_REQUIRED", message: "CodeBuddy 未登录，无法使用工具与对话。请在设置中完成登录。" });
    } else {
      send({ type: "error", message });
    }
  } finally {
    activeStreams.delete(convId);
    try { res.end(); } catch (e) { /* ignore */ }
  }
});

app.listen(PORT, () => {
  console.log("");
  console.log("  CodeBuddy Agent Bridge (for JavaFX Client)");
  console.log(`  ➜ http://localhost:${PORT}`);
  console.log(`  ➜ Agent 工作目录: ${DEFAULT_CWD}`);
  console.log("");
});
