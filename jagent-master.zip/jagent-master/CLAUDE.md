# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Overview

A CodeBuddy Agent desktop client: a **JavaFX 21 client** (`client/`) talking over **HTTP + SSE** to a **Node.js Express bridge** (`server/`) that wraps `@tencent-ai/agent-sdk`. No database — conversations/settings/schedules persist as JSON in `data/`. Builds with Maven (`client/pom.xml`) or plain `javac` + jars; no `module-info` (classpath mode).

```
JavaFX client (ChatController)  ⇄ HTTP/SSE  ⇄  server/index.js (Express)  ⇄  @tencent-ai/agent-sdk  ⇄  CodeBuddy CLI
```

## Commands

Windows one-click (scripts are `.bat`; the repo targets Windows):
```bat
scripts\start-all.bat     # install deps + download libs + compile + run server + run client
scripts\start-server.bat  # server only (port 3210)
scripts\start-client.bat  # compile client, auto-spawn server if needed
```

Server only:
```bash
cd server && npm install && npm run dev   # node index.js, http://localhost:3210
```

Maven (cross-platform build & run — see `client/pom.xml`; OS/arch profiles pick the right JavaFX classifier):
```bash
cd client
mvn clean package                            # compile + package (win/mac/linux)
mvn javafx:run                               # launch the client (auto-spawns the bridge server)
mvn javafx:run -Djavafx.args="--screenshot"  # screenshot self-check
```
Note: `mvn javafx:run` runs with `client/` as the working directory, so it persists data under
`client/data/` (the `.bat`/`javac` flows use repo-root `data/`).

Compile client (macOS — target only mac-aarch64 jars, `client/lib/*` also contains `-win` jars with duplicate classes):
```bash
javac -encoding UTF-8 \
  -cp "client/lib/gson-2.11.0.jar:client/lib/log4j-api-2.23.1.jar:client/lib/log4j-core-2.23.1.jar:client/lib/javafx-base-21.0.5-mac-aarch64.jar:client/lib/javafx-controls-21.0.5-mac-aarch64.jar:client/lib/javafx-graphics-21.0.5-mac-aarch64.jar" \
  -d client/out $(find client/src/main/java -name '*.java')
cp client/src/main/resources/css/app.css client/out/css/app.css
cp client/src/main/resources/log4j2.xml client/out/log4j2.xml
```

Run client:
```bash
java --module-path client/lib --add-modules javafx.controls \
  -cp "client/out:client/lib/gson-2.11.0.jar:client/lib/log4j-api-2.23.1.jar:client/lib/log4j-core-2.23.1.jar" com.jagent.Main
```

Screenshot self-check (writes `data/screenshot.png` then exits):
```bash
java --module-path client/lib --add-modules javafx.controls \
  -cp "client/out:client/lib/gson-2.11.0.jar:client/lib/log4j-api-2.23.1.jar:client/lib/log4j-core-2.23.1.jar" com.jagent.Main --screenshot
```

There is no test suite or linter. `Main` (not `App`) is the launcher so JavaFX runs in classpath mode.

## Architecture

### Client entry & orchestration
- `client/.../Main.java` → `App.java` (the `Application`, builds `Scene`, adds `/css/app.css`, handles `--screenshot`).
- `ChatController.java` is a thin coordinator: builds views, constructs services, and binds service events to views. UI views live in `client/.../ui/` (`SidebarView`, `ChatAreaView`, `ComposerView`, `MessageNode`, `Dialogs`, `Icons`, `MarkdownText`, `ActivityBarView`, `Theme`).

### Service layer (`service/` package — pure Java, no `javafx.*` imports)
- `SessionService` — conversation lifecycle (create/select/delete/persist) + change callback.
- `ChatService` — send/stop + single-stream state machine (`textBuffer`, debounced flush); emits a `Listener` event stream for UI to render.
- `ScheduleService` — cron tasks + per-task dedicated conversation binding; fires via `ChatService`.
- `SettingsService` — settings load/save (serverUrl/cwd/permissionMode/model/theme).
- `ConnectivityService` — server auto-start/health, login, models; emits `onStatus`/`onModels`/`onLoginChecked`.
- Services depend only on `model`/`store`/`api`/`schedule`; keep them JavaFX-free so future plugins/scripts can call them headlessly. `ChatController` is the composition root (wires one shared `AgentBridge` into both `ChatService` and `ConnectivityService`).

### Server auto-start
- `ChatController.spawnServer()` locates `server/index.js` (walks up from `user.dir`) and spawns `node`, streaming stdout to `data/bridge.log`. So starting the client is normally enough; the server is a child process.

### HTTP + SSE contract
- `AgentBridge.chat()` is a blocking SSE consumer (`data:` lines) mapped to `AgentBridge.ChatListener` callbacks. Event types: `init`, `session`, `text`, `tool`, `tool_result`, `permission_request`, `permission_denied`, `done`, `error` (see README table).
- REST: `/api/health`, `/api/check-login`, `/api/login`, `/api/models`, `/api/config`, `/api/chat`, `/api/permission-response`, `/api/abort`.

### Streaming & single-conversation constraint
- `ChatService` holds **one** active stream at a time (`streaming`, `streamingConv`, `activeMsg`). Incoming `text` chunks accumulate in a `textBuffer`, flushed by a debounced 90ms scheduler; the UI layer re-renders `MessageNode` on the `onTextUpdated` event.
- Because of the single-stream state, concurrent chats are not supported — scheduled tasks skip firing while `streaming` is true.

### Context resume
- The server keeps a `conversationId → sdk session_id` map (`server/index.js`), emits it as `session`, and accepts `resume` on the next `/api/chat`. The client stores it on `Conversation.sdkSessionId`.

### Persistence (`store/Store.java`)
- Gson-pretty JSON files under `data/`: `conversations.json`, `settings.json`, `schedules.json`. `Store.loadSchedules/saveSchedules` manage scheduled tasks.

### Cron scheduling (`schedule/` package, recently added)
- `CronExpression.java`: parses standard 5-field cron (分 时 日 月 周), computes `next(after)` by minute iteration (366-day cap), and a best-effort Chinese `describe()`.
- `ScheduleRunner.java`: client-side scheduler; one `ScheduledFuture` per enabled task, re-scheduling itself after each fire. Used by `ScheduleService` (loaded at startup, synced on save).
- Each `ScheduledTask` is bound to a **dedicated conversation** (`conversationId`). On fire, `executeScheduled` reuses that conversation (`select(conv)` + `send(content)`); if the conversation was deleted it is recreated and re-bound. The task editor is `Dialogs.showSchedule` (per-field cron builder + presets + live preview).

### Permission flow
- When the SDK requests a tool, the server sends `permission_request`, the client shows `Dialogs.showPermission`, and responds via `/api/permission-response`. Server times out after 5 minutes. Permission mode is a client setting (`default`/`acceptEdits`/`plan`/`bypassPermissions`).

## Conventions & gotchas

- Java 21 virtual threads (`Thread.ofVirtual()`) are used throughout for background work; UI mutations must go through `Platform.runLater`.
- Icons are inline SVG path strings rendered as `SVGPath` in `ui/Icons.java`; add new glyphs there (24x24 viewBox).
- Styling is `client/src/main/resources/css/app.css`, driven by looked-up color variables (`.root`) with `.theme-dark/.theme-blue/.theme-green/.theme-purple` variants; theme switching toggles a `theme-*` style class via `ui/Theme.apply(...)`.
- `client/out/` is compiled output (flat `com/codebuddy/...`); the CSS resource must be copied alongside it after edits.
- Repo scripts/docs assume Windows paths (`C:\Program Files\...\jbr`, `.bat`); the dev machine may be macOS, so use the macOS javac/java commands above.


1、开发的过程中支持win/mac/linux多个操作系统
2、将ui和service 业务逻辑区分开，不耦合，业务含义明确
3、编码时，尽量支持可扩展，可维护，高内聚 
4、编码时增加注释