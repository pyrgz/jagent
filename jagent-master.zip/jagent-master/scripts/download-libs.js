#!/usr/bin/env node
// 下载 JavaFX 21 (Windows x64) + Gson 2.11.0 到 client/lib
const { createWriteStream, existsSync, mkdirSync, renameSync } = require("fs");
const { join } = require("path");
const https = require("https");
const http = require("http");

const libDir = join(__dirname, "..", "client", "lib");
if (!existsSync(libDir)) mkdirSync(libDir, { recursive: true });

const artifacts = [
  // Maven Central 直接给出完整分类器的 jar（含 native win 二进制）
  { url: "https://repo1.maven.org/maven2/org/openjfx/javafx-base/21.0.5/javafx-base-21.0.5-win.jar", name: "javafx-base-21.0.5-win.jar" },
  { url: "https://repo1.maven.org/maven2/org/openjfx/javafx-graphics/21.0.5/javafx-graphics-21.0.5-win.jar", name: "javafx-graphics-21.0.5-win.jar" },
  { url: "https://repo1.maven.org/maven2/org/openjfx/javafx-controls/21.0.5/javafx-controls-21.0.5-win.jar", name: "javafx-controls-21.0.5-win.jar" },
  { url: "https://repo1.maven.org/maven2/com/google/code/gson/gson/2.11.0/gson-2.11.0.jar", name: "gson-2.11.0.jar" },
  { url: "https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-api/2.23.1/log4j-api-2.23.1.jar", name: "log4j-api-2.23.1.jar" },
  { url: "https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-core/2.23.1/log4j-core-2.23.1.jar", name: "log4j-core-2.23.1.jar" },
  // langchain4j（OpenAI 兼容直连对话 + 文档问答）及其传递依赖
  { url: "https://repo1.maven.org/maven2/dev/langchain4j/langchain4j/1.20.0/langchain4j-1.20.0.jar", name: "langchain4j-1.20.0.jar" },
  { url: "https://repo1.maven.org/maven2/dev/langchain4j/langchain4j-core/1.20.0/langchain4j-core-1.20.0.jar", name: "langchain4j-core-1.20.0.jar" },
  { url: "https://repo1.maven.org/maven2/dev/langchain4j/langchain4j-open-ai/1.20.0/langchain4j-open-ai-1.20.0.jar", name: "langchain4j-open-ai-1.20.0.jar" },
  { url: "https://repo1.maven.org/maven2/dev/langchain4j/langchain4j-http-client/1.20.0/langchain4j-http-client-1.20.0.jar", name: "langchain4j-http-client-1.20.0.jar" },
  { url: "https://repo1.maven.org/maven2/dev/langchain4j/langchain4j-http-client-jdk/1.20.0/langchain4j-http-client-jdk-1.20.0.jar", name: "langchain4j-http-client-jdk-1.20.0.jar" },
  { url: "https://repo1.maven.org/maven2/dev/langchain4j/langchain4j-reactive-streaming/1.20.0-beta30/langchain4j-reactive-streaming-1.20.0-beta30.jar", name: "langchain4j-reactive-streaming-1.20.0-beta30.jar" },
  { url: "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-annotations/2.22/jackson-annotations-2.22.jar", name: "jackson-annotations-2.22.jar" },
  { url: "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-core/2.22.1/jackson-core-2.22.1.jar", name: "jackson-core-2.22.1.jar" },
  { url: "https://repo1.maven.org/maven2/com/fasterxml/jackson/core/jackson-databind/2.22.1/jackson-databind-2.22.1.jar", name: "jackson-databind-2.22.1.jar" },
  { url: "https://repo1.maven.org/maven2/com/knuddels/jtokkit/1.1.0/jtokkit-1.1.0.jar", name: "jtokkit-1.1.0.jar" },
  { url: "https://repo1.maven.org/maven2/io/smallrye/reactive/mutiny-zero/1.3.1/mutiny-zero-1.3.1.jar", name: "mutiny-zero-1.3.1.jar" },
  { url: "https://repo1.maven.org/maven2/org/apache/opennlp/opennlp-tools/2.5.11/opennlp-tools-2.5.11.jar", name: "opennlp-tools-2.5.11.jar" },
  { url: "https://repo1.maven.org/maven2/org/slf4j/slf4j-api/2.0.18/slf4j-api-2.0.18.jar", name: "slf4j-api-2.0.18.jar" },
  { url: "https://repo1.maven.org/maven2/org/apache/logging/log4j/log4j-slf4j2-impl/2.23.1/log4j-slf4j2-impl-2.23.1.jar", name: "log4j-slf4j2-impl-2.23.1.jar" },
  { url: "https://repo1.maven.org/maven2/com/google/errorprone/error_prone_annotations/2.27.0/error_prone_annotations-2.27.0.jar", name: "error_prone_annotations-2.27.0.jar" },
  { url: "https://repo1.maven.org/maven2/org/jspecify/jspecify/1.0.1/jspecify-1.0.1.jar", name: "jspecify-1.0.1.jar" },
];

function download(url) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith("https") ? https : http;
    const req = mod.get(url, { headers: { "User-Agent": "codebuddy-client-installer" } }, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        return resolve(download(res.headers.location));
      }
      if (res.statusCode !== 200) {
        return reject(new Error("HTTP " + res.statusCode + " for " + url));
      }
      const data = [];
      res.on("data", (c) => data.push(c));
      res.on("end", () => resolve(Buffer.concat(data)));
    });
    req.on("error", reject);
    req.setTimeout(90000, () => req.destroy(new Error("timeout")));
  });
}

(async () => {
  for (const a of artifacts) {
    const dest = join(libDir, a.name);
    if (existsSync(dest)) {
      console.log("[libs] 已存在:", a.name);
      continue;
    }
    process.stdout.write("[libs] 下载 " + a.name + " ... ");
    try {
      const buf = await download(a.url);
      if (buf.length < 1024) {
        console.log("失败（文件太小）");
        process.exit(1);
      }
      const tmp = dest + ".tmp";
      const ws = createWriteStream(tmp);
      ws.write(buf);
      ws.end();
      await new Promise((r) => ws.on("close", r));
      renameSync(tmp, dest);
      console.log("完成 (" + (buf.length / 1024).toFixed(1) + " KB)");
    } catch (e) {
      console.log("失败:", e.message);
      process.exit(1);
    }
  }
  console.log("[libs] 所有依赖已就绪");
})();