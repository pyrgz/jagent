#!/usr/bin/env python3
"""生成 jagent 应用图标（纯标准库，无第三方依赖）。

用法：
    python3 scripts/gen_icon.py

输出：
    client/src/main/resources/icon.png   （1024x1024，主图标）
    client/src/main/resources/icon.ico   （多尺寸 Windows 图标，PNG 压缩条目）
"""
import math
import os
import struct
import zlib

# ---------------- 设计常量（1024 设计空间） ----------------
SS = 1024.0

# 背景 squircle（圆角矩形，macOS 风格圆角）
BG_CX = BG_CY = 512.0
BG_HALF = 512.0
BG_R = 232.0

# 品牌渐变（取自主题 -app-accent）
TOP = (76, 141, 255)      # #4C8DFF
BOTTOM = (0, 82, 217)     # #0052D9

# 字形：小写「j」（白色）+ 圆点
STROKE = 124.0            # 笔画全宽
DOT_C = (620.0, 225.0)
DOT_R = 64.0
HOOK_PTS = [              # 竖干 + 向左回勾的中心线（干净的小写 j）
    (620.0, 360.0),
    (620.0, 620.0),
    (620.0, 680.0),
    (612.0, 730.0),
    (590.0, 765.0),
    (552.0, 788.0),
    (505.0, 796.0),
    (458.0, 790.0),
    (420.0, 772.0),
]

# ---------------- SDF ----------------
def sd_roundrect(px, py, cx, cy, halfw, halfh, r):
    qx = abs(px - cx) - (halfw - r)
    qy = abs(py - cy) - (halfh - r)
    ax = qx if qx > 0.0 else 0.0
    ay = qy if qy > 0.0 else 0.0
    inner = qx if qx > qy else qy
    if inner > 0.0:
        inner = 0.0
    return math.hypot(ax, ay) + inner - r


def _seg_d(px, py, ax, ay, bx, by):
    pax = px - ax
    pay = py - ay
    bax = bx - ax
    bay = by - ay
    denom = bax * bax + bay * bay
    h = ((pax * bax + pay * bay) / denom) if denom > 0.0 else 0.0
    h = 0.0 if h < 0.0 else (1.0 if h > 1.0 else h)
    return math.hypot(pax - bax * h, pay - bay * h)


def clamp(v):
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)


# ---------------- 渲染 ----------------
def render(size):
    k = size / SS
    half_stroke = STROKE * k / 2.0
    dot_cx, dot_cy = DOT_C[0] * k, DOT_C[1] * k
    dot_r = DOT_R * k

    segs = []
    for i in range(len(HOOK_PTS) - 1):
        a = HOOK_PTS[i]
        b = HOOK_PTS[i + 1]
        segs.append((a[0] * k, a[1] * k, b[0] * k, b[1] * k))

    # 字形包围盒（用于跳过无关像素，加速）
    minx = min(p[0] for p in HOOK_PTS) * k - half_stroke - 2.0
    maxx = max(p[0] for p in HOOK_PTS) * k + half_stroke + 2.0
    miny = (DOT_C[1] * k - dot_r) - half_stroke - 2.0
    maxy = max(p[1] for p in HOOK_PTS) * k + half_stroke + 2.0

    halfw = BG_HALF * k
    halfh = BG_HALF * k
    r = BG_R * k
    cx = BG_CX * k
    cy = BG_CY * k

    buf = bytearray()
    for y in range(size):
        if y % 128 == 0:
            print(f"  {size}px … {int(100 * y / size)}%", flush=True)
        row = bytearray()
        ty = y / size
        for x in range(size):
            # 背景 SDF
            d_bg = sd_roundrect(x + 0.5, y + 0.5, cx, cy, halfw, halfh, r)
            bg_a = clamp(0.5 - d_bg)
            if bg_a <= 0.0:
                row += b"\x00\x00\x00\x00"
                continue
            # 渐变颜色
            cr = TOP[0] + (BOTTOM[0] - TOP[0]) * ty
            cg = TOP[1] + (BOTTOM[1] - TOP[1]) * ty
            cb = TOP[2] + (BOTTOM[2] - TOP[2]) * ty
            # 左上角柔光高光
            hx = x - 210.0 * k
            hy = y - 190.0 * k
            hl = 0.10 * math.exp(-(hx * hx + hy * hy) / (2.0 * (320.0 * k) ** 2))
            cr += (255 - cr) * hl
            cg += (255 - cg) * hl
            cb += (255 - cb) * hl

            # 字形 SDF（仅包围盒内计算）
            ga = 0.0
            if minx <= x <= maxx and miny <= y <= maxy:
                d = math.hypot(x + 0.5 - dot_cx, y + 0.5 - dot_cy) - dot_r
                for (ax, ay, bx, by) in segs:
                    sd = _seg_d(x + 0.5, y + 0.5, ax, ay, bx, by) - half_stroke
                    if sd < d:
                        d = sd
                ga = clamp(0.5 - d) * bg_a

            if ga > 0.0:
                fr = 255 * ga
                cr = cr * (1.0 - ga) + fr
                cg = cg * (1.0 - ga) + fr
                cb = cb * (1.0 - ga) + fr

            row += bytes((int(cr + 0.5), int(cg + 0.5), int(cb + 0.5), int(bg_a * 255 + 0.5)))
        buf += row
    return bytes(buf)


# ---------------- PNG 编码 ----------------
def _chunk(tag, data):
    c = struct.pack(">I", len(data)) + tag + data
    c += struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    return c


def write_png(path, size, rgba):
    sig = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)  # 8-bit RGBA
    raw = bytearray()
    stride = size * 4
    for y in range(size):
        raw += b"\x00" + rgba[y * stride:(y + 1) * stride]
    idat = zlib.compress(bytes(raw), 9)
    with open(path, "wb") as f:
        f.write(sig + _chunk(b"IHDR", ihdr) + _chunk(b"IDAT", idat) + _chunk(b"IEND", b""))


# ---------------- ICO 编码（PNG 压缩条目） ----------------
def write_ico(path, images):
    # images: list of (size, png_bytes)
    count = len(images)
    header = struct.pack("<HHH", 0, 1, count)
    entries = b""
    blobs = b""
    offset = 6 + 16 * count
    for size, png in images:
        dim = 0 if size >= 256 else size
        entries += struct.pack("<BBBBHHII", dim, dim, 0, 0, 1, 32, len(png), offset)
        blobs += png
        offset += len(png)
    with open(path, "wb") as f:
        f.write(header + entries + blobs)


def main():
    out_dir = os.path.join(os.path.dirname(__file__), "..", "client", "src", "main", "resources")
    out_dir = os.path.abspath(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    print("渲染 1024 主图标 …")
    icon_path = os.path.join(out_dir, "icon.png")
    write_png(icon_path, 1024, render(1024))
    print("已生成:", icon_path)

    print("渲染 ICO 多尺寸 …")
    images = []
    for size in (16, 32, 48, 64, 128, 256):
        buf = render(size)
        # 复用 PNG 编码得到单尺寸 png 字节
        tmp = os.path.join(out_dir, f"__ico_{size}.png")
        write_png(tmp, size, buf)
        with open(tmp, "rb") as f:
            images.append((size, f.read()))
        os.remove(tmp)
    ico_path = os.path.join(out_dir, "icon.ico")
    write_ico(ico_path, images)
    print("已生成:", ico_path)


if __name__ == "__main__":
    main()
