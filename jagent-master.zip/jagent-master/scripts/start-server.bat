@echo off
chcp 65001 >nul
setlocal

rem =====================================================
rem   CodeBuddy Agent SDK 桥接服务启动脚本
rem   端口：3210
rem =====================================================

cd /d "%~dp0\.."

set "PORT=3210"
set "LOG_DIR=data"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

rem 找 node
set "NODE_EXE="
where node >nul 2>&1 && set "NODE_EXE=node"
if not defined NODE_EXE (
  for %%v in ("22.22.2" "20.10.0") do (
    if exist "%USERPROFILE%\.workbuddy\binaries\node\versions\%%~v\node.exe" (
      set "NODE_EXE=%USERPROFILE%\.workbuddy\binaries\node\versions\%%~v\node.exe"
    )
  )
)
if not defined NODE_EXE (
  if exist "D:\Program Files\nodejs\node.exe" set "NODE_EXE=D:\Program Files\nodejs\node.exe"
  if exist "C:\Program Files\nodejs\node.exe" set "NODE_EXE=C:\Program Files\nodejs\node.exe"
)
if not defined NODE_EXE (
  echo [错误] 未找到 Node.js。请先安装 Node.js 18+，或执行 scripts\install-node.bat。
  pause
  exit /b 1
)

rem 检查依赖
if not exist "server\node_modules\@tencent-ai\agent-sdk" (
  echo [信息] 首次启动，正在安装依赖...
  pushd server
  call "%NODE_EXE%" ..\scripts\install-deps.js || (
    popd
    echo [错误] 依赖安装失败
    pause
    exit /b 1
  )
  popd
)

rem 检查端口占用
netstat -ano | findstr ":%PORT%" | findstr LISTENING >nul 2>&1 && (
  echo [信息] 端口 %PORT% 已被占用，先停掉...
  for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":%PORT%" ^| findstr LISTENING') do (
    taskkill /F /PID %%p >nul 2>&1
  )
  timeout /t 2 >nul
)

echo.
echo   CodeBuddy Agent Bridge
echo   端口: %PORT%
echo   Node: %NODE_EXE%
echo   日志: %LOG_DIR%\bridge.log
echo.

cd /d "%~dp0\..\server"
"%NODE_EXE%" index.js