#!/usr/bin/env node
// 安装 CodeBuddy Agent SDK 与 Express（如缺失则安装）
const { existsSync } = require("fs");
const { join } = require("path");

const root = join(__dirname, "..", "server");
const nodeModules = join(root, "node_modules");
const pkg = require(join(root, "package.json"));
const deps = Object.keys(pkg.dependencies || {});

let missing = [];
for (const dep of deps) {
  if (!existsSync(join(nodeModules, dep))) missing.push(dep);
}

if (missing.length === 0) {
  console.log("[deps] 所有依赖已就绪");
  process.exit(0);
}

console.log("[deps] 缺失依赖:", missing.join(", "));
const { spawnSync } = require("child_process");
const npmCmd = process.platform === "win32" ? "npm.cmd" : "npm";
const r = spawnSync(npmCmd, ["install", "--no-audit", "--no-fund"], {
  cwd: root,
  stdio: "inherit",
  shell: process.platform === "win32",
});
if (r.status !== 0) {
  console.error("[deps] npm install 失败");
  process.exit(r.status || 1);
}
console.log("[deps] 安装完成");