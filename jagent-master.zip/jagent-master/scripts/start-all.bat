@echo off
chcp 65001 >nul
title CodeBuddy Agent Client

rem =====================================================
rem   启动全部：先起服务，再起客户端
rem =====================================================

cd /d "%~dp0\.."

rem 先启动服务（独立窗口）
start "CodeBuddy Bridge" cmd /k call scripts\start-server.bat

rem 等服务就绪
echo 等待服务启动...
:wait
netstat -ano | findstr ":3210" | findstr LISTENING >nul 2>&1 && goto :ready
timeout /t 1 >nul
goto :wait

:ready
echo 服务已就绪，启动客户端...
call scripts\start-client.bat