@echo off
chcp 65001 >nul
setlocal

rem =====================================================
rem   CodeBuddy JavaFX 客户端启动脚本
rem   启动 JavaFX 客户端（如果服务未启动会自动拉起）
rem =====================================================

cd /d "%~dp0\.."

rem 找 javac / java
set "JAVA_HOME_GUESS="
if exist "C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2025.2.6.2\jbr" (
  set "JAVA_HOME_GUESS=C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2025.2.6.2\jbr"
)
if not defined JAVA_HOME_GUESS (
  if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\javac.exe" set "JAVA_HOME_GUESS=%JAVA_HOME%"
  )
)
if not defined JAVA_HOME_GUESS (
  where javac >nul 2>&1 && (
    for /f "delims=" %%j in ('where javac') do set "JAVAC_PATH=%%j"
    for %%j in ("%JAVAC_PATH%") do set "JAVA_HOME_GUESS=%%~dpj.."
  )
)
if not defined JAVA_HOME_GUESS (
  echo [错误] 未找到 JDK（需要 javac）。请安装 JDK 17+ 或安装 IntelliJ IDEA。
  pause
  exit /b 1
)

set "JAVAC=%JAVA_HOME_GUESS%\bin\javac.exe"
set "JAVA=%JAVA_HOME_GUESS%\bin\java.exe"
if not exist "%JAVAC%" (
  echo [错误] %JAVAC% 不存在
  pause
  exit /b 1
)

rem 检查依赖（首次运行时需要）
if not exist "client\lib\javafx-controls-21.0.5-win.jar" goto :download
if not exist "client\lib\gson-2.11.0.jar" goto :download
goto :compile

:download
echo [信息] 首次运行，下载 JavaFX 与 Gson 依赖...
node scripts\download-libs.js || (
  echo [错误] 依赖下载失败
  pause
  exit /b 1
)

:compile
rem 比较源码与 class 时间戳，决定是否重新编译
set "NEED_COMPILE=0"
if not exist "client\out\com\codebuddy\agent\Main.class" set "NEED_COMPILE=1"
if "%NEED_COMPILE%"=="0" (
  for /r "client\src" %%f in (*.java) do (
    if %%~tf gtr "client\out\com\codebuddy\agent\Main.class" set "NEED_COMPILE=1"
  )
)
if "%NEED_COMPILE%"=="1" (
  echo [信息] 编译 Java 源码...
  rem 生成源码列表
  del /q build_sources.txt >nul 2>&1
  for /r "client\src" %%f in (*.java) do echo %%~ff >> build_sources.txt
  "%JAVAC%" -encoding UTF-8 -cp "client\lib\*" -d client\out @build_sources.txt || (
    echo [错误] 编译失败
    pause
    exit /b 1
  )
  copy /y client\src\main\resources\css\app.css client\out\css\app.css >nul 2>&1
  if not exist "client\out\css" mkdir client\out\css
  copy /y client\src\main\resources\css\app.css client\out\css\app.css >nul 2>&1
)

rem 启动客户端
echo.
echo   启动 CodeBuddy JavaFX 客户端...
echo   Java: %JAVA_HOME_GUESS%
echo.
"%JAVA%" --module-path "client\lib" --add-modules javafx.controls ^
  -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8 ^
  -cp "client\out;client\lib\gson-2.11.0.jar;client\lib\log4j-api-2.23.1.jar;client\lib\log4j-core-2.23.1.jar;client\lib\log4j-slf4j2-impl-2.23.1.jar;client\lib\slf4j-api-2.0.18.jar;client\lib\langchain4j-1.20.0.jar;client\lib\langchain4j-core-1.20.0.jar;client\lib\langchain4j-open-ai-1.20.0.jar;client\lib\langchain4j-http-client-1.20.0.jar;client\lib\langchain4j-http-client-jdk-1.20.0.jar;client\lib\langchain4j-reactive-streaming-1.20.0-beta30.jar;client\lib\jackson-annotations-2.22.jar;client\lib\jackson-core-2.22.1.jar;client\lib\jackson-databind-2.22.1.jar;client\lib\jtokkit-1.1.0.jar;client\lib\mutiny-zero-1.3.1.jar;client\lib\opennlp-tools-2.5.11.jar;client\lib\error_prone_annotations-2.27.0.jar;client\lib\jspecify-1.0.1.jar" ^
  com.jagent.Main