package com.jagent.harness;

import com.jagent.common.exception.BusinessException;
import com.jagent.harness.permission.HarnessPermissionPolicy;
import com.jagent.harness.verify.VerifyDef;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Harness 框架不变量测试：注册、编排、串联、错误隔离与权限闸门。
 *
 * @author azhu
 * @date 2026-10-24
 */
class HarnessFrameworkTest {

    @Test
    void registryRejectsDuplicateId() {
        HarnessRegistry registry = new HarnessRegistry();
        registry.register(harness("a", "A"));
        assertThrows(BusinessException.class, () -> registry.register(harness("a", "B")));
        assertNotNull(registry.get("a"));
    }

    @Test
    void pipelineExecutesInOrder() {
        List<String> calls = new ArrayList<>();
        HarnessPipeline pipeline = new HarnessPipeline()
                .add(recording("a", calls))
                .add(recording("b", calls));

        List<HarnessPipeline.StepResult> results = pipeline.execute("x");

        assertEquals(List.of("a", "b"), calls);
        assertEquals(2, results.size());
        assertTrue(results.get(0).ok());
        assertTrue(results.get(1).ok());
    }

    @Test
    void pipelineChainsPreviousOutput() {
        AtomicReference<String> seen = new AtomicReference<>();
        HarnessPipeline pipeline = new HarnessPipeline()
                .add(harness("first", "RESULT_A"))
                .add(capture("second", seen))
                .chain(true);

        pipeline.execute("INIT");

        assertEquals("RESULT_A", seen.get());
    }

    @Test
    void pipelineResolvesPlaceholders() {
        AtomicReference<String> seen = new AtomicReference<>();
        HarnessPipeline pipeline = new HarnessPipeline()
                .add(harness("first", "RESULT_A"))
                .add(capture("second", seen), "p:${prev}:${input}:${1}");

        pipeline.execute("ARG");

        assertEquals("p:RESULT_A:ARG:RESULT_A", seen.get());
    }

    @Test
    void pipelineIsolatesStepFailure() {
        AtomicReference<String> seen = new AtomicReference<>();
        HarnessPipeline pipeline = new HarnessPipeline()
                .add(failing("bad"))
                .add(capture("after", seen))
                .chain(true);

        List<HarnessPipeline.StepResult> results = pipeline.execute("x");

        assertEquals(2, results.size());
        assertFalse(results.get(0).ok());
        assertTrue(results.get(1).ok());
        assertTrue(seen.get().startsWith("（上一步执行失败：boom"));
    }

    @Test
    void pipelineSkipsStepWhenConditionNotMet() {
        List<String> calls = new ArrayList<>();
        VerifyDef when = new VerifyDef();
        when.type = "contains";
        when.step = 1;
        when.value = "命中：0 处";
        when.negate = true;

        HarnessPipeline skippedRun = new HarnessPipeline()
                .add(harness("first", "命中：0 处"))
                .add(recording("second", calls), null, when);
        List<HarnessPipeline.StepResult> skipped = skippedRun.execute("x");

        assertEquals(2, skipped.size());
        assertTrue(skipped.get(1).skipped());
        assertTrue(calls.isEmpty());

        HarnessPipeline executedRun = new HarnessPipeline()
                .add(harness("first", "命中：3 处"))
                .add(recording("second", calls), null, when);
        List<HarnessPipeline.StepResult> executed = executedRun.execute("x");

        assertFalse(executed.get(1).skipped());
        assertEquals(List.of("second"), calls);
    }

    @Test
    void permissionPolicyAllowsReadOnlyBashAndGatesNetwork() {
        String safe = "{\"command\":\"pwd; ls -la; echo \\\"---\\\"; date\"}";
        String curl = "{\"command\":\"curl -s -m 8 \\\"https://api.gold-api.com/price/XAU\\\"\"}";

        assertTrue(HarnessPermissionPolicy.permitted("Read", "{\"path\":\"a\"}", false));
        assertTrue(HarnessPermissionPolicy.permitted("demo__now", "{}", false));
        assertTrue(HarnessPermissionPolicy.permitted("Bash", safe, false));
        assertFalse(HarnessPermissionPolicy.permitted("Bash", curl, false));
        assertTrue(HarnessPermissionPolicy.permitted("Bash", curl, true));
        assertFalse(HarnessPermissionPolicy.permitted("Bash", "{\"command\":\"rm -rf /\"}", false));
        assertFalse(HarnessPermissionPolicy.permitted("Bash", "{\"command\":\"ls > out.txt\"}", false));
        assertFalse(HarnessPermissionPolicy.permitted("Write", "{\"path\":\"a\",\"content\":\"b\"}", false));
    }

    // ---- helpers ----

    private static Harness harness(String id, String output) {
        return new Harness() {
            @Override public String id() { return id; }
            @Override public String name() { return id; }
            @Override public String execute(String input) { return output; }
        };
    }

    private static Harness recording(String id, List<String> calls) {
        return new Harness() {
            @Override public String id() { return id; }
            @Override public String name() { return id; }
            @Override public String execute(String input) {
                calls.add(id);
                return id;
            }
        };
    }

    private static Harness capture(String id, AtomicReference<String> seen) {
        return new Harness() {
            @Override public String id() { return id; }
            @Override public String name() { return id; }
            @Override public String execute(String input) {
                seen.set(input);
                return input;
            }
        };
    }

    private static Harness failing(String id) {
        return new Harness() {
            @Override public String id() { return id; }
            @Override public String name() { return id; }
            @Override public String execute(String input) {
                throw new IllegalStateException("boom");
            }
        };
    }
}
