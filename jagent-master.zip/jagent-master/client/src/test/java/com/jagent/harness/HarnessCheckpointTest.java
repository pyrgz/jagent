package com.jagent.harness;

import com.jagent.harness.checkpoint.HarnessCheckpointStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * checkpoint 断点续跑与独立验收测试。
 *
 * @author azhu
 * @date 2026-10-24
 */
class HarnessCheckpointTest {

    @TempDir
    Path temp;

    @Test
    void resumeFromFailedStepAndVerify() throws Exception {
        HarnessRegistry registry = new HarnessRegistry();
        AtomicInteger attempts = new AtomicInteger();
        registry.register(new Harness() {
            @Override public String id() { return "flaky"; }
            @Override public String name() { return "不稳定步骤"; }
            @Override public String execute(String input) {
                if (attempts.incrementAndGet() == 1) throw new IllegalStateException("first failure");
                return "OK:" + input;
            }
        });

        HarnessCheckpointStore store = new HarnessCheckpointStore(temp.resolve("runs"));
        HarnessPipelineService service = service(registry, store,
                "{\"pipelines\":{\"p\":{\"name\":\"测试编排\",\"steps\":[{\"harness\":\"flaky\"}],"
                        + "\"verify\":[{\"type\":\"contains\",\"step\":1,\"value\":\"OK\"}]}}}");

        String first = service.execute("p");
        assertTrue(first.contains("状态：error"), first);
        assertTrue(first.contains("--resume"), first);
        assertTrue(first.contains("验收结果：失败"), first);

        String runId = store.recent(1).get(0).runId;
        String second = service.execute("--resume " + runId);
        assertTrue(second.contains("状态：ok"), second);
        assertTrue(second.contains("验收结果：通过"), second);
        assertEquals(2, attempts.get());
    }

    @Test
    void verificationFailsIndependently() throws Exception {
        HarnessRegistry registry = new HarnessRegistry();
        registry.register(new Harness() {
            @Override public String id() { return "stable"; }
            @Override public String name() { return "稳定步骤"; }
            @Override public String execute(String input) { return "NO_MATCH"; }
        });

        HarnessCheckpointStore store = new HarnessCheckpointStore(temp.resolve("runs2"));
        HarnessPipelineService service = service(registry, store,
                "{\"pipelines\":{\"p\":{\"name\":\"验收失败\",\"steps\":[{\"harness\":\"stable\"}],"
                        + "\"verify\":[{\"type\":\"contains\",\"step\":1,\"value\":\"OK\"}]}}}");

        String result = service.execute("p");

        assertTrue(result.contains("状态：ok"), result);
        assertTrue(result.contains("验收结果：失败"), result);
        assertEquals("failed", store.recent(1).get(0).verification);
    }

    private HarnessPipelineService service(HarnessRegistry registry, HarnessCheckpointStore store,
                                           String configJson) throws Exception {
        Path config = temp.resolve("pipelines-" + System.nanoTime() + ".json");
        Files.writeString(config, configJson, StandardCharsets.UTF_8);
        return new HarnessPipelineService(registry, config, store);
    }
}
