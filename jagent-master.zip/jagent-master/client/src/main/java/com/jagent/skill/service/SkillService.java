package com.jagent.skill.service;

import com.jagent.harness.Harness;
import com.jagent.settings.service.SettingsService;
import com.jagent.skill.model.Skill;
import com.jagent.store.Store;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * 技能（Claude/CodeBuddy SKILL.md）发现、加载/卸载、创建/编辑/删除。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class SkillService implements Harness {

    @Override
    public String id() { return "skill"; }

    @Override
    public String name() { return "技能"; }

    private static final Logger log = LogManager.getLogger(SkillService.class);

    public interface Listener {
        default void onChanged() {}

        default void onError(String message) {}
    }

    private final SettingsService settings;
    private final List<Skill> skills = new ArrayList<>();
    private final Set<String> loadedPaths = new LinkedHashSet<>();
    private Listener listener = new Listener() {};

    public SkillService(SettingsService settings) {
        this.settings = settings;
        loadedPaths.addAll(Store.loadLoadedSkills());
        refresh();
    }

    public void setListener(Listener listener) {
        this.listener = listener == null ? new Listener() {} : listener;
    }

    /** 重新扫描技能目录并通知监听者。 */
    public void refresh() {
        skills.clear();
        scan(userSkillDirs(), "user");
        scan(projectSkillDirs(), "project");
        skills.sort(Comparator.comparing(s -> s.name.toLowerCase()));
        for (Skill s : skills) {
            s.loaded = loadedPaths.contains(s.path);
        }
        log.info("技能扫描完成：共 {} 个，已加载 {} 个", skills.size(),
                skills.stream().filter(s -> s.loaded).count());
        listener.onChanged();
    }

    public List<Skill> all() {
        return skills;
    }

    /** 供对话框命令 {@code /harness skill} 调用：列出已发现的技能。 */
    @Override
    public String execute(String input) {
        if (skills.isEmpty()) return "暂无技能。可在技能面板新建或刷新。";
        StringBuilder sb = new StringBuilder("已发现技能：\n");
        for (Skill s : skills) {
            sb.append("- ").append(s.name);
            if (s.description != null && !s.description.isBlank()) {
                sb.append("：").append(s.description.trim());
            }
            sb.append('\n');
        }
        return sb.toString().trim();
    }

    public boolean isLoaded(Skill skill) {
        return skill != null && loadedPaths.contains(skill.path);
    }

    /** 加载/卸载技能（是否将其指令注入系统提示词）。 */
    public void setLoaded(Skill skill, boolean loaded) {
        if (skill == null) return;
        if (loaded) {
            loadedPaths.add(skill.path);
        } else {
            loadedPaths.remove(skill.path);
        }
        skill.loaded = loaded;
        Store.saveLoadedSkills(new ArrayList<>(loadedPaths));
        log.info("{}技能：{} ({})", loaded ? "加载" : "卸载", skill.name, skill.path);
        listener.onChanged();
    }

    /**
     * 仅当会话显式指定了技能时，返回该技能的系统提示词追加文本；否则返回 null。
     *
     * <p>只注入技能元数据（名称、描述、目录），不内联 SKILL.md 全文。模型在任务匹配时
     * 再用 Read 工具按需读取 {@code <目录>/SKILL.md}，避免每次请求携带大量无关内容。</p>
     */
    public String appendSystemPrompt(String skillPath) {
        if (skillPath == null || skillPath.isBlank()) return null;
        for (Skill s : skills) {
            if (!skillPath.equals(s.path)) continue;
            StringBuilder body = new StringBuilder();
            body.append("\n\n## 技能: ").append(s.name).append("\n");
            if (s.description != null && !s.description.isBlank()) {
                body.append(s.description.trim()).append("\n");
            }
            body.append("技能目录: ").append(s.path).append("\n");
            body.append("当任务与上述描述匹配时，请先读取 ").append(s.path)
                    .append("/SKILL.md 获取完整指令，再严格按指令执行。\n");
            return "\n\n# 已指定技能\n本会话指定使用以下技能。请先读取对应 SKILL.md，"
                    + "然后严格遵循其中的指令执行；技能目录内可能包含脚本，请使用可用工具（如 Bash）在技能目录内运行它们。\n"
                    + body;
        }
        return null;
    }

    /** 新建技能（写入用户级技能目录，并自动加载）。 */
    public void create(String name, String description, String content) {
        Path base = userSkillDirs().get(0);
        try {
            Files.createDirectories(base);
            Path dir = base.resolve(slugify(name));
            Files.createDirectories(dir);
            Files.writeString(dir.resolve("SKILL.md"), render(name, description, content),
                    StandardCharsets.UTF_8);
            loadedPaths.add(dir.toString());
            Store.saveLoadedSkills(new ArrayList<>(loadedPaths));
            log.info("创建技能：{} -> {}", name, dir);
        } catch (IOException e) {
            log.error("创建技能失败：{}", name, e);
            listener.onError("创建技能失败：" + e.getMessage());
            return;
        }
        refresh();
    }

    /** 覆盖保存技能（原地更新 SKILL.md）。 */
    public void save(Skill skill, String name, String description, String content) {
        if (skill == null) return;
        try {
            Path md = Path.of(skill.path).resolve("SKILL.md");
            Files.writeString(md, render(name, description, content), StandardCharsets.UTF_8);
            log.info("保存技能：{} -> {}", name, md);
        } catch (IOException e) {
            log.error("保存技能失败：{}", name, e);
            listener.onError("保存技能失败：" + e.getMessage());
            return;
        }
        refresh();
    }

    /** 删除技能（移除整个技能目录，仅限已发现的技能目录内的 SKILL.md）。 */
    public void delete(Skill skill) {
        if (skill == null) return;
        Path dir = Path.of(skill.path);
        if (!Files.isRegularFile(dir.resolve("SKILL.md")) || !isWithinSkillRoots(dir)) {
            listener.onError("拒绝删除：目录不是有效的技能目录。");
            return;
        }
        try {
            deleteRecursively(dir);
            loadedPaths.remove(skill.path);
            Store.saveLoadedSkills(new ArrayList<>(loadedPaths));
            log.info("删除技能：{} ({})", skill.name, dir);
        } catch (IOException e) {
            log.error("删除技能失败：{}", skill.name, e);
            listener.onError("删除技能失败：" + e.getMessage());
            return;
        }
        refresh();
    }

    // ================= 目录与扫描 =================

    private List<Path> userSkillDirs() {
        List<Path> dirs = new ArrayList<>();
        // 默认：工程 data/skills 目录（不加载用户主目录下的 .codebuddy/.claude 技能）
        dirs.add(Store.dataDir().resolve("skills"));
        return dirs;
    }

    private List<Path> projectSkillDirs() {
        List<Path> dirs = new ArrayList<>();
        String ws = settings.settings().workspaceDir;
        if (ws == null || ws.isBlank()) ws = settings.settings().cwd;
        if (ws != null && !ws.isBlank()) {
            dirs.add(Path.of(ws, ".codebuddy", "skills"));
        }
        return dirs;
    }

    private void scan(List<Path> dirs, String source) {
        for (Path dir : dirs) {
            if (!Files.isDirectory(dir)) continue;
            try (Stream<Path> stream = Files.list(dir)) {
                stream.filter(Files::isDirectory).forEach(sub -> {
                    Skill s = parse(sub, source);
                    if (s != null) skills.add(s);
                });
            } catch (IOException e) {
                log.warn("扫描技能目录失败：{}", dir, e);
            }
        }
    }

    private static Skill parse(Path dir, String source) {
        Path md = dir.resolve("SKILL.md");
        if (!Files.isRegularFile(md)) return null;
        try {
            String text = Files.readString(md, StandardCharsets.UTF_8);
            Skill s = new Skill();
            s.path = dir.toString();
            s.source = source;
            s.name = dir.getFileName() == null ? dir.toString() : dir.getFileName().toString();
            s.content = text;
            if (text.startsWith("---")) {
                int end = text.indexOf("\n---", 3);
                if (end > 0) {
                    String fm = text.substring(3, end);
                    s.content = text.substring(end + 4).stripLeading();
                    for (String line : fm.split("\\r?\\n")) {
                        int idx = line.indexOf(':');
                        if (idx <= 0) continue;
                        String k = line.substring(0, idx).trim();
                        String v = line.substring(idx + 1).trim();
                        if ("name".equals(k)) {
                            s.name = v;
                        } else if ("description".equals(k)) {
                            s.description = v;
                        }
                    }
                }
            }
            s.hasScripts = hasScripts(dir);
            return s;
        } catch (IOException e) {
            log.warn("解析技能失败：{}", dir, e);
            return null;
        }
    }

    private static boolean hasScripts(Path dir) {
        try (Stream<Path> stream = Files.list(dir)) {
            return stream.anyMatch(p -> Files.isRegularFile(p)
                    && !"SKILL.md".equals(p.getFileName() == null ? "" : p.getFileName().toString()));
        } catch (IOException e) {
            return false;
        }
    }

    private boolean isWithinSkillRoots(Path dir) {
        for (Path root : userSkillDirs()) if (dir.startsWith(root)) return true;
        for (Path root : projectSkillDirs()) if (dir.startsWith(root)) return true;
        return false;
    }

    private static void deleteRecursively(Path dir) throws IOException {
        if (!Files.exists(dir)) return;
        try (Stream<Path> stream = Files.walk(dir)) {
            stream.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.delete(p);
                } catch (IOException ignored) {
                }
            });
        }
    }

    private static String render(String name, String description, String content) {
        StringBuilder sb = new StringBuilder();
        sb.append("---\n");
        sb.append("name: ").append(name == null ? "" : name.trim()).append("\n");
        sb.append("description: ").append(description == null ? "" : description.trim()).append("\n");
        sb.append("---\n\n");
        sb.append(content == null ? "" : content.trim()).append('\n');
        return sb.toString();
    }

    private static String slugify(String name) {
        String s = name == null ? "" : name.trim().toLowerCase();
        s = s.replaceAll("[^a-z0-9\\u4e00-\\u9fa5]+", "-").replaceAll("^-+|-+$", "");
        return s.isBlank() ? "skill" : s;
    }
}
