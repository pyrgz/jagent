package com.jagent.ui;

import com.jagent.chat.model.ToolCall;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.transform.Rotate;

/**
 * 工具调用卡片：显示工具名、参数、结果，可折叠
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ToolCard extends VBox {

    private final ToolCall tool;
    private final StackPane statusBox;
    private final Label statusLabel;
    private final Region chevron;
    private final VBox content;
    private final VBox resultSection;
    private final TextFlow resultFlow;
    private boolean expanded = false;
    private boolean restored = false;

    public ToolCard(ToolCall tool) {
        this.tool = tool;
        getStyleClass().add("tool-card");
        setSpacing(0);

        // ---------- 头部 ----------
        HBox header = new HBox(8);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("tool-header");
        header.setPadding(new Insets(6, 10, 6, 10));

        statusBox = new StackPane();
        statusBox.setPrefSize(16, 16);
        statusBox.setMinSize(16, 16);

        Label name = new Label(tool.name);
        name.getStyleClass().add("tool-name");

        statusLabel = new Label("运行中");
        statusLabel.getStyleClass().add("tool-status");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        chevron = new Region();
        chevron.getStyleClass().add("tool-chevron");
        chevron.setPrefSize(14, 14);
        chevron.setMinSize(14, 14);
        chevron.setMaxSize(14, 14);
        chevron.getTransforms().add(new Rotate(0, 7, 7));

        header.getChildren().addAll(statusBox, name, statusLabel, spacer, chevron);

        // ---------- 内容 ----------
        content = new VBox(6);
        content.getStyleClass().add("tool-content");
        content.setManaged(false);
        content.setVisible(false);
        content.setPadding(new Insets(4, 10, 10, 10));

        TextFlow inputFlow = new TextFlow();
        inputFlow.getStyleClass().add("md-code-flow");
        Text inputText = new Text(prettyJson(tool.inputJson));
        inputText.getStyleClass().add("tool-code-text");
        inputFlow.getChildren().add(inputText);

        Label inputCaption = new Label("参数");
        inputCaption.getStyleClass().add("tool-caption");

        resultSection = new VBox(4);
        resultSection.setManaged(false);
        resultSection.setVisible(false);
        Label resultCaption = new Label("结果");
        resultCaption.getStyleClass().add("tool-caption");
        resultFlow = new TextFlow();
        resultFlow.getStyleClass().add("md-code-flow");
        Text resultText = new Text(tool.result == null ? "" : tool.result);
        resultText.getStyleClass().add("tool-code-text");
        resultFlow.getChildren().add(resultText);
        ScrollPane resultScroll = new ScrollPane(resultFlow);
        resultScroll.getStyleClass().add("tool-result-scroll");
        resultScroll.setFitToWidth(true);
        resultScroll.setPrefHeight(140);
        resultScroll.setMaxHeight(140);
        resultScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        resultSection.getChildren().addAll(resultCaption, resultScroll);

        content.getChildren().addAll(inputCaption, inputFlow, resultSection);

        header.addEventHandler(MouseEvent.MOUSE_CLICKED, e -> toggle());

        getChildren().addAll(header, content);
        update(tool);
    }

    private void toggle() {
        expanded = !expanded;
        content.setManaged(expanded);
        content.setVisible(expanded);
        resultSection.setManaged(expanded && resultFlow.getChildren().size() > 0
                && !((Text) resultFlow.getChildren().get(0)).getText().isEmpty());
        resultSection.setVisible(resultSection.isManaged());
        ((Rotate) chevron.getTransforms().get(0)).setAngle(expanded ? 180 : 0);
    }

    /** 标记为从历史会话恢复的卡片：运行中状态不再显示转圈，而显示「未完成」。 */
    public void markRestored() {
        this.restored = true;
        update(tool);
    }

    /** 根据模型数据刷新状态 */
    public void update(ToolCall tool) {
        Node statusNode;
        switch (tool.status == null ? "running" : tool.status) {
            case "completed" -> {
                statusNode = Icons.stroke(Icons.CHECK, 14, javafx.scene.paint.Color.web("#2EA44F"));
                statusLabel.setText("完成");
                statusLabel.getStyleClass().setAll("tool-status", "tool-status-ok");
            }
            case "error" -> {
                statusNode = Icons.stroke(Icons.CLOSE, 14, javafx.scene.paint.Color.web("#E5484D"));
                statusLabel.setText("失败");
                statusLabel.getStyleClass().setAll("tool-status", "tool-status-err");
            }
            default -> {
                if (restored) {
                    statusNode = Icons.stroke(Icons.CLOCK, 14, javafx.scene.paint.Color.web("#98A0AB"));
                    statusLabel.setText("未完成");
                    statusLabel.getStyleClass().setAll("tool-status", "tool-status-stale");
                } else {
                    ProgressIndicator pi = new ProgressIndicator();
                    pi.setPrefSize(14, 14);
                    pi.setMinSize(14, 14);
                    pi.setMaxSize(14, 14);
                    statusNode = pi;
                    statusLabel.setText("运行中");
                    statusLabel.getStyleClass().setAll("tool-status", "tool-status-running");
                }
            }
        }
        statusBox.getChildren().setAll(statusNode);

        if (tool.result != null && !tool.result.isBlank() && resultFlow.getChildren().size() > 0) {
            Text t = (Text) resultFlow.getChildren().get(0);
            String shown = tool.result.length() > 4000 ? tool.result.substring(0, 4000) + "\n…（已截断）" : tool.result;
            t.setText(shown);
            resultSection.setManaged(expanded);
            resultSection.setVisible(expanded);
        }
    }

    static String prettyJson(String json) {
        if (json == null || json.isBlank()) return "{}";
        try {
            return new GsonBuilder().setPrettyPrinting().create()
                    .toJson(JsonParser.parseString(json));
        } catch (Exception e) {
            return json;
        }
    }
}
