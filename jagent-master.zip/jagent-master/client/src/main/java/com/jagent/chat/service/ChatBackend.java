package com.jagent.chat.service;

import com.jagent.chat.model.ChatRequest;
import com.google.gson.JsonObject;

/**
 * 聊天后端抽象：CodeBuddy 桥接（{@code CodeBuddyBackend}）与 langchain4j 直连
 * （{@code Langchain4jBackend}）都实现该接口，供 {@code ChatService} 按「模型来源」动态切换。
 *
 * <p>放在 api 包以避免 service→api 反向依赖；实现类位于 service 包（service→api）。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public interface ChatBackend {

    /** 聊天事件回调（方法在后台线程触发，UI 层需自行切换到 FX 线程） */
    interface StreamListener {
        default void onInit(JsonObject data) {}

        default void onSession(String sdkSessionId) {}

        default void onText(String content) {}

        /** 模型思考（扩展思考/推理）增量，与正文分开 */
        default void onThinking(String content) {}

        default void onTool(String id, String name, String inputJson) {}

        default void onToolResult(String toolId, String content, boolean isError) {}

        /** 工具入参流式增量（可选实现；完整入参仍由 onTool 下发） */
        default void onToolInputDelta(String toolId, String partialJson) {}

        default void onPermissionRequest(String requestId, String toolName, String inputJson) {}

        default void onDone(JsonObject data) {}

        /** 无错误码的错误；默认转交给带错误码的重载，便于统一处理。 */
        default void onError(String message) {
            onError(null, message);
        }

        default void onError(String code, String message) {}
    }

    /** 后端唯一标识：{@code "jagent"} 或 {@code "langchain4j"} */
    String id();

    /** 后端当前是否可用（网络/配置就绪） */
    boolean isAvailable();

    /** 发送消息并流式回调（阻塞，应在后台线程调用） */
    void chat(ChatRequest request, StreamListener listener);

    /** 中断某个会话的流式响应 */
    void abort(String conversationId);

    /** 响应工具权限请求（仅 CodeBuddy 后端使用；langchain4j 默认无操作） */
    default void respondPermission(String requestId, boolean allow, String message) {}

    /** 释放资源 */
    default void shutdown() {}
}
