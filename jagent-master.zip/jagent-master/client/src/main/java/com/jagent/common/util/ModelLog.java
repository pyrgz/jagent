package com.jagent.common.util;

import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.ChatRequest;
import com.jagent.chat.model.ToolCall;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;

import java.util.List;

/**
 * 模型输入 / 输出日志。
 *
 * <p>普通模式只打印一行摘要；调试模式打印完整的系统提示词、历史消息、当前消息、
 * 工具入参与结果以及模型最终输出（含思考过程）。调试模式由设置项 {@code debug}
 * 控制，也可用 {@code -Djagent.debug=true} 或环境变量 {@code JAGENT_DEBUG=true}
 * 强制开启。</p>
 *
 * <p>模型日志使用独立 logger {@value #LOGGER_NAME}，同时输出到控制台与
 * {@code data/model.log}，方便复查长对话。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class ModelLog {

    public static final String LOGGER_NAME = "com.jagent.model";

    private static final Logger log = LogManager.getLogger(LOGGER_NAME);
    private static final int PREVIEW_LIMIT = 200;

    private static volatile boolean debug;

    private ModelLog() {}

    /** 开关调试模式（同步调整 logger 级别：开=DEBUG，关=INFO）。 */
    public static void setDebug(boolean enabled) {
        debug = enabled;
        Configurator.setLevel(LOGGER_NAME, enabled ? Level.DEBUG : Level.INFO);
        log.info("模型日志：{}", enabled ? "调试模式（全量输入输出）" : "普通模式（摘要）");
    }

    public static boolean isDebug() {
        return debug;
    }

    /** 记录一次模型请求的输入（两个后端共用的逻辑输入）。 */
    public static void input(String backend, ChatRequest req) {
        if (req == null) return;
        log.info("[模型输入] backend={}, conv={}, model={}, 历史={}条, 指令={}字, 消息={}",
                backend, req.conversationId, req.model,
                req.history == null ? 0 : req.history.size(),
                length(req.systemPromptAppend), preview(req.message));
        if (!log.isDebugEnabled()) return;
        log.debug("[模型输入] backend={}, conv={}, model={}, cwd={}, permissionMode={}, resume={}",
                backend, req.conversationId, req.model, req.cwd, req.permissionMode, req.resume);
        if (notBlank(req.systemPromptAppend)) {
            log.debug("[模型输入] 系统提示词：\n{}", req.systemPromptAppend);
        }
        if (req.history != null) {
            for (int i = 0; i < req.history.size(); i++) {
                ChatMessage m = req.history.get(i);
                log.debug("[模型输入] 历史[{}]:\n{}", i, render(m));
            }
        }
        log.debug("[模型输入] 当前消息：\n{}", req.message);
    }

    /** 记录后端实际提交的消息与工具定义（langchain4j 工具循环每轮都会重新提交）。 */
    public static void inputMessages(String backend, String convId, int turn, List<?> messages, List<?> tools) {
        if (!log.isDebugEnabled()) return;
        int messageCount = messages == null ? 0 : messages.size();
        int toolCount = tools == null ? 0 : tools.size();
        log.debug("[模型输入] backend={}, conv={}, 第{}轮，消息={}条，工具={}个",
                backend, convId, turn, messageCount, toolCount);
        if (messages != null) {
            for (int i = 0; i < messages.size(); i++) {
                log.debug("[模型输入] conv={} 第{}轮 消息[{}]:\n{}", convId, turn, i, messages.get(i));
            }
        }
        if (tools != null) {
            for (int i = 0; i < tools.size(); i++) {
                log.debug("[模型输入] conv={} 第{}轮 工具[{}]:\n{}", convId, turn, i, tools.get(i));
            }
        }
    }

    /** 记录实际发送给桥接服务的 HTTP 请求体。 */
    public static void requestBody(String convId, String body) {
        if (log.isDebugEnabled()) log.debug("[模型输入] conv={} 请求体：\n{}", convId, body);
    }

    public static void session(String convId, String sdkSessionId) {
        if (log.isDebugEnabled()) log.debug("[模型会话] conv={}, sdkSessionId={}", convId, sdkSessionId);
    }

    public static void tool(String convId, String name, String inputJson) {
        log.info("[工具调用] conv={}, 工具={}, 参数={}", convId, name, preview(inputJson));
        if (log.isDebugEnabled()) log.debug("[工具调用] conv={}, 工具={}, 完整参数：\n{}", convId, name, inputJson);
    }

    public static void toolResult(String convId, String toolId, String content, boolean isError) {
        log.info("[工具结果] conv={}, toolId={}, 错误={}, 长度={}, 摘要={}",
                convId, toolId, isError, length(content), preview(content));
        if (log.isDebugEnabled()) log.debug("[工具结果] conv={}, toolId={}, 完整结果：\n{}", convId, toolId, content);
    }

    /** 记录模型最终输出（正文 + 思考 + 工具调用）。 */
    public static void done(String convId, ChatMessage msg) {
        if (msg == null) return;
        log.info("[模型输出] conv={}, 正文={}字, 思考={}字, 工具={}个",
                convId, length(msg.content), length(msg.thinking),
                msg.toolCalls == null ? 0 : msg.toolCalls.size());
        if (log.isDebugEnabled()) log.debug("[模型输出] conv={} 完整内容：\n{}", convId, render(msg));
    }

    public static void error(String convId, String message) {
        log.warn("[模型错误] conv={}, 错误={}", convId, message);
    }

    // ---- helpers ----

    private static String render(ChatMessage m) {
        if (m == null) return "null";
        StringBuilder sb = new StringBuilder();
        sb.append("[role=").append(m.role).append(", id=").append(m.id).append("]\n");
        if (notBlank(m.thinking)) sb.append("--- 思考 ---\n").append(m.thinking).append('\n');
        sb.append(m.content == null || m.content.isEmpty() ? "（无正文）" : m.content);
        if (m.toolCalls != null && !m.toolCalls.isEmpty()) {
            for (ToolCall tc : m.toolCalls) {
                sb.append("\n--- 工具调用 ---\n")
                        .append("name=").append(tc.name)
                        .append(", id=").append(tc.id)
                        .append(", status=").append(tc.status)
                        .append("\n参数：").append(tc.inputJson);
                if (tc.result != null) sb.append("\n结果：").append(tc.result);
            }
        }
        return sb.toString();
    }

    private static boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }

    private static int length(String s) {
        return s == null ? 0 : s.length();
    }

    private static String preview(String s) {
        if (s == null) return "";
        String flat = s.replace("\r", "").replace("\n", "⏎");
        return flat.length() <= PREVIEW_LIMIT ? flat : flat.substring(0, PREVIEW_LIMIT) + "…";
    }
}
