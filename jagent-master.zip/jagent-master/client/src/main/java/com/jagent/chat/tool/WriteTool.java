package com.jagent.chat.tool;

import com.google.gson.JsonObject;
import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 将内容写入文件（不存在则创建，含父目录）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class WriteTool extends BaseTool {

    public WriteTool(Path root) {
        super(root);
    }

    @Override
    public ToolSpecification specification() {
        return ToolSpecification.builder()
                .name("Write")
                .description("将内容写入指定路径的文件（不存在则创建，自动创建父目录）。")
                .parameters(JsonObjectSchema.builder()
                        .addStringProperty("path", "文件的绝对路径或相对工作目录的路径")
                        .addStringProperty("content", "要写入的完整文件内容")
                        .required("path", "content")
                        .build())
                .build();
    }

    @Override
    public String execute(String argumentsJson) throws Exception {
        JsonObject a = args(argumentsJson);
        String p = arg(a, "path");
        String content = arg(a, "content");
        if (p == null || p.isBlank()) return "错误：缺少 path 参数";
        if (content == null) return "错误：缺少 content 参数";
        Path target = resolve(p);
        if (target.getParent() != null) Files.createDirectories(target.getParent());
        Files.writeString(target, content);
        return "已写入 " + content.length() + " 字符到 " + target;
    }

    @Override
    public boolean requiresPermission() {
        return true;
    }
}
