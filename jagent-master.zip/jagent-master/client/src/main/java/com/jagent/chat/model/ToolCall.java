package com.jagent.chat.model;

/**
 * 工具调用记录
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ToolCall {
    public String id;
    public String name;
    public String inputJson;
    public String result;
    public String status = "running"; // running | completed | error

    public ToolCall() {}

    public ToolCall(String id, String name, String inputJson) {
        this.id = id;
        this.name = name;
        this.inputJson = inputJson;
    }
}
