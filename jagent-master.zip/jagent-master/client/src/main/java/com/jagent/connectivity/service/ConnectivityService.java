package com.jagent.connectivity.service;

import com.jagent.harness.Harness;
import com.jagent.chat.model.ModelInfo;
import com.jagent.chat.service.CodeBuddyBackend;
import com.jagent.settings.service.SettingsService;
import com.jagent.store.Store;
import com.google.gson.JsonObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 服务端连通性：自启动 Node 桥接服务、健康检查、登录、模型列表。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ConnectivityService implements Harness {

    private static final Logger log = LogManager.getLogger(ConnectivityService.class);

    @Override
    public String id() { return "connectivity"; }

    @Override
    public String name() { return "连接"; }

    @Override
    public void initialize() { bootstrap(); }

    public interface Listener {
        default void onStatus(boolean ok, String text) {}
        default void onModels(List<ModelInfo> models) {}
        default void onLoginChecked(JsonObject login) {}
    }

    private final CodeBuddyBackend bridge;
    private final SettingsService settings;
    private Listener listener = new Listener() {};
    private Process serverProcess;

    public ConnectivityService(CodeBuddyBackend bridge, SettingsService settings) {
        this.bridge = bridge;
        this.settings = settings;
    }

    public void setListener(Listener listener) {
        this.listener = listener == null ? new Listener() {} : listener;
    }

    /** 启动流程：确保服务可用，然后加载登录状态与模型。 */
    public void bootstrap() {
        Thread.ofVirtual().name("bootstrap").start(() -> {
            boolean ok;
            try {
                ok = ensureServerRunning();
            } catch (Exception e) {
                ok = false;
            }
            if (ok) {
                listener.onStatus(true, "服务已连接");
                refreshLoginAndModels();
            } else {
                listener.onStatus(false, "服务未连接");
            }
        });
    }

    public void refreshLoginAndModels() {
        Thread.ofVirtual().name("login-check").start(() -> {
            JsonObject login = bridge.checkLogin();
            List<ModelInfo> modelList = null;
            try {
                modelList = bridge.models();
            } catch (Exception e) {
                log.warn("获取模型列表失败：{}", e.getMessage());
            }
            final JsonObject l = login;
            final List<ModelInfo> m = modelList;
            listener.onLoginChecked(l);
            if (m != null && !m.isEmpty()) {
                log.info("获取到模型列表：{} 个", m.size());
                listener.onModels(m);
            }
        });
    }

    // ---- 登录/配置委托 ----

    public JsonObject login() {
        return bridge.login();
    }

    public JsonObject checkLogin() {
        return bridge.checkLogin();
    }

    public void saveConfig(String apiKey) {
        bridge.saveConfig(apiKey);
    }

    public void setBaseUrl(String url) {
        bridge.setBaseUrl(url);
    }

    // ---- 服务自启动 ----

    private boolean ensureServerRunning() throws InterruptedException {
        if (bridge.health()) return true;
        Process p = spawnServer();
        if (p == null) return bridge.health();
        for (int i = 0; i < 25; i++) {
            Thread.sleep(800);
            if (bridge.health()) return true;
            if (!p.isAlive()) return false;
        }
        return bridge.health();
    }

    private Process spawnServer() {
        Path serverJs = findServerJs();
        if (serverJs == null) {
            log.error("未找到 server/index.js");
            return null;
        }
        for (String node : nodeCandidates()) {
            try {
                ProcessBuilder pb = new ProcessBuilder(node, serverJs.getFileName().toString())
                        .directory(serverJs.getParent().toFile())
                        .redirectErrorStream(true);
                Process p = pb.start();
                serverProcess = p;
                Runtime.getRuntime().addShutdownHook(new Thread(p::destroy));
                // 日志写入 data/bridge.log
                Thread.ofVirtual().name("bridge-log").start(() -> {
                    try (BufferedReader reader = new BufferedReader(
                            new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
                        try (BufferedWriter writer = Files.newBufferedWriter(
                                Store.dataDir().resolve("bridge.log"), StandardCharsets.UTF_8)) {
                            String line;
                            while ((line = reader.readLine()) != null) {
                                writer.write(line);
                                writer.newLine();
                            }
                        }
                    } catch (Exception ignored) {
                    }
                });
                log.info("已启动桥接服务：{} {}", node, serverJs);
                return p;
            } catch (Exception e) {
                // 尝试下一个 node 路径
            }
        }
        return null;
    }

    private Path findServerJs() {
        Path userDir = Path.of(System.getProperty("user.dir"));
        Path dir = userDir;
        for (int i = 0; i < 3; i++) {
            Path candidate = dir.resolve("server").resolve("index.js");
            if (Files.isRegularFile(candidate)) return candidate;
            dir = dir.getParent();
            if (dir == null) break;
        }
        return null;
    }

    private List<String> nodeCandidates() {
        List<String> candidates = new ArrayList<>();
        candidates.add("node");
        String userHome = System.getProperty("user.home", "");
        if (!userHome.isBlank()) {
            Path managed = Path.of(userHome, ".workbuddy", "binaries", "node", "versions");
            if (Files.isDirectory(managed)) {
                try (var stream = Files.list(managed)) {
                    stream.filter(Files::isDirectory)
                            .map(v -> v.resolve("node.exe"))
                            .filter(Files::isRegularFile)
                            .forEach(v -> candidates.add(v.toString()));
                } catch (Exception ignored) {
                }
            }
        }
        candidates.add("D:\\Program Files\\nodejs\\node.exe");
        candidates.add("C:\\Program Files\\nodejs\\node.exe");
        return candidates;
    }

    public void shutdown() {
        if (serverProcess != null && serverProcess.isAlive()) {
            serverProcess.destroy();
        }
    }
}
