package com.jagent.knowledge.model;

import java.util.UUID;

/**
 * 知识库内的单个文档
 *
 * @author azhu
 * @date 2026-10-24
 */
public class KnowledgeDocument {
    public String id = UUID.randomUUID().toString();
    public String name = "";
    /** 原始文档在本地知识库目录中的存储路径（工程 data/knowledge/<库ID>/<文件名>） */
    public String path = "";
    public int chunkCount = 0;
    public long createdAt = System.currentTimeMillis();
}
