package com.jagent.workspace.service;

import com.jagent.harness.Harness;
import com.jagent.settings.service.SettingsService;
import com.jagent.workspace.model.FileNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * 工作区文件浏览：打开目录、列出子项、读取文件内容。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class WorkspaceService implements Harness {

    private static final Logger log = LogManager.getLogger(WorkspaceService.class);

    @Override
    public String id() { return "workspace"; }

    @Override
    public String name() { return "工作区"; }

    /** 文本预览上限，避免大文件占用过多内存。 */
    private static final long MAX_TEXT_BYTES = 2L * 1024 * 1024;

    /** 默认忽略的噪声目录（隐藏目录由 `.` 前缀规则统一过滤）。 */
    private static final Set<String> IGNORED_DIRS = Set.of(
            "node_modules", "target", "out", "build", "dist");

    /** 按扩展名直接判定为二进制、交给预览器的类型（避免内容嗅探误判）。 */
    private static final Set<String> PREVIEW_BINARY_EXT = Set.of(
            "pdf", "docx", "doc", "xlsx", "png", "jpg", "jpeg", "gif", "bmp");

    public interface Listener {
        default void onRootChanged(Path root) {}
        default void onFileOpened(String path, String content, boolean binary, long size) {}
        default void onError(String message) {}
    }

    private final SettingsService settings;
    private Path root;
    private Listener listener = new Listener() {};

    public WorkspaceService(SettingsService settings) {
        this.settings = settings;
        String ws = settings.settings().workspaceDir;
        if (ws != null && !ws.isBlank()) {
            Path p = Path.of(ws);
            if (Files.isDirectory(p)) {
                this.root = p;
            }
        }
        log.info("工作区初始化：{}", root == null ? "无" : root);
    }

    public void setListener(Listener listener) {
        this.listener = listener == null ? new Listener() {} : listener;
    }

    public Path root() {
        return root;
    }

    /** 打开工作区目录，持久化到 settings 并通知监听者。 */
    public void openWorkspace(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) {
            log.warn("打开工作区失败：目录无效 {}", dir);
            return;
        }
        this.root = dir;
        settings.settings().workspaceDir = dir.toString();
        // AI 工作目录（工具读写文件的基础目录）跟随切换后的目录
        settings.settings().cwd = dir.toString();
        settings.save();
        log.info("打开工作区：{}", dir);
        listener.onRootChanged(root);
    }

    /** 列出目录下的直接子项（目录在前、按名排序，过滤隐藏与噪声目录）。 */
    public List<FileNode> listChildren(Path dir) {
        List<FileNode> result = new ArrayList<>();
        if (dir == null || !Files.isDirectory(dir)) {
            return result;
        }
        try (Stream<Path> stream = Files.list(dir)) {
            stream.forEach(p -> {
                String name = p.getFileName() == null ? "" : p.getFileName().toString();
                boolean isDir = Files.isDirectory(p);
                if (name.startsWith(".")) {
                    return;
                }
                if (isDir && IGNORED_DIRS.contains(name.toLowerCase())) {
                    return;
                }
                long size = isDir ? 0 : safeSize(p);
                result.add(new FileNode(name, p.toString(), isDir, size));
            });
        } catch (IOException ignored) {
        }
        result.sort(Comparator
                .comparing((FileNode n) -> !n.directory)
                .thenComparing(n -> n.name.toLowerCase()));
        return result;
    }

    /** 异步读取文件内容，通过监听者回调。 */
    public void openFile(Path file) {
        Thread.ofVirtual().name("file-open").start(() -> {
            try {
                if (file == null || !Files.isRegularFile(file)) {
                    listener.onError("无法打开文件：" + file);
                    return;
                }
                long size = Files.size(file);
                if (isPreviewBinary(file)) {
                    listener.onFileOpened(file.toString(), "", true, size);
                    return;
                }
                byte[] bytes = readUpTo(file, MAX_TEXT_BYTES);
                boolean binary = isBinary(bytes);
                String content = "";
                if (!binary) {
                    content = new String(bytes, StandardCharsets.UTF_8);
                    if (size > MAX_TEXT_BYTES) {
                        content += "\n\n…（文件过大，仅显示前 2MB）";
                    }
                }
                listener.onFileOpened(file.toString(), content, binary, size);
            } catch (Exception e) {
                listener.onError("读取文件失败：" + e.getMessage());
            }
        });
    }

    private static long safeSize(Path p) {
        try {
            return Files.size(p);
        } catch (IOException e) {
            return 0;
        }
    }

    private static byte[] readUpTo(Path file, long max) throws IOException {
        long len = Math.min(Files.size(file), max);
        byte[] buf = new byte[(int) len];
        try (InputStream in = Files.newInputStream(file)) {
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
        }
        return buf;
    }

    /** 按扩展名判断是否为「交给预览器」的二进制类型（图片/PDF/Word 等）。 */
    private static boolean isPreviewBinary(Path file) {
        String name = file.getFileName() == null ? "" : file.getFileName().toString();
        int i = name.lastIndexOf('.');
        if (i < 0 || i == name.length() - 1) return false;
        return PREVIEW_BINARY_EXT.contains(name.substring(i + 1).toLowerCase());
    }

    /** 简单二进制探测：NUL 字节，或控制字符占比过高。 */
    private static boolean isBinary(byte[] bytes) {
        int n = Math.min(bytes.length, 8000);
        int suspicious = 0;
        for (int i = 0; i < n; i++) {
            int b = bytes[i] & 0xFF;
            if (b == 0) {
                return true;
            }
            if (b < 0x09 || (b > 0x0D && b < 0x20)) {
                suspicious++;
            }
        }
        return n > 0 && suspicious * 100 / n > 30;
    }
}
