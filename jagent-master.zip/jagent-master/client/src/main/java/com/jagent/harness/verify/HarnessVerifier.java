package com.jagent.harness.verify;

import com.jagent.harness.HarnessPipeline;

import java.util.List;

/**
 * 独立验收：不依赖执行者（模型）自述，直接校验编排步骤的实际输出。
 *
 * @author azhu
 * @date 2026-10-24
 */
public interface HarnessVerifier {

    VerificationResult verify(List<HarnessPipeline.StepResult> steps);
}
