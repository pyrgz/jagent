package com.jagent.schedule.service;

import com.jagent.harness.Harness;
import com.jagent.chat.model.Conversation;
import com.jagent.chat.service.ChatService;
import com.jagent.chat.service.SessionService;
import com.jagent.schedule.model.ScheduledTask;
import com.jagent.store.Store;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 定时任务：cron 调度 + 每个任务绑定专属会话 + 到点触发发送。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ScheduleService implements Harness {

    private static final Logger log = LogManager.getLogger(ScheduleService.class);

    @Override
    public String id() { return "schedule"; }

    @Override
    public String name() { return "定时任务"; }

    private final List<ScheduledTask> schedules = new ArrayList<>();
    private final ScheduleRunner runner = new ScheduleRunner();
    private final SessionService sessions;
    private final ChatService chat;
    private Consumer<ScheduledTask> onFire;

    public ScheduleService(SessionService sessions, ChatService chat) {
        this.sessions = sessions;
        this.chat = chat;
        load();
    }

    private void load() {
        schedules.addAll(Store.loadSchedules());
        sync();
        log.info("定时任务加载完成：共 {} 个", schedules.size());
    }

    private void sync() {
        runner.sync(schedules, this::notifyFire);
    }

    private void notifyFire(ScheduledTask task) {
        if (onFire != null) onFire.accept(task);
    }

    /** 调度线程触发后，由 UI 层订阅并在 FX 线程调用 {@link #execute}。 */
    public void setOnFire(Consumer<ScheduledTask> onFire) {
        this.onFire = onFire;
    }

    /** 新建定时任务：创建专属会话并绑定、持久化、重新调度。 */
    public void add(ScheduledTask task) {
        task.conversationId = newScheduledConversation(task.content).id;
        schedules.add(task);
        Store.saveSchedules(schedules);
        sync();
        log.info("新增定时任务：id={}, cron={}", task.id, task.cron);
    }

    /** 返回当前定时任务列表快照，供 UI 展示。 */
    public List<ScheduledTask> all() {
        return new ArrayList<>(schedules);
    }

    /** 启用/停用某个定时任务，并持久化 + 重新调度。 */
    public void setEnabled(String id, boolean enabled) {
        for (ScheduledTask t : schedules) {
            if (t.id.equals(id)) {
                if (t.enabled != enabled) {
                    t.enabled = enabled;
                    Store.saveSchedules(schedules);
                    sync();
                }
                return;
            }
        }
    }

    /** 在 FX 线程执行：解析专属会话、选中并发送内容。 */
    public void execute(ScheduledTask task) {
        if (task == null || task.content == null || task.content.isBlank()) return;
        Conversation conv = resolveConversation(task);
        if (chat.isStreaming(conv.id)) {
            log.info("定时任务跳过（会话正在流式输出）：id={}", task.id);
            return;
        }
        // 后台并行执行：不切换当前会话，向专属会话直接发送
        chat.send(conv, task.content, null);
        log.info("定时任务触发发送：id={}, 会话={}", task.id, conv.id);
    }

    private Conversation resolveConversation(ScheduledTask task) {
        Conversation conv = sessions.findById(task.conversationId);
        if (conv == null) {
            conv = newScheduledConversation(task.content);
            task.conversationId = conv.id;
            Store.saveSchedules(schedules);
        }
        return conv;
    }

    private Conversation newScheduledConversation(String content) {
        Conversation conv = sessions.create(false);
        String flat = content == null ? "" : content.replace("\n", " ").trim();
        conv.title = "定时 · " + (flat.length() > 20 ? flat.substring(0, 20) + "…" : flat);
        sessions.persist();
        return conv;
    }

    public void shutdown() {
        runner.shutdown();
    }
}
