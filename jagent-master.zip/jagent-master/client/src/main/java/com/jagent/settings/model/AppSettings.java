package com.jagent.settings.model;

/**
 * 客户端设置（持久化到 data/settings.json）
 *
 * @author azhu
 * @date 2026-10-24
 */
public class AppSettings {
    public String serverUrl = "http://localhost:3210";
    /** Agent 工作目录（工具读写文件的范围） */
    public String cwd = "";
    /** default | acceptEdits | plan | bypassPermissions */
    public String permissionMode = "default";
    public String model = "";
    /** 模型来源：langchain4j（OpenAI 兼容直连，默认） | codebuddy（CodeBuddy CLI） */
    public String provider = "langchain4j";
    /** langchain4j / OpenAI 兼容接口配置 */
    public String llmBaseUrl = "";
    public String llmApiKey = "";
    public String llmModel = "";
    /** 嵌入模型名（文档问答/RAG 使用；需所选接口支持 embeddings） */
    public String llmEmbeddingModel = "text-embedding-3-small";
    /** 嵌入接口地址（留空则复用 llmBaseUrl） */
    public String llmEmbeddingBaseUrl = "";
    /** 嵌入 API Key（留空则复用 llmApiKey） */
    public String llmEmbeddingApiKey = "";
    public boolean autoStartServer = true;
    /** 界面主题：light | dark | blue | green | purple */
    public String theme = "light";
    /** 上次打开的工作区文件夹（文件树） */
    public String workspaceDir = "";
    /** 调试模式：全量打印模型输入输出日志 */
    public boolean debug = false;
    /** 发送给模型的历史轮数（按用户消息计），-1 表示不限制；默认最近 3 轮 */
    public int historyRounds = 3;
}
