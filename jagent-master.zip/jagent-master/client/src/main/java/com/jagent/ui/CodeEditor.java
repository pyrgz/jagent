package com.jagent.ui;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Collection;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 基于 RichTextFX 的轻量代码编辑器：行号、等宽字体、基础语法高亮、Ctrl/Cmd+S 保存。
 * 供文件查看器编辑文本 / 代码 / Markdown 文件。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class CodeEditor extends BorderPane {

    private static final Pattern HIGHLIGHT = Pattern.compile(
            "(?<COMMENT>//[^\n]*|/\\*(?:.|\\R)*?\\*/|#[^\n]*|<!--(?:.|\\R)*?-->)" +
            "|(?<STRING>\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*')" +
            "|(?<KEYWORD>\\b(?:public|private|protected|static|final|class|interface|enum|record|extends|implements|"
            + "void|int|long|double|float|boolean|char|byte|short|String|return|if|else|for|while|do|switch|case|"
            + "break|continue|new|this|super|try|catch|finally|throw|throws|import|package|null|true|false|var|"
            + "def|fn|function|const|let|import|from|as|lambda|async|await|print|elif|and|or|not)\\b)" +
            "|(?<NUMBER>\\b\\d+(?:\\.\\d+)?\\b)");

    private final CodeArea codeArea;
    private Path file;
    private boolean loading = false;
    private Runnable onDirtyChange;

    public CodeEditor() {
        codeArea = new CodeArea();
        codeArea.setParagraphGraphicFactory(LineNumberFactory.get(codeArea));
        codeArea.getStyleClass().add("code-editor");

        // Ctrl/Cmd + S 保存
        codeArea.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (e.isShortcutDown() && e.getCode() == KeyCode.S) {
                e.consume();
                save();
            }
        });

        // 文本变化 → 通知外部（脏标记）并防抖重新高亮
        codeArea.textProperty().addListener((obs, o, n) -> {
            if (!loading && onDirtyChange != null) onDirtyChange.run();
        });
        codeArea.multiPlainChanges()
                .successionEnds(Duration.ofMillis(300))
                .subscribe(ignore -> applyHighlighting());

        setCenter(codeArea);
    }

    /** 加载文件内容到编辑器。 */
    public void load(Path file, String content) {
        this.file = file;
        loading = true;
        codeArea.replaceText(content == null ? "" : content);
        loading = false;
        codeArea.moveTo(0);
        codeArea.getUndoManager().forgetHistory();
        applyHighlighting();
    }

    /** 保存到磁盘；成功返回 true。 */
    public boolean save() {
        if (file == null) return false;
        try {
            Files.writeString(file, codeArea.getText(), StandardCharsets.UTF_8);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void setOnDirtyChange(Runnable onDirtyChange) {
        this.onDirtyChange = onDirtyChange;
    }

    public CodeArea codeArea() {
        return codeArea;
    }

    private void applyHighlighting() {
        codeArea.setStyleSpans(0, computeHighlighting(codeArea.getText()));
    }

    private static StyleSpans<Collection<String>> computeHighlighting(String text) {
        Matcher m = HIGHLIGHT.matcher(text);
        StyleSpansBuilder<Collection<String>> builder = new StyleSpansBuilder<>();
        int last = 0;
        while (m.find()) {
            String style = m.group("COMMENT") != null ? "code-comment"
                    : m.group("STRING") != null ? "code-string"
                    : m.group("KEYWORD") != null ? "code-keyword"
                    : m.group("NUMBER") != null ? "code-number" : null;
            if (style == null) continue;
            builder.add(Collections.emptyList(), m.start() - last);
            builder.add(Collections.singleton(style), m.end() - m.start());
            last = m.end();
        }
        builder.add(Collections.emptyList(), text.length() - last);
        return builder.create();
    }
}
