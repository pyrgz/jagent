package com.jagent;

/**
 * 启动器。Main 不继承 Application，
 * 以便在仅 classpath（无 module-info）方式下也能正常启动 JavaFX。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class Main {
    public static void main(String[] args) {
        // macOS：在 AWT/JavaFX 工具包初始化前设置应用名，
        // 避免顶部系统菜单栏显示为启动类名（"Main"）或 "java"。
        System.setProperty("apple.awt.application.name", "jagent");
        System.setProperty("com.apple.mrj.application.apple.menu.about.name", "jagent");
        App.main(args);
    }
}
