package com.jagent.chat.tool;

import java.nio.file.Path;
import java.util.List;

/**
 * 组装默认工具集，供后端在每次会话中构建可调用工具。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class ToolKit {

    private ToolKit() {}

    /** 返回工作目录为 {@code cwd} 的默认工具列表。 */
    public static List<Tool> defaults(Path cwd) {
        return List.of(
                new ReadTool(cwd),
                new WriteTool(cwd),
                new BashTool(cwd),
                new GlobTool(cwd),
                new GrepTool(cwd));
    }
}
