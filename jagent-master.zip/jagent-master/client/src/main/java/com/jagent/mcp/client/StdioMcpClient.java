package com.jagent.mcp.client;

import com.jagent.mcp.model.McpServerConfig;
import com.jagent.mcp.model.McpToolDef;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;

/**
 * stdio 传输的 MCP 客户端：启动本地子进程，通过 stdin/stdout 收发换行分隔的 JSON-RPC 消息。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class StdioMcpClient implements McpClient {

    private static final Logger log = LogManager.getLogger(StdioMcpClient.class);

    private final String name;
    private final Process process;
    private final BufferedWriter stdin;
    private final long timeoutSeconds;
    private final Map<Long, CompletableFuture<JsonObject>> pending = new ConcurrentHashMap<>();
    private final AtomicLong ids = new AtomicLong();

    private volatile boolean closed;
    private volatile String serverInfo = "";

    public StdioMcpClient(String name, McpServerConfig config) throws IOException {
        this.name = name;
        this.timeoutSeconds = config.timeoutSeconds > 0 ? config.timeoutSeconds : 60;

        List<String> command = new ArrayList<>();
        command.add(config.command);
        if (config.args != null) command.addAll(config.args);

        ProcessBuilder pb = new ProcessBuilder(command);
        if (config.env != null && !config.env.isEmpty()) pb.environment().putAll(config.env);
        pb.redirectErrorStream(false);
        this.process = pb.start();
        this.stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));

        Thread.ofVirtual().name("mcp-" + name + "-stdout").start(this::readLoop);
        Thread.ofVirtual().name("mcp-" + name + "-stderr").start(this::errorLoop);
    }

    @Override
    public void initialize() throws Exception {
        JsonObject result = request("initialize", JsonRpc.initializeParams());
        if (result.has("serverInfo") && result.get("serverInfo").isJsonObject()) {
            JsonObject info = result.getAsJsonObject("serverInfo");
            String n = str(info, "name");
            String v = str(info, "version");
            serverInfo = (n == null || n.isBlank() ? name : n) + (v == null || v.isBlank() ? "" : " " + v);
        } else {
            serverInfo = name;
        }
        writeLine(JsonRpc.notification("notifications/initialized", null).toString());
        log.info("MCP[{}] 初始化完成：{}", name, serverInfo);
    }

    @Override
    public List<McpToolDef> listTools() throws Exception {
        List<McpToolDef> tools = new ArrayList<>();
        String cursor = null;
        do {
            JsonObject params = new JsonObject();
            if (cursor != null && !cursor.isBlank()) params.addProperty("cursor", cursor);
            JsonObject result = request("tools/list", params);
            JsonArray arr = result.has("tools") && result.get("tools").isJsonArray()
                    ? result.getAsJsonArray("tools") : new JsonArray();
            for (JsonElement el : arr) {
                if (!el.isJsonObject()) continue;
                JsonObject tool = el.getAsJsonObject();
                String toolName = str(tool, "name");
                if (toolName == null || toolName.isBlank()) continue;
                JsonObject schema = tool.has("inputSchema") && tool.get("inputSchema").isJsonObject()
                        ? tool.getAsJsonObject("inputSchema") : new JsonObject();
                tools.add(new McpToolDef(toolName, str(tool, "description"), schema));
            }
            cursor = str(result, "nextCursor");
        } while (cursor != null && !cursor.isBlank());
        return tools;
    }

    @Override
    public JsonObject callTool(String toolName, JsonObject arguments) throws Exception {
        JsonObject params = new JsonObject();
        params.addProperty("name", toolName);
        params.add("arguments", arguments == null ? new JsonObject() : arguments);
        return request("tools/call", params);
    }

    @Override
    public String serverInfo() {
        return serverInfo == null || serverInfo.isBlank() ? name : serverInfo;
    }

    @Override
    public void close() {
        if (closed) return;
        closed = true;
        failPending("MCP 服务已关闭：" + name);
        try {
            stdin.close();
        } catch (IOException ignored) {
        }
        process.descendants().forEach(ProcessHandle::destroy);
        process.destroy();
    }

    // ---- internals ----

    private JsonObject request(String method, JsonObject params) throws Exception {
        if (closed) throw new McpException("MCP 服务已关闭：" + name);
        long id = ids.incrementAndGet();
        JsonObject request = JsonRpc.request(id, method, params);
        CompletableFuture<JsonObject> future = new CompletableFuture<>();
        pending.put(id, future);
        try {
            writeLine(request.toString());
            JsonObject response = future.get(timeoutSeconds, TimeUnit.SECONDS);
            return JsonRpc.resultOrThrow(response);
        } catch (TimeoutException e) {
            throw new McpException("MCP[" + name + "] 请求超时：" + method);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new McpException("MCP[" + name + "] 请求被中断：" + method);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause() == null ? e : e.getCause();
            throw new McpException("MCP[" + name + "] " + method + " 失败：" + cause.getMessage(), cause);
        } finally {
            pending.remove(id);
        }
    }

    private void writeLine(String line) throws IOException {
        synchronized (stdin) {
            stdin.write(line);
            stdin.newLine();
            stdin.flush();
        }
    }

    private void readLoop() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                try {
                    handleMessage(JsonParser.parseString(line).getAsJsonObject());
                } catch (Exception e) {
                    log.warn("MCP[{}] 无法解析消息：{}", name, abbreviate(line));
                }
            }
        } catch (IOException e) {
            if (!closed) log.warn("MCP[{}] 读取进程输出失败：{}", name, e.getMessage());
        } finally {
            failPending("MCP 服务已退出：" + name);
        }
    }

    private void errorLoop() {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) log.debug("MCP[{}] stderr: {}", name, line);
            }
        } catch (IOException ignored) {
        }
    }

    private void handleMessage(JsonObject msg) {
        JsonElement idEl = msg.get("id");
        if (idEl != null && !idEl.isJsonNull() && idEl.isJsonPrimitive()) {
            long id;
            try {
                id = idEl.getAsLong();
            } catch (Exception e) {
                return;
            }
            CompletableFuture<JsonObject> future = pending.remove(id);
            if (future != null) future.complete(msg);
            return;
        }
        // 服务端通知（如 notifications/tools/list_changed）：当前无需处理
        String method = str(msg, "method");
        if (method != null) log.debug("MCP[{}] 通知：{}", name, method);
    }

    private void failPending(String reason) {
        for (Long id : new ArrayList<>(pending.keySet())) {
            CompletableFuture<JsonObject> future = pending.remove(id);
            if (future != null) future.completeExceptionally(new McpException(reason));
        }
    }

    private static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
    }

    private static String abbreviate(String s) {
        return s.length() <= 300 ? s : s.substring(0, 300) + "…";
    }
}
