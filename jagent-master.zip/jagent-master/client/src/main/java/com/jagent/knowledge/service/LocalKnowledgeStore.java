package com.jagent.knowledge.service;

import com.jagent.store.Store;
import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.store.embedding.EmbeddingMatch;
import dev.langchain4j.store.embedding.EmbeddingSearchRequest;
import dev.langchain4j.store.embedding.filter.MetadataFilterBuilder;
import dev.langchain4j.store.embedding.inmemory.InMemoryEmbeddingStore;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 本地知识库向量存储：每个知识库一个 {@code InMemoryEmbeddingStore<TextSegment>}，
 * 序列化到 {@code vectors/<kbId>.json}（langchain4j 内置 Jackson 格式）。
 * 分块文本写入 {@code TextSegment.metadata} 的 {@code documentId}，删除单文档按该字段过滤。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class LocalKnowledgeStore implements KnowledgeStore {

    private static final Logger log = LogManager.getLogger(LocalKnowledgeStore.class);
    private static final String DOC_ID = "documentId";

    private final Path vectorsDir;
    private final Map<String, InMemoryEmbeddingStore<TextSegment>> loaded = new ConcurrentHashMap<>();

    public LocalKnowledgeStore() {
        this.vectorsDir = Store.dataDir().resolve("vectors");
        try {
            Files.createDirectories(vectorsDir);
        } catch (IOException e) {
            log.error("创建向量目录失败：{}", vectorsDir, e);
        }
    }

    private Path fileFor(String kbId) {
        return vectorsDir.resolve(kbId + ".json");
    }

    private synchronized InMemoryEmbeddingStore<TextSegment> storeFor(String kbId) {
        InMemoryEmbeddingStore<TextSegment> s = loaded.get(kbId);
        if (s != null) return s;
        Path f = fileFor(kbId);
        if (Files.exists(f)) {
            try {
                s = InMemoryEmbeddingStore.fromJson(Files.readString(f));
            } catch (Exception e) {
                log.warn("读取知识库向量文件失败，按空库处理：{}", f, e);
            }
        }
        if (s == null) s = new InMemoryEmbeddingStore<>();
        loaded.put(kbId, s);
        return s;
    }

    private void persist(String kbId, InMemoryEmbeddingStore<TextSegment> s) {
        Path target = fileFor(kbId);
        Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
        try {
            Files.writeString(tmp, s.serializeToJson());
            try {
                Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException atomicFail) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            log.error("保存知识库向量文件失败：{}", target, e);
        }
    }

    @Override
    public void addChunks(String kbId, String docId, List<Chunk> chunks) {
        InMemoryEmbeddingStore<TextSegment> s = storeFor(kbId);
        for (Chunk c : chunks) {
            Metadata meta = new Metadata().put(DOC_ID, docId);
            s.add(new Embedding(c.vector), new TextSegment(c.text, meta));
        }
        persist(kbId, s);
    }

    @Override
    public void removeDocument(String kbId, String docId) {
        InMemoryEmbeddingStore<TextSegment> s = storeFor(kbId);
        s.removeAll(MetadataFilterBuilder.metadataKey(DOC_ID).isEqualTo(docId));
        persist(kbId, s);
    }

    @Override
    public void clearBase(String kbId) {
        InMemoryEmbeddingStore<TextSegment> s = storeFor(kbId);
        s.removeAll();
        persist(kbId, s);
    }

    @Override
    public void deleteBase(String kbId) {
        loaded.remove(kbId);
        try {
            Files.deleteIfExists(fileFor(kbId));
        } catch (IOException e) {
            log.error("删除知识库向量文件失败：{}", kbId, e);
        }
    }

    @Override
    public List<SearchHit> search(String kbId, float[] queryVector, int topK) {
        InMemoryEmbeddingStore<TextSegment> s = storeFor(kbId);
        EmbeddingSearchRequest req = new EmbeddingSearchRequest(new Embedding(queryVector), topK, 0.0, null);
        List<SearchHit> out = new ArrayList<>();
        for (EmbeddingMatch<TextSegment> m : s.search(req).matches()) {
            String docId = m.embedded().metadata().getString(DOC_ID);
            Double score = m.score();
            out.add(new SearchHit(docId == null ? "" : docId, m.embedded().text(), score == null ? 0.0 : score));
        }
        return out;
    }
}
