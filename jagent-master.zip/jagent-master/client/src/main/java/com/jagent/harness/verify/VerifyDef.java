package com.jagent.harness.verify;

/**
 * 验收规则配置（data/pipelines.json 中 pipeline 的 verify 项）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class VerifyDef {

    /** nonEmpty | contains | regex */
    public String type = "nonEmpty";
    /** 校验第几步的输出（从 1 开始） */
    public int step = 1;
    /** contains 的文本 / regex 的表达式 */
    public String value;
    /** 取反 */
    public boolean negate = false;
}
