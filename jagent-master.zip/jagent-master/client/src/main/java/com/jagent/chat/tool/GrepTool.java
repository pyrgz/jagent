package com.jagent.chat.tool;

import com.google.gson.JsonObject;
import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Stream;

/**
 * 按正则/字面量搜索文件内容。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class GrepTool extends BaseTool {

    public GrepTool(Path root) {
        super(root);
    }

    @Override
    public ToolSpecification specification() {
        return ToolSpecification.builder()
                .name("Grep")
                .description("在工作目录中搜索文件内容，返回 文件名:行号:内容。")
                .parameters(JsonObjectSchema.builder()
                        .addStringProperty("pattern", "要搜索的文本或正则表达式")
                        .addStringProperty("path", "文件或目录（可选，默认工作目录）")
                        .required("pattern")
                        .build())
                .build();
    }

    @Override
    public String execute(String argumentsJson) throws Exception {
        JsonObject a = args(argumentsJson);
        String pattern = arg(a, "pattern");
        if (pattern == null || pattern.isBlank()) return "错误：缺少 pattern 参数";
        String base = arg(a, "path");
        Path start = base == null || base.isBlank() ? root : resolve(base);

        Pattern regex = compilePattern(pattern);

        List<String> hits = new ArrayList<>();
        if (Files.isRegularFile(start)) {
            grepFile(start, regex, hits);
        } else if (Files.isDirectory(start)) {
            try (Stream<Path> stream = Files.walk(start)) {
                stream.filter(Files::isRegularFile).limit(2000).forEach(p -> grepFile(p, regex, hits));
            }
        }
        return hits.isEmpty() ? "未找到匹配内容" : String.join("\n", hits);
    }

    private static Pattern compilePattern(String pattern) {
        try {
            return Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
        } catch (PatternSyntaxException e) {
            return Pattern.compile(Pattern.quote(pattern), Pattern.CASE_INSENSITIVE);
        }
    }

    private void grepFile(Path file, Pattern regex, List<String> hits) {
        try {
            List<String> lines = Files.readAllLines(file);
            for (int i = 0; i < lines.size() && hits.size() < 200; i++) {
                if (regex.matcher(lines.get(i)).find()) {
                    hits.add(file.getFileName() + ":" + (i + 1) + ": " + lines.get(i).strip());
                }
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean requiresPermission() {
        return false;
    }
}
