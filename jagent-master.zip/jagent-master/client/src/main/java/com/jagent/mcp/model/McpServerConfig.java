package com.jagent.mcp.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 单个 MCP Server 配置（data/mcp.json 中的一项）。
 *
 * <p>配置 {@code command}/{@code args}/{@code env} 时使用 stdio 本地进程传输；
 * 配置 {@code url} 时使用 Streamable HTTP 传输。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class McpServerConfig {

    /** stdio：启动命令，如 npx / uvx / node */
    public String command;
    /** stdio：命令参数 */
    public List<String> args = new ArrayList<>();
    /** stdio：附加环境变量 */
    public Map<String, String> env = new LinkedHashMap<>();

    /** HTTP：MCP 服务地址（Streamable HTTP 端点） */
    public String url;
    /** HTTP：附加请求头（如 Authorization） */
    public Map<String, String> headers = new LinkedHashMap<>();

    /** 是否启用 */
    public boolean enabled = true;
    /** 单次请求超时（秒） */
    public int timeoutSeconds = 60;
}
