package com.jagent.harness.example;

import com.jagent.harness.Harness;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

/**
 * Harness 应用示例：统计工作目录的文件数量、目录数量、总大小与类型分布。
 *
 * <p>在对话框中执行：</p>
 * <pre>
 * /harness stats
 * /harness stats src/main/java
 * </pre>
 *
 * <p>演示了「业务 harness + /harness 命令」的完整接入方式：实现 {@link Harness#execute(String)}
 * 后由 ServiceAssembler 注册，即可从对话框直接调用，无需改动 UI 或 ChatService。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ProjectStatsHarness implements Harness {

    /** 构建产物 / 依赖目录不参与统计。 */
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".idea", ".gradle", "node_modules", "target", "out", "build", "dist");

    /** 防止超大目录导致长时间扫描。 */
    private static final int MAX_FILES = 200_000;

    private final Supplier<String> rootSupplier;

    public ProjectStatsHarness(Supplier<String> rootSupplier) {
        this.rootSupplier = rootSupplier;
    }

    @Override
    public String id() {
        return "stats";
    }

    @Override
    public String name() {
        return "项目统计";
    }

    @Override
    public String execute(String input) {
        Path root = resolveRoot();
        if (root == null) {
            return "工作目录未配置或不存在，无法统计。";
        }
        Path target = root;
        if (input != null && !input.isBlank()) {
            Path candidate = root.resolve(input.trim()).normalize();
            if (!candidate.startsWith(root)) {
                return "路径必须位于工作目录内：" + root;
            }
            if (!Files.exists(candidate)) {
                return "路径不存在：" + candidate;
            }
            target = candidate;
        }

        long[] files = {0};
        long[] dirs = {0};
        long[] bytes = {0};
        boolean[] truncated = {false};
        Map<String, Integer> extensions = new HashMap<>();
        final Path scanRoot = target;

        try {
            Files.walkFileTree(scanRoot, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(scanRoot) && SKIP_DIRS.contains(dir.getFileName().toString())) {
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                    if (!dir.equals(scanRoot)) dirs[0]++;
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (++files[0] > MAX_FILES) {
                        truncated[0] = true;
                        return FileVisitResult.TERMINATE;
                    }
                    bytes[0] += attrs.size();
                    extensions.merge(extensionOf(file.getFileName().toString()), 1, Integer::sum);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) {
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            return "统计失败：" + (e.getMessage() == null ? e.toString() : e.getMessage());
        }

        StringBuilder sb = new StringBuilder();
        sb.append("项目统计：").append(target).append('\n');
        sb.append("- 文件：").append(files[0]).append(" 个\n");
        sb.append("- 目录：").append(dirs[0]).append(" 个\n");
        sb.append("- 总大小：").append(formatSize(bytes[0])).append('\n');
        sb.append("- 类型 Top：").append(topExtensions(extensions, 6));
        if (truncated[0]) sb.append("\n- 提示：文件数超过上限，结果已截断");
        return sb.toString();
    }

    private Path resolveRoot() {
        String cwd = rootSupplier == null ? null : rootSupplier.get();
        Path root = (cwd == null || cwd.isBlank()) ? Path.of(System.getProperty("user.dir")) : Path.of(cwd);
        try {
            return Files.isDirectory(root) ? root.toAbsolutePath().normalize() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static String extensionOf(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 || dot == name.length() - 1 ? "无扩展名" : name.substring(dot).toLowerCase();
    }

    private static String topExtensions(Map<String, Integer> extensions, int limit) {
        if (extensions.isEmpty()) return "无";
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(extensions.entrySet());
        entries.sort(Comparator.<Map.Entry<String, Integer>>comparingInt(Map.Entry::getValue)
                .reversed()
                .thenComparing(Map.Entry::getKey));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < entries.size() && i < limit; i++) {
            if (i > 0) sb.append("、");
            sb.append(entries.get(i).getKey()).append(' ').append(entries.get(i).getValue());
        }
        return sb.toString();
    }

    private static String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format("%.1f KB", kb);
        double mb = kb / 1024.0;
        if (mb < 1024) return String.format("%.1f MB", mb);
        return String.format("%.2f GB", mb / 1024.0);
    }
}
