package com.jagent;

import com.jagent.chat.service.ChatBackend;
import com.jagent.chat.service.ChatService;
import com.jagent.chat.service.CodeBuddyBackend;
import com.jagent.chat.service.Langchain4jBackend;
import com.jagent.chat.service.SessionService;
import com.jagent.connectivity.service.ConnectivityService;
import com.jagent.harness.HarnessPipelineService;
import com.jagent.harness.HarnessRegistry;
import com.jagent.harness.example.ProjectDailyReportHarness;
import com.jagent.harness.example.ProjectInspectionHarness;
import com.jagent.harness.example.ProjectStatsHarness;
import com.jagent.harness.example.ToolAgentHarness;
import com.jagent.harness.example.ToolChainHarness;
import com.jagent.jagent.service.JagentService;
import com.jagent.knowledge.service.KnowledgeService;
import com.jagent.knowledge.service.KnowledgeStore;
import com.jagent.knowledge.service.LocalKnowledgeStore;
import com.jagent.mcp.service.McpService;
import com.jagent.schedule.service.ScheduleService;
import com.jagent.settings.service.SettingsService;
import com.jagent.skill.service.SkillService;
import com.jagent.store.Store;
import com.jagent.workspace.service.WorkspaceService;

/**
 * 组装所有业务 service 并注册到 {@link HarnessRegistry}。
 * 供 {@code ChatController}（GUI）与 {@code HeadlessMain}（headless）共用，避免两处重复维护。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class ServiceAssembler {

    private ServiceAssembler() {}

    /** 组装结果：全部 service + 已注册的 harness 注册表。 */
    public static final class Services {
        public SettingsService settings;
        public SessionService sessions;
        public SkillService skills;
        public CodeBuddyBackend codebuddy;
        public Langchain4jBackend langchain4j;
        public McpService mcp;
        public KnowledgeStore knowledgeStore;
        public KnowledgeService knowledge;
        public ChatService chat;
        public ScheduleService schedule;
        public ConnectivityService connectivity;
        public WorkspaceService workspace;
        public JagentService jagent;
        public HarnessRegistry harnesses;
    }

    public static Services assemble() {
        Services s = new Services();
        s.settings = new SettingsService();
        s.sessions = new SessionService(s.settings);
        s.skills = new SkillService(s.settings);
        s.codebuddy = new CodeBuddyBackend(s.settings.settings().serverUrl);
        s.mcp = new McpService();
        s.langchain4j = new Langchain4jBackend(s.settings.settings(), s.mcp);
        s.knowledgeStore = new LocalKnowledgeStore();
        s.knowledge = new KnowledgeService(s.langchain4j, s.settings.settings(), s.knowledgeStore);
        s.jagent = new JagentService(s.settings);
        ChatBackend initialBackend = "langchain4j".equals(s.settings.settings().provider) ? s.langchain4j : s.codebuddy;
        s.chat = new ChatService(initialBackend, s.sessions, s.settings, s.skills, s.jagent);
        s.schedule = new ScheduleService(s.sessions, s.chat);
        s.connectivity = new ConnectivityService(s.codebuddy, s.settings);
        s.workspace = new WorkspaceService(s.settings);

        // 注册业务 harness（底层先注册，逆序关闭时上层先停、底层最后保存）
        s.harnesses = new HarnessRegistry();
        // Harness 应用示例：/harness stats
        s.harnesses.register(new ProjectStatsHarness(() -> s.settings.settings().cwd));
        // 业务场景示例：/harness report [天数]
        s.harnesses.register(new ProjectDailyReportHarness(() -> s.settings.settings().cwd));
        // 多工具编排示例：/harness tools [glob]
        s.harnesses.register(new ToolChainHarness(() -> s.settings.settings().cwd));
        // 大模型 + 内置工具 + MCP 工具：/harness agent <任务>
        s.harnesses.register(new ToolAgentHarness(s.langchain4j, s.settings));
        // Harness 编排示例：/harness inspect
        s.harnesses.register(new ProjectInspectionHarness(
                () -> s.settings.settings().cwd, s.skills, s.mcp));
        // 配置文件驱动编排：/harness pipeline <名称>
        s.harnesses.register(new HarnessPipelineService(
                s.harnesses, Store.dataDir().resolve("pipelines.json")));
        s.harnesses.register(s.mcp);
        s.harnesses.register(s.settings);
        s.harnesses.register(s.sessions);
        s.harnesses.register(s.skills);
        s.harnesses.register(s.jagent);
        s.harnesses.register(s.knowledge);
        s.harnesses.register(s.workspace);
        s.harnesses.register(s.chat);
        s.harnesses.register(s.schedule);
        s.harnesses.register(s.connectivity);
        return s;
    }
}
