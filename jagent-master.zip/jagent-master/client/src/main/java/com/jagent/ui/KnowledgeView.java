package com.jagent.ui;

import com.jagent.chat.service.ChatBackend;
import com.jagent.knowledge.model.KnowledgeBase;
import com.jagent.knowledge.model.KnowledgeDocument;
import com.jagent.knowledge.service.KnowledgeService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 知识库 / 文档问答面板：多知识库管理（新建/切换/删除）+ 文档入库（可删单文档）+ 提问流式作答。
 * 自成闭环，不占用主聊天单流状态机；订阅 {@link KnowledgeService} 的变更事件刷新。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class KnowledgeView {

    private final Stage owner;
    private final KnowledgeService knowledge;

    private final VBox root;
    private final ComboBox<KnowledgeBase> kbSelect;
    private final Label kbConfig;
    private final Label status;
    private final Label docTitle;
    private final ListView<KnowledgeDocument> docList;
    private final TextArea answer;
    private final TextField questionField;
    private final Button askBtn;
    private final Button addBtn;
    private final Button deleteBtn;

    private final StringBuilder answerBuffer = new StringBuilder();
    private boolean asking = false;
    private boolean adjusting = false;

    /** 提问历史（↑ 上一条 / ↓ 下一条） */
    private final List<String> history = new ArrayList<>();
    private int historyIndex = -1;
    private String draft = "";
    private boolean navigating = false;

    public KnowledgeView(Stage owner, KnowledgeService knowledge) {
        this.owner = owner;
        this.knowledge = knowledge;

        // ---------- 头部 ----------
        kbSelect = new ComboBox<>();
        kbSelect.setPrefWidth(220);
        kbSelect.setButtonCell(kbCell());
        kbSelect.setCellFactory(lv -> kbCell());
        kbSelect.valueProperty().addListener((obs, o, n) -> {
            if (adjusting) return;
            if (n != null) knowledge.selectBase(n.id);
        });

        kbConfig = new Label();
        kbConfig.getStyleClass().add("kb-config");

        Button newBtn = new Button("新建");
        newBtn.getStyleClass().add("btn-ghost");
        newBtn.setOnAction(e -> createBase());

        deleteBtn = new Button("删除");
        deleteBtn.getStyleClass().add("btn-ghost");
        deleteBtn.setOnAction(e -> deleteBase());

        addBtn = new Button("添加文档");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setOnAction(e -> addDocuments());

        Region sp1 = new Region();
        HBox.setHgrow(sp1, Priority.ALWAYS);
        HBox header = new HBox(8, kbSelect, kbConfig, sp1, newBtn, deleteBtn, addBtn);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("kb-header");

        // ---------- 状态 ----------
        status = new Label("选择或新建知识库后，添加文档即可提问。");
        status.getStyleClass().add("kb-status");
        status.setWrapText(true);

        // ---------- 左栏：文档列表 ----------
        docTitle = new Label("文档 · 0");
        docTitle.getStyleClass().add("kb-title");

        docList = new ListView<>();
        docList.getStyleClass().add("kb-list");
        docList.setCellFactory(lv -> new DocCell());

        VBox left = new VBox(8, docTitle, docList);
        left.getStyleClass().add("kb-col-docs");
        left.setPrefWidth(320);
        VBox.setVgrow(docList, Priority.ALWAYS);

        // ---------- 右栏：回答 + 提问 ----------
        answer = new TextArea();
        answer.setEditable(false);
        answer.setWrapText(true);
        answer.setPromptText("答案将显示在这里…");
        answer.getStyleClass().add("kb-answer");
        VBox.setVgrow(answer, Priority.ALWAYS);

        questionField = new TextField();
        questionField.setPromptText("基于当前知识库的文档提问…");
        questionField.getStyleClass().add("kb-question");
        questionField.setOnAction(e -> ask());
        // 历史导航：↑ 上一条 / ↓ 下一条
        questionField.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.UP) {
                e.consume();
                navigateHistory(true);
            } else if (e.getCode() == KeyCode.DOWN) {
                e.consume();
                navigateHistory(false);
            }
        });
        // 手动输入时退出历史浏览
        questionField.textProperty().addListener((obs, o, n) -> {
            if (!navigating) historyIndex = -1;
        });
        HBox.setHgrow(questionField, Priority.ALWAYS);

        askBtn = new Button("提问");
        askBtn.getStyleClass().add("btn-primary");
        askBtn.setOnAction(e -> ask());

        HBox askRow = new HBox(8, questionField, askBtn);
        askRow.getStyleClass().add("kb-ask-row");
        askRow.setAlignment(Pos.CENTER_LEFT);

        VBox right = new VBox(10, answer, askRow);
        HBox.setHgrow(right, Priority.ALWAYS);
        VBox.setVgrow(answer, Priority.ALWAYS);

        HBox main = new HBox(14, left, right);
        VBox.setVgrow(main, Priority.ALWAYS);

        root = new VBox(12, header, status, main);
        root.getStyleClass().add("kb-root");
        root.setPadding(new Insets(18, 22, 18, 22));
        VBox.setVgrow(main, Priority.ALWAYS);

        knowledge.setListener(new KnowledgeService.Listener() {
            @Override
            public void onChanged() {
                Platform.runLater(KnowledgeView.this::refresh);
            }

            @Override
            public void onError(String message) {
                Platform.runLater(() -> setStatus("出错了：" + (message == null ? "未知错误" : message)));
            }
        });

        refresh();
    }

    public Node node() {
        return root;
    }

    private ListCell<KnowledgeBase> kbCell() {
        return new ListCell<>() {
            @Override
            protected void updateItem(KnowledgeBase b, boolean empty) {
                super.updateItem(b, empty);
                setText(empty || b == null ? null : b.name + "（" + b.documents.size() + " 文档）");
            }
        };
    }

    private void refresh() {
        List<KnowledgeBase> bases = knowledge.bases();
        KnowledgeBase current = knowledge.current();

        adjusting = true;
        kbSelect.getItems().setAll(bases);
        kbSelect.setValue(current);
        adjusting = false;

        if (current != null) {
            kbConfig.setText("分块 " + current.chunkSize + " · 重叠 " + current.chunkOverlap
                    + (current.embeddingModel == null || current.embeddingModel.isBlank()
                    ? "" : " · 模型 " + current.embeddingModel));
            docList.getItems().setAll(knowledge.documents(current.id));
            docTitle.setText("文档 · " + current.documents.size());
            addBtn.setDisable(false);
            deleteBtn.setDisable(false);
        } else {
            kbConfig.setText("");
            docList.getItems().clear();
            docTitle.setText("文档 · 0");
            addBtn.setDisable(true);
            deleteBtn.setDisable(true);
        }
    }

    private void createBase() {
        Dialogs.showKnowledgeBase(owner, "新知识库", 300, 30, (name, size, overlap) ->
                knowledge.createBase(name, size, overlap));
    }

    private void deleteBase() {
        KnowledgeBase b = knowledge.current();
        if (b == null) return;
        if (showConfirm("删除知识库", "确定删除「" + b.name + "」吗？其所有文档与索引将一并删除。")) {
            knowledge.deleteBase(b.id);
            answer.clear();
            setStatus("已删除知识库。");
        }
    }

    private void addDocuments() {
        KnowledgeBase b = knowledge.current();
        if (b == null) return;
        final String baseId = b.id;

        FileChooser chooser = new FileChooser();
        chooser.setTitle("选择要加入知识库的文档");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("文本 / 代码文件", "*.txt", "*.md", "*.markdown",
                        "*.java", "*.js", "*.ts", "*.py", "*.json", "*.xml", "*.yml", "*.yaml",
                        "*.html", "*.css", "*.sql", "*.sh", "*.bat", "*.properties", "*.csv"),
                new FileChooser.ExtensionFilter("所有文件", "*.*"));
        List<File> files = chooser.showOpenMultipleDialog(owner);
        if (files == null || files.isEmpty()) return;

        setStatus("正在建立索引…");
        Thread.ofVirtual().name("kb-index").start(() -> {
            int indexed = 0;
            int skipped = 0;
            String firstError = null;
            for (File f : files) {
                try {
                    int n = knowledge.addDocument(baseId, f.toPath());
                    if (n >= 0) indexed++;
                    else skipped++;
                } catch (Exception e) {
                    skipped++;
                    if (firstError == null) {
                        firstError = e.getMessage() == null ? e.toString() : e.getMessage();
                    }
                }
            }
            final int ok = indexed;
            final int skip = skipped;
            final String err = firstError;
            Platform.runLater(() -> {
                refresh();
                StringBuilder sb = new StringBuilder("完成：已添加 " + ok + " 个文档");
                if (skip > 0) {
                    sb.append("，跳过 ").append(skip).append(" 个");
                    if (err != null && !err.isBlank()) sb.append("（").append(err).append("）");
                }
                sb.append("。");
                setStatus(sb.toString());
            });
        });
    }

    private void ask() {
        if (asking) return;
        if (knowledge.current() == null) return;
        String q = questionField.getText();
        if (q == null || q.isBlank()) return;
        recordHistory(q);

        asking = true;
        askBtn.setDisable(true);
        questionField.setDisable(true);
        answer.clear();
        answerBuffer.setLength(0);
        setStatus("正在检索文档并生成回答…");

        Thread.ofVirtual().name("kb-ask").start(() -> knowledge.ask(q, new ChatBackend.StreamListener() {
            @Override
            public void onText(String content) {
                if (content == null || content.isEmpty()) return;
                answerBuffer.append(content);
                Platform.runLater(() -> answer.setText(answerBuffer.toString()));
            }

            @Override
            public void onError(String message) {
                Platform.runLater(() -> {
                    setStatus("出错了：" + (message == null ? "未知错误" : message));
                    finishAsk();
                });
            }

            @Override
            public void onDone(com.google.gson.JsonObject data) {
                Platform.runLater(() -> {
                    setStatus("回答完成。");
                    finishAsk();
                });
            }
        }));
    }

    private void finishAsk() {
        asking = false;
        askBtn.setDisable(false);
        questionField.setDisable(false);
    }

    // ================= 提问历史（↑ 上一条 / ↓ 下一条） =================

    private void recordHistory(String q) {
        if (history.isEmpty() || !history.get(history.size() - 1).equals(q)) {
            history.add(q);
            if (history.size() > 100) history.remove(0);
        }
        historyIndex = -1;
        draft = "";
    }

    private void navigateHistory(boolean up) {
        if (history.isEmpty()) return;
        if (up) {
            if (historyIndex == -1) {
                draft = questionField.getText();
                historyIndex = history.size() - 1;
            } else if (historyIndex > 0) {
                historyIndex--;
            } else {
                return; // 已是最早一条
            }
            setHistoryText(history.get(historyIndex));
        } else {
            if (historyIndex == -1) return; // 已在草稿
            historyIndex++;
            if (historyIndex >= history.size()) {
                historyIndex = -1;
                setHistoryText(draft);
            } else {
                setHistoryText(history.get(historyIndex));
            }
        }
    }

    private void setHistoryText(String text) {
        navigating = true;
        questionField.setText(text);
        navigating = false;
        questionField.positionCaret(questionField.getLength());
        questionField.requestFocus();
    }

    private boolean showConfirm(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, message, ButtonType.CANCEL, ButtonType.OK);
        alert.initOwner(owner);
        alert.setTitle(title);
        alert.setHeaderText(null);
        return alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK;
    }

    private void setStatus(String text) {
        status.setText(text);
    }

    // ---------------- 文档条目 ----------------

    private class DocCell extends ListCell<KnowledgeDocument> {
        private final HBox card;
        private final Label name;
        private final Label meta;
        private final StackPane del;

        DocCell() {
            name = new Label();
            name.getStyleClass().add("kb-doc-name");
            meta = new Label();
            meta.getStyleClass().add("kb-doc-meta");
            VBox texts = new VBox(2, name, meta);

            del = new StackPane(Icons.stroke(Icons.TRASH, 14, Color.web("#98A0AB")));
            del.getStyleClass().add("conv-del");
            del.setPrefSize(24, 24);
            del.setMinSize(24, 24);
            del.setMaxSize(24, 24);
            del.setOnMouseClicked(e -> {
                KnowledgeDocument d = getItem();
                if (d != null) {
                    e.consume();
                    removeDocument(d);
                }
            });

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            card = new HBox(6, texts, spacer, del);
            card.setAlignment(Pos.CENTER_LEFT);
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }

        @Override
        protected void updateItem(KnowledgeDocument d, boolean empty) {
            super.updateItem(d, empty);
            if (empty || d == null) {
                setGraphic(null);
            } else {
                name.setText(d.name);
                meta.setText(d.chunkCount + " 块");
                setGraphic(card);
            }
        }
    }

    private void removeDocument(KnowledgeDocument d) {
        KnowledgeBase b = knowledge.current();
        if (b == null) return;
        if (showConfirm("删除文档", "确定删除「" + d.name + "」吗？")) {
            knowledge.removeDocument(b.id, d.id);
        }
    }
}
