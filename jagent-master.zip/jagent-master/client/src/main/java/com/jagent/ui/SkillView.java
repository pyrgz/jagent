package com.jagent.ui;

import com.jagent.skill.model.Skill;
import com.jagent.skill.service.SkillService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.util.function.Consumer;

/**
 * 侧边栏技能面板：列出技能，支持加载/卸载、新建、编辑、删除。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class SkillView {

    private final SkillService skills;
    private final Consumer<Skill> onEdit;
    private final Consumer<Skill> onDelete;
    private final Runnable onNew;

    private final VBox root;
    private final ListView<Skill> list;

    public SkillView(SkillService skills, Consumer<Skill> onEdit, Consumer<Skill> onDelete, Runnable onNew) {
        this.skills = skills;
        this.onEdit = onEdit;
        this.onDelete = onDelete;
        this.onNew = onNew;

        Label title = new Label("技能");
        title.getStyleClass().add("skill-title");

        Button newBtn = new Button("新建");
        newBtn.getStyleClass().add("btn-ghost");
        newBtn.setPadding(new Insets(4, 8, 4, 8));
        newBtn.setOnAction(e -> { if (onNew != null) onNew.run(); });

        Button refreshBtn = new Button("刷新");
        refreshBtn.getStyleClass().add("btn-ghost");
        refreshBtn.setPadding(new Insets(4, 8, 4, 8));
        refreshBtn.setOnAction(e -> skills.refresh());

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox header = new HBox(8, title, sp, newBtn, refreshBtn);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("skill-header");

        list = new ListView<>();
        list.getStyleClass().add("skill-list");
        VBox.setVgrow(list, Priority.ALWAYS);
        list.setCellFactory(lv -> new SkillCell(skills, onEdit, onDelete));

        root = new VBox(header, list);
        root.getStyleClass().add("sidebar");
        root.setPadding(new Insets(12, 8, 12, 8));

        skills.setListener(new SkillService.Listener() {
            @Override
            public void onChanged() {
                Platform.runLater(SkillView.this::refresh);
            }
        });
        refresh();
    }

    public Node node() {
        return root;
    }

    public void refresh() {
        list.getItems().setAll(skills.all());
    }

    // ---------------- 单元格 ----------------

    private static class SkillCell extends ListCell<Skill> {
        private final SkillService skills;
        private final Consumer<Skill> onEdit;
        private final Consumer<Skill> onDelete;

        private final Label name = new Label();
        private final Label src = new Label();
        private final Label desc = new Label();
        private final CheckBox toggle = new CheckBox("加载");
        private final VBox card;

        SkillCell(SkillService skills, Consumer<Skill> onEdit, Consumer<Skill> onDelete) {
            this.skills = skills;
            this.onEdit = onEdit;
            this.onDelete = onDelete;

            name.getStyleClass().add("skill-name");
            src.getStyleClass().add("skill-src");
            desc.getStyleClass().add("skill-desc");
            desc.setWrapText(true);
            toggle.getStyleClass().add("skill-toggle");
            toggle.setOnAction(e -> {
                Skill s = getItem();
                if (s != null) skills.setLoaded(s, toggle.isSelected());
            });

            Region sp1 = new Region();
            HBox.setHgrow(sp1, Priority.ALWAYS);
            HBox top = new HBox(6, name, src);
            top.setAlignment(Pos.CENTER_LEFT);

            Button edit = new Button("编辑");
            edit.getStyleClass().add("btn-ghost");
            edit.setPadding(new Insets(2, 8, 2, 8));
            edit.setOnAction(e -> {
                Skill s = getItem();
                if (s != null && onEdit != null) onEdit.accept(s);
            });

            StackPane del = new StackPane(Icons.stroke(Icons.TRASH, 14, Color.web("#98A0AB")));
            del.getStyleClass().add("conv-del");
            del.setPrefSize(24, 24);
            del.setMinSize(24, 24);
            del.setMaxSize(24, 24);
            del.setOnMouseClicked(e -> {
                Skill s = getItem();
                if (s != null && onDelete != null) {
                    e.consume();
                    onDelete.accept(s);
                }
            });

            Region sp2 = new Region();
            HBox.setHgrow(sp2, Priority.ALWAYS);
            HBox actions = new HBox(6, toggle, sp2, edit, del);
            actions.setAlignment(Pos.CENTER_LEFT);

            card = new VBox(4, top, desc, actions);
            card.getStyleClass().add("skill-card");
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }

        @Override
        protected void updateItem(Skill s, boolean empty) {
            super.updateItem(s, empty);
            if (empty || s == null) {
                setGraphic(null);
                return;
            }
            name.setText(s.name == null || s.name.isBlank() ? "未命名技能" : s.name);
            src.setText("project".equals(s.source) ? "项目" : "用户");
            String d = (s.description == null || s.description.isBlank())
                    ? (s.hasScripts ? "含脚本" : "无描述")
                    : s.description.trim();
            desc.setText(d);
            toggle.setSelected(s.loaded);
            setGraphic(card);
        }
    }
}
