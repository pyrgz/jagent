package com.jagent.jagent.service;

import com.jagent.harness.Harness;
import com.jagent.settings.service.SettingsService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * 工作空间下的 jagent.md 指令文件（类似 claude.md）：作为每次与大模型交互的
 * 规则/规范/约束自动注入系统提示词。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class JagentService implements Harness {

    @Override
    public String id() { return "jagent"; }

    @Override
    public String name() { return "指令"; }

    private static final Logger log = LogManager.getLogger(JagentService.class);
    private static final String FILE_NAME = "jagent.md";

    private static final String TEMPLATE = """
            # 项目指令（jagent.md）

            在此文件中定义每次与大模型交互时需要遵守的规则、规范或约束。
            本文件会在每次对话时自动注入系统提示词并立即生效。

            ## 示例规则

            - 编码语言：Java 21
            - 代码保持简洁、可维护、高内聚
            - 遵循项目现有命名与目录规范
            """;

    private final SettingsService settings;

    public JagentService(SettingsService settings) {
        this.settings = settings;
    }

    /** 在指定目录下生成 jagent.md（已存在则不覆盖），返回文件路径。 */
    public Path generate(Path dir) {
        Path p = dir.resolve(FILE_NAME);
        if (!Files.isRegularFile(p)) {
            try {
                Files.createDirectories(dir);
                Files.writeString(p, TEMPLATE, StandardCharsets.UTF_8);
                log.info("生成 jagent.md：{}", p);
            } catch (IOException e) {
                log.error("生成 jagent.md 失败：{}", p, e);
            }
        }
        return p;
    }

    /** 读取 jagent.md 内容；工作空间优先，其次安装目录，均无则 null。 */
    public String rules() {
        for (Path p : candidatePaths()) {
            if (!Files.isRegularFile(p)) continue;
            try {
                String text = Files.readString(p, StandardCharsets.UTF_8);
                if (text != null && !text.isBlank()) return text.trim();
            } catch (IOException e) {
                log.warn("读取 jagent.md 失败：{}", p, e);
            }
        }
        return null;
    }

    private List<Path> candidatePaths() {
        return List.of(workspacePath(), installPath());
    }

    private Path workspacePath() {
        String ws = settings.settings().workspaceDir;
        if (ws == null || ws.isBlank()) ws = settings.settings().cwd;
        if (ws == null || ws.isBlank()) ws = System.getProperty("user.dir");
        return Path.of(ws).resolve(FILE_NAME);
    }

    private Path installPath() {
        return Path.of(System.getProperty("user.home"), ".jagent", FILE_NAME);
    }
}
