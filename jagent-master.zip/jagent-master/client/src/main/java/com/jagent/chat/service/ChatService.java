package com.jagent.chat.service;

import com.jagent.common.util.ModelLog;
import com.jagent.harness.Harness;
import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.ChatRequest;
import com.jagent.chat.model.Conversation;
import com.jagent.chat.model.ToolCall;
import com.jagent.jagent.service.JagentService;
import com.jagent.settings.service.SettingsService;
import com.jagent.skill.service.SkillService;
import com.jagent.store.Store;
import com.google.gson.JsonObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;

/**
 * 聊天/流式发送状态机（多会话并行，每会话一个活跃流）。纯 Java，无 UI 依赖。
 * 通过 {@link Listener} 向 UI 层发出事件；除 onUserMessage/onAssistantMessage/onTitleChanged/onStreamingChanged
 * 在调用线程（send 的调用方）同步触发外，其余事件在内部单线程 executor 上触发，UI 层需自行切换线程。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ChatService implements Harness {

    @Override
    public String id() { return "chat"; }

    @Override
    public String name() { return "聊天"; }

    public interface Listener {
        default void onUserMessage(Conversation conv, ChatMessage msg) {}
        default void onAssistantMessage(Conversation conv, ChatMessage msg) {}
        default void onTitleChanged(Conversation conv) {}
        default void onTextUpdated(Conversation conv, ChatMessage msg) {}
        default void onToolAdded(Conversation conv, ChatMessage msg, ToolCall tool) {}
        default void onToolUpdated(Conversation conv, ChatMessage msg, ToolCall tool) {}
        default void onPermissionRequest(String requestId, String toolName, String inputJson,
                                         BiConsumer<String, Boolean> responder) {}
        default void onStreamingChanged(Conversation conv, boolean streaming) {}
        default void onFinished(Conversation conv, ChatMessage msg) {}
        default void onAuthRequired() {}
    }

    private static final Logger log = LogManager.getLogger(ChatService.class);

    private volatile ChatBackend backend;
    private final SessionService sessions;
    private final SettingsService settings;
    private final SkillService skills;
    private final JagentService jagent;
    private Listener listener = new Listener() {};

    /** 每个会话的活跃流，key 为会话 id（同一会话同时最多一个流）。 */
    private final Map<String, Stream> streams = new ConcurrentHashMap<>();

    private final ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "chat-service");
        t.setDaemon(true);
        return t;
    });

    public ChatService(ChatBackend backend, SessionService sessions, SettingsService settings, SkillService skills,
                       JagentService jagent) {
        this.backend = backend;
        this.sessions = sessions;
        this.settings = settings;
        this.skills = skills;
        this.jagent = jagent;
    }

    public void setListener(Listener listener) {
        this.listener = listener == null ? new Listener() {} : listener;
    }

    /** 切换聊天后端（CodeBuddy 桥接 / langchain4j 直连）。 */
    public void setBackend(ChatBackend backend) {
        this.backend = backend;
    }

    public ChatBackend backend() {
        return backend;
    }

    /** 是否存在任意活跃流。 */
    public boolean isStreaming() {
        return !streams.isEmpty();
    }

    /** 指定会话是否正在流式输出。 */
    public boolean isStreaming(String convId) {
        return convId != null && streams.containsKey(convId);
    }

    public void send(String text) {
        send(text, null);
    }

    /** 向当前会话发送消息，permissionMode 为空时回退到全局设置。 */
    public void send(String text, String permissionMode) {
        send(sessions.current(), text, permissionMode);
    }

    /** 向指定会话发送（供定时任务等后台并行调用，无需切换当前会话）。 */
    public void send(Conversation conv, String text, String permissionMode) {
        if (text == null || text.isBlank()) return;
        if (conv == null) {
            conv = sessions.create(true);
        }
        final Conversation c = conv;
        final ChatBackend backendForStream = backend;
        if (streams.containsKey(c.id)) return; // 该会话已有活跃流，避免重复

        // 用户消息
        ChatMessage userMsg = new ChatMessage(UUID.randomUUID().toString(), "user");
        userMsg.content = text;
        synchronized (Store.PERSIST_LOCK) {
            c.messages.add(userMsg);
        }
        listener.onUserMessage(c, userMsg);

        // 自动标题
        if (c.title == null || c.title.isBlank() || "新会话".equals(c.title)) {
            String flat = text.replace("\n", " ").trim();
            c.title = flat.length() > 24 ? flat.substring(0, 24) + "…" : flat;
            listener.onTitleChanged(c);
        }
        c.updatedAt = System.currentTimeMillis();

        // 助手占位消息
        ChatMessage msg = new ChatMessage(UUID.randomUUID().toString(), "assistant");
        msg.model = modelFor(c);
        synchronized (Store.PERSIST_LOCK) {
            c.messages.add(msg);
        }
        final Stream stream = new Stream(c, msg, backendForStream);
        streams.put(c.id, stream);
        listener.onAssistantMessage(c, msg);
        listener.onStreamingChanged(c, true);

        final String model = msg.model;
        final String resume = c.sdkSessionId;
        final String skillPrompt = skills.appendSystemPrompt(c.skillPath);
        final String jagentPrompt = jagent == null ? null : jagent.rules();
        final ChatMessage am = msg;

        // 组装后端无关请求（history = 当前用户消息与助手占位之前的全部历史）
        ChatRequest req = new ChatRequest();
        req.conversationId = c.id;
        req.message = text;
        req.model = model;
        req.cwd = settings.settings().cwd;
        req.permissionMode = (permissionMode == null || permissionMode.isBlank())
                ? settings.settings().permissionMode : permissionMode;
        req.resume = resume;
        req.systemPromptAppend = buildSystemPrompt(jagentPrompt, skillPrompt);
        int historyEnd = Math.max(0, c.messages.size() - 2);
        req.history = buildHistory(c.messages, historyEnd, settings.settings().historyRounds);

        Thread.ofVirtual().name("java-agent-chat").start(() -> {
            // 日志统一放到后台线程，避免调试模式的大段日志阻塞 JavaFX UI 线程
            log.info("发送消息：conv={}, model={}, 技能={}, 指令={}", c.id, model,
                    c.skillPath == null ? "无" : c.skillPath, jagentPrompt != null);
            ModelLog.input(backendForStream.id(), req);
            backendForStream.chat(req, new ChatBackend.StreamListener() {
                            @Override
                            public void onSession(String sdkSessionId) {
                                c.sdkSessionId = sdkSessionId;
                                ModelLog.session(c.id, sdkSessionId);
                            }

                            @Override
                            public void onText(String content) {
                                if (content == null || content.isEmpty()) return;
                                synchronized (stream.textBuffer) {
                                    stream.textBuffer.append(content);
                                }
                                scheduleFlush(stream);
                            }

                            @Override
                            public void onThinking(String content) {
                                if (content == null || content.isEmpty()) return;
                                synchronized (stream.thinkingBuffer) {
                                    stream.thinkingBuffer.append(content);
                                }
                                scheduleFlush(stream);
                            }

                            @Override
                            public void onTool(String id, String name, String inputJson) {
                                ModelLog.tool(c.id, name, inputJson);
                                exec.execute(() -> {
                                    ToolCall tc = new ToolCall(id, name, inputJson);
                                    synchronized (Store.PERSIST_LOCK) {
                                        am.toolCalls.add(tc);
                                    }
                                    listener.onToolAdded(c, am, tc);
                                });
                            }

                            @Override
                            public void onToolResult(String toolId, String content, boolean isError) {
                                ModelLog.toolResult(c.id, toolId, content, isError);
                                exec.execute(() -> {
                                    for (ToolCall tc : am.toolCalls) {
                                        if (tc.id.equals(toolId)) {
                                            tc.status = isError ? "error" : "completed";
                                            tc.result = content;
                                            listener.onToolUpdated(c, am, tc);
                                            break;
                                        }
                                    }
                                });
                            }

                            @Override
                            public void onToolInputDelta(String toolId, String partialJson) {
                                if (toolId == null || partialJson == null || partialJson.isEmpty()) return;
                                exec.execute(() -> {
                                    for (ToolCall tc : am.toolCalls) {
                                        if (tc.id.equals(toolId)) {
                                            tc.inputJson = (tc.inputJson == null ? "" : tc.inputJson) + partialJson;
                                            listener.onToolUpdated(c, am, tc);
                                            break;
                                        }
                                    }
                                });
                            }

                            @Override
                            public void onPermissionRequest(String requestId, String toolName, String inputJson) {
                                listener.onPermissionRequest(requestId, toolName, inputJson, (name, allow) ->
                                        Thread.ofVirtual().start(() ->
                                                backendForStream.respondPermission(requestId, allow,
                                                        allow ? null : "用户拒绝了此操作")));
                            }

                            @Override
                            public void onDone(JsonObject data) {
                                exec.execute(() -> finishStream(c, am, false, null));
                            }

                            @Override
                            public void onError(String code, String message) {
                                ModelLog.error(c.id, message);
                                // 报错后立即中断该会话，避免后端继续生成或界面停留在流式状态
                                abort(backendForStream, c.id);
                                exec.execute(() -> finishStream(c, am, true, message));
                                if ("AUTH_REQUIRED".equals(code)) {
                                    listener.onAuthRequired();
                                }
                            }
                        });
        });
    }

    /**
     * 组装发送给模型的历史消息。错误/中断的消息会去掉提示文案但保留已生成的部分，
     * 使下一次请求可以「断点继续」，而不是丢掉上下文或把错误提示喂给模型。
     */
    private static List<ChatMessage> buildHistory(List<ChatMessage> messages, int end, int rounds) {
        int start = historyStart(messages, end, rounds);
        List<ChatMessage> history = new ArrayList<>(Math.max(0, end - start));
        for (int i = start; i < end; i++) {
            ChatMessage m = messages.get(i);
            if (m == null || m.local) continue;
            if (!m.error) {
                history.add(m);
                continue;
            }
            String content = m.content == null ? "" : m.content;
            int warn = content.lastIndexOf("\n\n⚠ ");
            if (warn < 0) warn = content.lastIndexOf("⚠ ");
            if (warn >= 0) content = content.substring(0, warn);
            content = content.replace("\n\n_（已手动停止）_", "").trim();
            if (content.isEmpty()) continue;
            ChatMessage copy = new ChatMessage(m.id, m.role);
            copy.content = content;
            copy.model = m.model;
            history.add(copy);
        }
        return history;
    }

    /**
     * 按「轮」截取历史起点：每轮以用户消息开始；rounds==0 表示不发送历史，
     * rounds&lt;0 表示不限制。默认只带最近 3 轮，控制上下文长度。
     */
    private static int historyStart(List<ChatMessage> messages, int end, int rounds) {
        if (rounds < 0) return 0;
        if (rounds == 0) return end;
        int seen = 0;
        for (int i = end - 1; i >= 0; i--) {
            ChatMessage m = messages.get(i);
            if (m != null && "user".equals(m.role)) {
                seen++;
                if (seen == rounds) return i;
            }
        }
        return 0;
    }

    private String modelFor(Conversation conv) {
        if (conv.model != null && !conv.model.isBlank()) return conv.model;
        return settings.settings().model;
    }

    /** 组合 jagent.md 指令与已加载技能，作为系统提示词追加内容。 */
    private String buildSystemPrompt(String jagentPrompt, String skillPrompt) {
        StringBuilder sb = new StringBuilder();
        if (jagentPrompt != null && !jagentPrompt.isBlank()) {
            sb.append("# 项目规则（jagent.md）\n以下规则来自工作空间 jagent.md，请严格遵守：\n\n")
                    .append(jagentPrompt.trim());
        }
        if (skillPrompt != null && !skillPrompt.isBlank()) {
            if (sb.length() > 0) sb.append("\n\n");
            sb.append(skillPrompt.trim());
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private void scheduleFlush(Stream s) {
        synchronized (s) {
            if (s.pendingFlush == null) {
                s.pendingFlush = exec.schedule(() -> flushNow(s), 90, TimeUnit.MILLISECONDS);
            }
        }
    }

    private void flushNow(Stream s) {
        synchronized (s) {
            s.pendingFlush = null;
        }
        String textChunk;
        synchronized (s.textBuffer) {
            textChunk = s.textBuffer.length() == 0 ? null : s.textBuffer.toString();
            s.textBuffer.setLength(0);
        }
        String thinkingChunk;
        synchronized (s.thinkingBuffer) {
            thinkingChunk = s.thinkingBuffer.length() == 0 ? null : s.thinkingBuffer.toString();
            s.thinkingBuffer.setLength(0);
        }
        if (textChunk == null && thinkingChunk == null) return;
        if (textChunk != null) {
            s.msg.content = (s.msg.content == null ? "" : s.msg.content) + textChunk;
        }
        if (thinkingChunk != null) {
            s.msg.thinking = (s.msg.thinking == null ? "" : s.msg.thinking) + thinkingChunk;
        }
        listener.onTextUpdated(s.conv, s.msg);
    }

    /** 结束流式响应。按消息实例幂等：仅当 msg 仍是该会话当前活跃消息时才收尾。 */
    private void finishStream(Conversation conv, ChatMessage msg, boolean error, String errorMessage) {
        Stream s = streams.get(conv.id);
        if (s == null || s.msg != msg) return;
        streams.remove(conv.id);
        synchronized (s.textBuffer) {
            if (s.textBuffer.length() > 0) {
                msg.content = (msg.content == null ? "" : msg.content) + s.textBuffer;
                s.textBuffer.setLength(0);
            }
        }
        synchronized (s.thinkingBuffer) {
            if (s.thinkingBuffer.length() > 0) {
                msg.thinking = (msg.thinking == null ? "" : msg.thinking) + s.thinkingBuffer;
                s.thinkingBuffer.setLength(0);
            }
        }
        synchronized (s) {
            if (s.pendingFlush != null) {
                s.pendingFlush.cancel(false);
                s.pendingFlush = null;
            }
        }
        if (error && errorMessage != null) {
            msg.error = true;
            msg.content = (msg.content == null ? "" : msg.content)
                    + (msg.content.isEmpty() ? "" : "\n\n")
                    + "⚠ " + errorMessage;
        }
        conv.updatedAt = System.currentTimeMillis();
        ModelLog.done(conv.id, msg);
        listener.onFinished(conv, msg);
        listener.onStreamingChanged(conv, false);
    }

    /** 停止当前会话的流式响应。 */
    public void stop() {
        stop(sessions.current());
    }

    public void stop(Conversation conv) {
        if (conv == null) return;
        Stream s = streams.get(conv.id);
        if (s == null) return;
        final ChatMessage msg = s.msg;
        final ChatBackend backendForStream = s.backend;
        abort(backendForStream, conv.id);
        // 本地兜底：2 秒后仍未结束则强制结束
        exec.schedule(() -> {
            Stream cur = streams.get(conv.id);
            if (cur != null && cur.msg == msg) {
                msg.content = (msg.content == null ? "" : msg.content)
                        + (msg.content.isEmpty() ? "" : "\n\n_（已手动停止）_");
                finishStream(conv, msg, false, null);
            }
        }, 2, TimeUnit.SECONDS);
    }

    /** 异步中断后端生成（不阻塞调用线程，失败只记录日志）。 */
    private void abort(ChatBackend backend, String convId) {
        Thread.ofVirtual().name("agent-abort").start(() -> {
            try {
                backend.abort(convId);
            } catch (Exception e) {
                log.warn("中断会话失败：{}", convId, e);
            }
        });
    }

    public void shutdown() {
        exec.shutdownNow();
    }

    /** 单个会话的活跃流状态。 */
    private static final class Stream {
        final Conversation conv;
        final ChatMessage msg;
        final ChatBackend backend;
        final StringBuilder textBuffer = new StringBuilder();
        final StringBuilder thinkingBuffer = new StringBuilder();
        ScheduledFuture<?> pendingFlush;

        Stream(Conversation conv, ChatMessage msg, ChatBackend backend) {
            this.conv = conv;
            this.msg = msg;
            this.backend = backend;
        }
    }
}
