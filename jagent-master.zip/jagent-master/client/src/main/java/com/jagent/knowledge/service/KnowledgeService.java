package com.jagent.knowledge.service;

import com.jagent.harness.Harness;
import com.jagent.chat.service.ChatBackend;
import com.jagent.chat.service.Langchain4jBackend;
import com.jagent.settings.model.AppSettings;
import com.jagent.knowledge.model.KnowledgeBase;
import com.jagent.knowledge.model.KnowledgeDocument;
import com.jagent.store.Store;
import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.DocumentSplitter;
import dev.langchain4j.data.document.splitter.DocumentSplitters;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.message.SystemMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.openai.OpenAiEmbeddingModel;
import dev.langchain4j.model.output.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 知识库领域服务：多知识库管理 + 文档分块/嵌入入库 + 检索问答。
 * 纯 Java，无 javafx 依赖；向量存储委托给 {@link KnowledgeStore}（可替换为 ES/DB 实现）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class KnowledgeService implements Harness {

    @Override
    public String id() { return "knowledge"; }

    @Override
    public String name() { return "知识库"; }

    public interface Listener {
        default void onChanged() {}

        default void onError(String message) {}
    }

    private static final Logger log = LogManager.getLogger(KnowledgeService.class);

    private static final Set<String> TEXT_EXT = Set.of(
            "txt", "md", "markdown", "java", "js", "ts", "jsx", "tsx", "py", "json", "xml",
            "yml", "yaml", "html", "htm", "css", "sql", "sh", "bat", "cmd", "properties",
            "csv", "log", "ini", "conf", "kt", "c", "h", "cpp", "hpp", "go", "rs", "rb", "php");

    private final Langchain4jBackend llm;
    private final AppSettings settings;
    private final KnowledgeStore store;

    private final List<KnowledgeBase> bases = new ArrayList<>();
    private KnowledgeBase current;
    private volatile EmbeddingModel embeddingModel;
    private Listener listener = new Listener() {};

    public KnowledgeService(Langchain4jBackend llm, AppSettings settings, KnowledgeStore store) {
        this.llm = llm;
        this.settings = settings;
        this.store = store;
        this.bases.addAll(Store.loadKnowledgeBases());
        if (this.bases.isEmpty()) {
            createBase("默认知识库", 300, 30);
        } else {
            this.current = this.bases.get(0);
        }
    }

    public void setListener(Listener listener) {
        this.listener = listener == null ? new Listener() {} : listener;
    }

    // ---- 知识库 ----

    public synchronized List<KnowledgeBase> bases() {
        return new ArrayList<>(bases);
    }

    public synchronized KnowledgeBase current() {
        return current;
    }

    public synchronized void selectBase(String baseId) {
        KnowledgeBase b = find(baseId);
        if (b != null && b != current) {
            current = b;
            notifyChanged();
        }
    }

    public synchronized KnowledgeBase createBase(String name, int chunkSize, int chunkOverlap) {
        KnowledgeBase b = new KnowledgeBase();
        b.name = (name == null || name.isBlank()) ? "新建知识库" : name.trim();
        b.chunkSize = chunkSize > 0 ? chunkSize : 300;
        b.chunkOverlap = (chunkOverlap >= 0 && chunkOverlap < b.chunkSize) ? chunkOverlap : Math.min(30, b.chunkSize - 1);
        bases.add(b);
        current = b;
        persist();
        notifyChanged();
        return b;
    }

    public synchronized void deleteBase(String baseId) {
        KnowledgeBase b = find(baseId);
        if (b == null) return;
        store.deleteBase(baseId);
        bases.remove(b);
        deleteKnowledgeDir(baseId);
        if (current == b) {
            current = bases.isEmpty() ? null : bases.get(0);
        }
        persist();
        notifyChanged();
    }

    public synchronized KnowledgeBase find(String baseId) {
        for (KnowledgeBase b : bases) {
            if (b.id.equals(baseId)) return b;
        }
        return null;
    }

    // ---- 文档 ----

    public synchronized List<KnowledgeDocument> documents(String baseId) {
        KnowledgeBase b = find(baseId);
        if (b == null) return new ArrayList<>();
        return new ArrayList<>(b.documents);
    }

    /** 添加单个文本文件并落盘到本地知识库目录，返回其分块数；非文本返回 -1，空返回 0。
     *  配置了嵌入接口时额外做向量化入库；否则仅本地存储，问答走关键词检索。 */
    public synchronized int addDocument(String baseId, Path file) throws IOException {
        KnowledgeBase b = find(baseId);
        if (b == null) throw new IOException("知识库不存在");
        if (!isText(file)) return -1;
        String text = Files.readString(file, StandardCharsets.UTF_8);
        if (text == null || text.isBlank()) return 0;

        DocumentSplitter splitter = DocumentSplitters.recursive(b.chunkSize, b.chunkOverlap);
        List<TextSegment> segments = splitter.split(Document.from(text));
        if (segments.isEmpty()) return 0;

        String docId = UUID.randomUUID().toString();

        // 原始文档始终落盘到工程知识库目录
        Path targetDir = knowledgeDir(b.id);
        Files.createDirectories(targetDir);
        Path stored = targetDir.resolve(file.getFileName().toString());
        Files.copy(file, stored, StandardCopyOption.REPLACE_EXISTING);

        boolean baseEmbedded = b.embeddingModel != null && !b.embeddingModel.isBlank();
        // 配置了远程嵌入接口时才做向量化入库
        if (embeddingReady()) {
            if (baseEmbedded && !settings.llmEmbeddingModel.equals(b.embeddingModel)) {
                throw new IOException("嵌入模型与已有文档不一致，请使用原模型或新建知识库");
            }
            Response<List<Embedding>> response;
            try {
                response = model().embedAll(segments);
            } catch (Exception e) {
                throw new IOException("文档嵌入失败，请检查嵌入接口配置（地址/Key/模型名）："
                        + (e.getMessage() == null ? e.toString() : e.getMessage()));
            }
            List<Embedding> embeddings = response.content();
            if (embeddings.size() != segments.size()) {
                throw new IOException("嵌入结果数量与分块数量不一致");
            }
            List<KnowledgeStore.Chunk> chunks = new ArrayList<>();
            for (int i = 0; i < segments.size(); i++) {
                chunks.add(new KnowledgeStore.Chunk(segments.get(i).text(), embeddings.get(i).vector()));
            }
            store.addChunks(b.id, docId, chunks);
            if (!baseEmbedded) {
                b.embeddingModel = settings.llmEmbeddingModel;
            }
        }

        KnowledgeDocument kd = new KnowledgeDocument();
        kd.id = docId;
        kd.name = file.getFileName().toString();
        kd.path = stored.toString();
        kd.chunkCount = segments.size();
        b.documents.add(kd);
        b.updatedAt = System.currentTimeMillis();
        persist();
        notifyChanged();
        return segments.size();
    }

    public synchronized void removeDocument(String baseId, String docId) {
        KnowledgeBase b = find(baseId);
        if (b == null) return;
        store.removeDocument(baseId, docId);
        KnowledgeDocument removed = null;
        for (KnowledgeDocument d : b.documents) {
            if (d.id.equals(docId)) {
                removed = d;
                break;
            }
        }
        b.documents.removeIf(d -> d.id.equals(docId));
        if (removed != null && removed.path != null && !removed.path.isBlank()) {
            try {
                Files.deleteIfExists(Path.of(removed.path));
            } catch (IOException e) {
                log.warn("删除知识库文档文件失败：{}", removed.path, e);
            }
        }
        b.updatedAt = System.currentTimeMillis();
        persist();
        notifyChanged();
    }

    // ---- 检索问答 ----

    /**
     * 供对话框命令 {@code /harness knowledge <问题>} 调用：同步等待知识库问答完成。
     */
    @Override
    public String execute(String input) throws Exception {
        if (input == null || input.isBlank()) {
            return "用法：/harness knowledge <问题>";
        }
        CountDownLatch done = new CountDownLatch(1);
        StringBuilder answer = new StringBuilder();
        AtomicReference<String> error = new AtomicReference<>();
        ask(input.trim(), new ChatBackend.StreamListener() {
            @Override
            public void onText(String content) {
                if (content != null) answer.append(content);
            }

            @Override
            public void onDone(com.google.gson.JsonObject data) {
                done.countDown();
            }

            @Override
            public void onError(String code, String message) {
                error.set(message);
                done.countDown();
            }
        });
        if (!done.await(5, TimeUnit.MINUTES)) {
            return "知识库问答超时";
        }
        if (error.get() != null) {
            return "知识库问答失败：" + error.get();
        }
        String text = answer.toString().trim();
        return text.isEmpty() ? "知识库没有返回内容" : text;
    }

    public void ask(String question, ChatBackend.StreamListener listener) {
        KnowledgeBase b = current();
        if (b == null) {
            listener.onError("请先创建知识库");
            return;
        }
        ask(b.id, question, listener);
    }

    public void ask(String baseId, String question, ChatBackend.StreamListener listener) {
        if (question == null || question.isBlank()) {
            listener.onError("请输入问题");
            return;
        }
        KnowledgeBase b = find(baseId);
        if (b == null) {
            listener.onError("知识库不存在");
            return;
        }
        if (b.documents.isEmpty()) {
            listener.onError("请先添加文档");
            return;
        }
        boolean baseEmbedded = b.embeddingModel != null && !b.embeddingModel.isBlank();
        try {
            List<KnowledgeStore.SearchHit> hits;
            if (embeddingReady() && baseEmbedded) {
                Embedding questionEmbedding = model().embed(question).content();
                hits = store.search(baseId, questionEmbedding.vector(), 3);
            } else {
                // 未配置嵌入接口时，退化为本地关键词检索
                hits = keywordSearch(b, question, 3);
            }
            if (hits.isEmpty()) {
                listener.onError("未在文档中找到相关内容");
                return;
            }
            StringBuilder context = new StringBuilder();
            for (KnowledgeStore.SearchHit h : hits) {
                context.append("- ").append(h.text).append("\n\n");
            }
            List<dev.langchain4j.data.message.ChatMessage> messages = List.of(
                    SystemMessage.from("你是文档问答助手。请仅根据下面提供的文档片段回答用户问题；"
                            + "如果片段中没有答案，请明确说明。不要编造。\n\n文档片段：\n" + context),
                    UserMessage.from(question));
            llm.stream(messages, listener);
        } catch (Exception e) {
            log.error("文档问答失败", e);
            listener.onError(e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    // ---- 本地关键词检索（未配置嵌入接口时的降级方案） ----

    private List<KnowledgeStore.SearchHit> keywordSearch(KnowledgeBase b, String question, int topK) {
        List<KnowledgeStore.SearchHit> out = new ArrayList<>();
        List<String> terms = new ArrayList<>();
        for (String t : question.toLowerCase().split("[\\s，。？！、；：,.?!;:()\\[\\]{}]+")) {
            if (!t.isBlank()) terms.add(t);
        }
        if (terms.isEmpty()) return out;

        DocumentSplitter splitter = DocumentSplitters.recursive(b.chunkSize, b.chunkOverlap);
        for (KnowledgeDocument d : b.documents) {
            if (d.path == null || d.path.isBlank()) continue;
            Path p = Path.of(d.path);
            if (!Files.isReadable(p)) continue;
            try {
                String text = Files.readString(p, StandardCharsets.UTF_8);
                for (TextSegment seg : splitter.split(Document.from(text))) {
                    String lower = seg.text().toLowerCase();
                    int score = 0;
                    for (String t : terms) {
                        if (lower.contains(t)) score++;
                    }
                    if (score > 0) out.add(new KnowledgeStore.SearchHit(d.id, seg.text(), score));
                }
            } catch (IOException ignored) {
            }
        }
        out.sort((x, y) -> Double.compare(y.score, x.score));
        return out.size() > topK ? new ArrayList<>(out.subList(0, topK)) : out;
    }

    // ---- 运行配置 ----

    public boolean embeddingReady() {
        return settings.llmEmbeddingModel != null && !settings.llmEmbeddingModel.isBlank()
                && settings.llmEmbeddingBaseUrl != null && !settings.llmEmbeddingBaseUrl.isBlank()
                && settings.llmEmbeddingApiKey != null && !settings.llmEmbeddingApiKey.isBlank();
    }

    /** 嵌入接口地址（仅使用独立配置，不填则走本地存储）。 */
    private String embeddingBaseUrl() {
        return settings.llmEmbeddingBaseUrl == null ? "" : settings.llmEmbeddingBaseUrl.trim();
    }

    /** 嵌入 API Key（仅使用独立配置，不填则走本地存储）。 */
    private String embeddingApiKey() {
        return settings.llmEmbeddingApiKey == null ? "" : settings.llmEmbeddingApiKey.trim();
    }

    public void reset() {
        embeddingModel = null;
    }

    public synchronized void persist() {
        Store.saveKnowledgeBases(bases);
    }

    /** 工程内知识库原始文档目录：data/knowledge/<库ID>。 */
    private Path knowledgeDir(String baseId) {
        return Store.dataDir().resolve("knowledge").resolve(baseId);
    }

    private void deleteKnowledgeDir(String baseId) {
        Path dir = knowledgeDir(baseId);
        if (!Files.exists(dir)) return;
        try (var stream = Files.walk(dir)) {
            stream.sorted(java.util.Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.deleteIfExists(p);
                } catch (IOException e) {
                    log.warn("删除知识库文档目录失败：{}", p, e);
                }
            });
        } catch (IOException e) {
            log.warn("遍历知识库文档目录失败：{}", dir, e);
        }
    }

    private synchronized EmbeddingModel model() {
        if (embeddingModel == null) {
            embeddingModel = OpenAiEmbeddingModel.builder()
                    .baseUrl(embeddingBaseUrl())
                    .apiKey(embeddingApiKey())
                    .modelName(settings.llmEmbeddingModel.trim())
                    .build();
        }
        return embeddingModel;
    }

    private void notifyChanged() {
        Listener l = listener;
        if (l != null) l.onChanged();
    }

    private static boolean isText(Path file) {
        String n = file.getFileName().toString();
        int dot = n.lastIndexOf('.');
        if (dot < 0) return false;
        return TEXT_EXT.contains(n.substring(dot + 1).toLowerCase());
    }
}
