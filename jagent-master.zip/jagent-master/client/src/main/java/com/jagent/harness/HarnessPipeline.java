package com.jagent.harness;

import com.jagent.common.exception.BusinessException;
import com.jagent.harness.verify.Verifiers;
import com.jagent.harness.verify.VerifyDef;

import java.util.ArrayList;
import java.util.List;

/**
 * 业务编排：按顺序串联多个 harness 的生命周期或执行动作。
 * 支持链式 {@link #add(Harness)} / {@link #add(Harness, String)}；
 * {@link #start()} 顺序初始化，{@link #stop()} 逆序关闭。
 *
 * <p>与 {@link HarnessRegistry} 的差异：Registry 面向「注册 + 按 id 查找」的全局管理，
 * Pipeline 面向「一次性的有序流程编排」，两者可组合使用。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class HarnessPipeline {

    private final List<Step> steps = new ArrayList<>();
    private boolean chain;

    /**
     * 开启步骤结果串联：未显式指定 input 的步骤会收到上一步的输出。
     * 第一步仍使用 execute 的默认入参。
     */
    public HarnessPipeline chain(boolean chain) {
        this.chain = chain;
        return this;
    }

    public HarnessPipeline add(Harness h) {
        return add(h, null, null);
    }

    /**
     * 添加步骤并指定该步骤的固定入参；{@code input} 为 null 时使用 execute 的默认入参。
     */
    public HarnessPipeline add(Harness h, String input) {
        return add(h, input, null);
    }

    /**
     * 添加带条件的步骤：{@code when} 基于之前步骤的输出判断，不满足时跳过该步骤。
     */
    public HarnessPipeline add(Harness h, String input, VerifyDef when) {
        if (h == null) throw new BusinessException("harness 不能为空");
        steps.add(new Step(h, input, when));
        return this;
    }

    /** 顺序初始化所有步骤。 */
    public void start() {
        for (Step step : steps) step.harness().initialize();
    }

    /** 逆序关闭所有步骤。 */
    public void stop() {
        for (int i = steps.size() - 1; i >= 0; i--) steps.get(i).harness().shutdown();
    }

    /**
     * 顺序执行所有步骤的 {@link Harness#execute(String)}，单步失败不影响后续步骤。
     * 适合“巡检 / 报表”等一次性编排场景。
     */
    public List<StepResult> execute(String input) {
        return execute(input, null);
    }

    /**
     * 带拦截器的执行：可在单步执行前复用已保存结果（checkpoint），
     * 并在单步完成后回调（持久化 checkpoint / 审计）。
     */
    public List<StepResult> execute(String input, StepInterceptor interceptor) {
        List<StepResult> results = new ArrayList<>();
        List<String> outputs = new ArrayList<>();
        String previous = null;

        for (int index = 0; index < steps.size(); index++) {
            Step step = steps.get(index);
            Harness h = step.harness();

            StepResult cached = interceptor == null ? null : interceptor.reuse(index);
            if (cached != null && cached.ok()) {
                results.add(cached);
                outputs.add(cached.output() == null ? "" : cached.output());
                if (!cached.skipped()) previous = cached.output() == null ? "" : cached.output();
                interceptor.completed(index, cached);
                continue;
            }

            // 条件步骤：基于之前步骤的输出判断，不满足则跳过
            if (step.when() != null) {
                boolean pass = Verifiers.of(step.when()).verify(results).passed();
                if (!pass) {
                    StepResult skipped = new StepResult(h.id(), h.name(), null, null, true);
                    results.add(skipped);
                    outputs.add("");
                    if (interceptor != null) interceptor.completed(index, skipped);
                    continue;
                }
            }

            String stepInput;
            if (step.input() != null) {
                // 支持 ${input} / ${prev} / ${1} / ${2} ... 占位符
                stepInput = resolve(step.input(), input, previous, outputs);
            } else if (chain && previous != null) {
                stepInput = previous;
            } else {
                stepInput = input;
            }

            StepResult result;
            try {
                String output = h.execute(stepInput);
                outputs.add(output == null ? "" : output);
                previous = output == null ? "" : output;
                result = new StepResult(h.id(), h.name(), output, null);
            } catch (Exception e) {
                String error = e.getMessage() == null ? e.toString() : e.getMessage();
                outputs.add("");
                previous = "（上一步执行失败：" + error + "）";
                result = new StepResult(h.id(), h.name(), null, error);
            }
            results.add(result);
            if (interceptor != null) interceptor.completed(index, result);
        }
        return results;
    }

    /** 单步执行拦截器：复用已成功结果 / 落盘 checkpoint。 */
    public interface StepInterceptor {
        /** 返回非 null 且 ok 时跳过该步骤执行。 */
        default StepResult reuse(int index) {
            return null;
        }

        default void completed(int index, StepResult result) {}
    }

    private static String resolve(String template, String input, String previous, List<String> outputs) {
        String value = template.replace("${input}", input == null ? "" : input);
        value = value.replace("${prev}", previous == null ? "" : previous);
        for (int i = 0; i < outputs.size(); i++) {
            value = value.replace("${" + (i + 1) + "}", outputs.get(i));
        }
        return value;
    }

    public List<Harness> steps() {
        List<Harness> out = new ArrayList<>(steps.size());
        for (Step step : steps) out.add(step.harness());
        return out;
    }

    private record Step(Harness harness, String input, VerifyDef when) {}

    /** 单个步骤的执行结果。 */
    public record StepResult(String id, String name, String output, String error, boolean skipped) {

        public StepResult(String id, String name, String output, String error) {
            this(id, name, output, error, false);
        }

        public boolean ok() {
            return error == null;
        }
    }
}
