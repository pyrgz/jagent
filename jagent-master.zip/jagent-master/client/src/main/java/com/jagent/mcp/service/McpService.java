package com.jagent.mcp.service;

import com.jagent.chat.tool.Tool;
import com.jagent.harness.Harness;
import com.jagent.mcp.client.HttpMcpClient;
import com.jagent.mcp.client.McpClient;
import com.jagent.mcp.client.StdioMcpClient;
import com.jagent.mcp.model.McpConfig;
import com.jagent.mcp.model.McpServerConfig;
import com.jagent.mcp.model.McpToolDef;
import com.jagent.mcp.tool.McpTool;
import com.jagent.store.Store;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * MCP 服务管理：读取 data/mcp.json，连接启用的 MCP Server，并把其工具暴露给直连后端。
 *
 * <p>配置文件变化后会在下一次请求时自动重连，无需重启客户端。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class McpService implements Harness {

    @Override
    public String id() { return "mcp"; }

    @Override
    public String name() { return "MCP"; }

    private static final Logger log = LogManager.getLogger(McpService.class);
    private static final Gson GSON = new GsonBuilder().create();
    private static final int MAX_TOOL_NAME = 64;

    private final Path configFile = Store.dataDir().resolve("mcp.json");
    private final List<Tool> tools = new CopyOnWriteArrayList<>();
    private final List<McpClient> clients = new ArrayList<>();

    private long loadedMtime = Long.MIN_VALUE;

    /** 当前可用的 MCP 工具（配置变化时自动重载）。 */
    public List<Tool> tools() {
        reloadIfChanged();
        return new ArrayList<>(tools);
    }

    /** 供对话框命令 {@code /harness mcp}（及编排）调用：列出已连接的 MCP 工具。 */
    @Override
    public String execute(String input) {
        List<Tool> list = tools();
        if (list.isEmpty()) {
            return "未加载 MCP 工具（请检查 data/mcp.json 是否配置并连接成功）";
        }
        StringBuilder sb = new StringBuilder("MCP 工具 ").append(list.size()).append(" 个：\n");
        for (Tool tool : list) {
            sb.append("- ").append(tool.specification().name()).append('\n');
        }
        return sb.toString().trim();
    }

    private synchronized void reloadIfChanged() {
        long mtime = configMtime();
        if (mtime == loadedMtime) return;

        closeAll();
        tools.clear();

        if (mtime == 0) {
            loadedMtime = 0;
            log.info("未配置 MCP 服务（{}）", configFile);
            return;
        }

        McpConfig config;
        try {
            config = GSON.fromJson(Files.readString(configFile), McpConfig.class);
        } catch (Exception e) {
            log.error("读取 MCP 配置失败：{}", configFile, e);
            loadedMtime = mtime;
            return;
        }
        if (config == null || config.mcpServers == null || config.mcpServers.isEmpty()) {
            loadedMtime = mtime;
            log.info("MCP 配置为空：{}", configFile);
            return;
        }

        Set<String> usedNames = new HashSet<>();
        for (Map.Entry<String, McpServerConfig> entry : config.mcpServers.entrySet()) {
            String serverName = entry.getKey();
            McpServerConfig server = entry.getValue();
            if (server == null || !server.enabled) continue;

            McpClient client = null;
            try {
                client = createClient(serverName, server);
                client.initialize();
                List<McpToolDef> defs = client.listTools();
                String prefix = sanitize(serverName);
                for (McpToolDef def : defs) {
                    String specName = uniqueName(prefix + "__" + sanitize(def.name()), usedNames);
                    tools.add(new McpTool(specName, def, client));
                }
                clients.add(client);
                log.info("MCP[{}] 已加载 {} 个工具（{}）", serverName, defs.size(), client.serverInfo());
            } catch (Exception e) {
                log.error("MCP[{}] 初始化失败：{}", serverName, e.getMessage(), e);
                if (client != null) client.close();
            }
        }
        loadedMtime = mtime;
    }

    private static McpClient createClient(String name, McpServerConfig config) throws Exception {
        if (config.url != null && !config.url.isBlank()) {
            return new HttpMcpClient(name, config);
        }
        if (config.command != null && !config.command.isBlank()) {
            return new StdioMcpClient(name, config);
        }
        throw new IllegalArgumentException("需要配置 command（stdio）或 url（HTTP）");
    }

    private long configMtime() {
        try {
            return Files.exists(configFile) ? Files.getLastModifiedTime(configFile).toMillis() : 0;
        } catch (Exception e) {
            log.warn("读取 MCP 配置文件时间失败：{}", configFile, e);
            return 0;
        }
    }

    private void closeAll() {
        for (McpClient client : new ArrayList<>(clients)) {
            try {
                client.close();
            } catch (Exception ignored) {
            }
        }
        clients.clear();
    }

    private static String sanitize(String name) {
        String s = name == null ? "mcp" : name.replaceAll("[^a-zA-Z0-9_-]", "_");
        return s.isBlank() ? "mcp" : s;
    }

    /** 工具全名限制 64 字符，并解决不同服务之间的重名。 */
    private static String uniqueName(String base, Set<String> used) {
        String name = base.length() > MAX_TOOL_NAME ? base.substring(0, MAX_TOOL_NAME) : base;
        int i = 2;
        while (!used.add(name)) {
            String suffix = "_" + i++;
            int keep = Math.max(1, MAX_TOOL_NAME - suffix.length());
            name = (base.length() > keep ? base.substring(0, keep) : base) + suffix;
        }
        return name;
    }

    @Override
    public void shutdown() {
        synchronized (this) {
            closeAll();
            tools.clear();
            loadedMtime = Long.MIN_VALUE;
        }
    }
}
