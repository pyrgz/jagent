package com.jagent.chat.service;

import com.jagent.chat.model.ChatRequest;
import com.jagent.chat.model.ModelInfo;
import com.jagent.common.exception.BaseException;
import com.jagent.common.util.ModelLog;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

/**
 * CodeBuddy 聊天后端：经 HTTP + SSE 与本地 Node.js CodeBuddy SDK 桥接服务通信。
 * chat() 为阻塞式 SSE 消费，请在后台线程调用；事件回调在 HTTP 线程触发。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class CodeBuddyBackend implements ChatBackend {

    private static final Logger log = LogManager.getLogger(CodeBuddyBackend.class);
    private final HttpClient http;
    private final Gson gson = new Gson();
    private volatile String baseUrl;

    public CodeBuddyBackend(String baseUrl) {
        this.baseUrl = baseUrl == null || baseUrl.isBlank() ? "http://localhost:3210" : baseUrl;
        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
        this.http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(6))
                .executor(executor)
                .build();
    }

    public void setBaseUrl(String url) {
        if (url != null && !url.isBlank()) this.baseUrl = url.trim();
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    @Override
    public String id() {
        return "codebuddy";
    }

    @Override
    public boolean isAvailable() {
        return health();
    }

    /** 服务是否可用 */
    public boolean health() {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + "/api/health"))
                    .timeout(Duration.ofSeconds(3)).GET().build();
            return http.send(req, HttpResponse.BodyHandlers.ofString()).statusCode() == 200;
        } catch (Exception e) {
            return false;
        }
    }

    /** 登录状态；网络异常返回 null */
    public JsonObject checkLogin() {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + "/api/check-login"))
                    .timeout(Duration.ofSeconds(30)).GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) {
                return JsonParser.parseString(resp.body()).getAsJsonObject();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /**
     * 发起 CodeBuddy 登录流程，返回登录 URL（阻塞，应在后台线程调用）。
     * 返回 null 表示网络异常；alreadyLoggedIn=true 表示已登录无需再登。
     */
    public JsonObject login() {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + "/api/login"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(30))
                    .POST(HttpRequest.BodyPublishers.ofString("{}"))
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) {
                return JsonParser.parseString(resp.body()).getAsJsonObject();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** 模型列表（失败时返回默认列表） */
    public List<ModelInfo> models() {
        List<ModelInfo> out = new ArrayList<>();
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + "/api/models"))
                    .timeout(Duration.ofSeconds(30)).GET().build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) {
                JsonObject obj = JsonParser.parseString(resp.body()).getAsJsonObject();
                if (obj.has("models") && obj.get("models").isJsonArray()) {
                    JsonArray arr = obj.getAsJsonArray("models");
                    for (var el : arr) {
                        if (!el.isJsonObject()) continue;
                        JsonObject m = el.getAsJsonObject();
                        String id = str(m, "modelId");
                        String name = str(m, "name");
                        if (id != null && !id.isBlank()) out.add(new ModelInfo(id, name));
                    }
                }
            }
        } catch (Exception ignored) {
        }
        if (out.isEmpty()) {
            out.add(new ModelInfo("claude-sonnet-4", "Claude Sonnet 4"));
        }
        return out;
    }

    /** 保存 API Key 等配置到服务端 .env */
    public void saveConfig(String apiKey) {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("apiKey", apiKey);
            postJson("/api/config", o);
        } catch (Exception ignored) {
        }
    }

    /** 工具权限审批 */
    @Override
    public void respondPermission(String requestId, boolean allow, String message) {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("requestId", requestId);
            o.addProperty("behavior", allow ? "allow" : "deny");
            if (message != null) o.addProperty("message", message);
            postJson("/api/permission-response", o);
        } catch (Exception ignored) {
        }
    }

    /** 中断某个会话的流式响应 */
    public void abort(String conversationId) {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("conversationId", conversationId);
            postJson("/api/abort", o);
        } catch (Exception ignored) {
        }
    }

    /**
     * 发送消息并消费 SSE 流（阻塞，应在后台线程调用）。
     */
    @Override
    public void chat(ChatRequest request, ChatBackend.StreamListener listener) {
        JsonObject body = new JsonObject();
        body.addProperty("conversationId", request.conversationId);
        body.addProperty("message", request.message);
        if (request.model != null && !request.model.isBlank()) body.addProperty("model", request.model);
        if (request.cwd != null && !request.cwd.isBlank()) body.addProperty("cwd", request.cwd);
        if (request.permissionMode != null && !request.permissionMode.isBlank()) body.addProperty("permissionMode", request.permissionMode);
        if (request.resume != null && !request.resume.isBlank()) body.addProperty("resume", request.resume);
        if (request.systemPromptAppend != null && !request.systemPromptAppend.isBlank()) body.addProperty("systemPromptAppend", request.systemPromptAppend);
        ModelLog.requestBody(request.conversationId, body.toString());

        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + "/api/chat"))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofMinutes(30))
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();
            HttpResponse<Stream<String>> resp = http.send(req, HttpResponse.BodyHandlers.ofLines());
            if (resp.statusCode() != 200) {
                BaseException be = ModelErrorMapper.fromHttpStatus(resp.statusCode());
                log.error("聊天请求失败：HTTP {}，{}", resp.statusCode(), be.getMessage());
                listener.onError(be.getCode(), be.getMessage());
                return;
            }
            Iterator<String> it = resp.body().iterator();
            while (it.hasNext()) {
                String line = it.next();
                if (line == null) continue;
                if (!line.startsWith("data:")) continue;
                String payload = line.substring(5).trim();
                if (payload.isEmpty()) continue;
                JsonObject obj;
                try {
                    obj = JsonParser.parseString(payload).getAsJsonObject();
                } catch (Exception parseError) {
                    continue;
                }
                String type = str(obj, "type");
                switch (type == null ? "" : type) {
                    case "init" -> listener.onInit(obj);
                    case "session" -> listener.onSession(str(obj, "sdkSessionId"));
                    case "text" -> listener.onText(str(obj, "content"));
                    case "thinking" -> listener.onThinking(str(obj, "content"));
                    case "tool_input_delta" -> listener.onToolInputDelta(str(obj, "toolId"), str(obj, "partialJson"));
                    case "tool" -> listener.onTool(str(obj, "id"), str(obj, "name"),
                            obj.has("input") ? obj.get("input").toString() : "{}");
                    case "tool_result" -> listener.onToolResult(str(obj, "toolId"),
                            str(obj, "content"), bool(obj, "isError"));
                    case "permission_request" -> listener.onPermissionRequest(
                            str(obj, "requestId"), str(obj, "toolName"),
                            obj.has("input") ? pretty(obj.get("input")) : "{}");
                    case "permission_denied" -> {
                    }
                    case "error" -> {
                        BaseException be = ModelErrorMapper.fromServer(str(obj, "code"), str(obj, "message"));
                        listener.onError(be.getCode(), be.getMessage());
                        return;
                    }
                    case "done" -> {
                        listener.onDone(obj);
                        return;
                    }
                    default -> {
                    }
                }
            }
            // 流结束但未收到 done 事件（服务端关闭连接）→ 按完成处理
            listener.onDone(new JsonObject());
        } catch (Exception e) {
            BaseException be = ModelErrorMapper.toUserError(e);
            log.error("聊天请求异常：{}", be.getMessage(), e);
            listener.onError(be.getCode(), be.getMessage());
        }
    }

    private void postJson(String path, JsonObject body) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + path))
                .header("Content-Type", "application/json")
                .timeout(Duration.ofSeconds(10))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();
        http.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private String pretty(Object jsonElement) {
        try {
            return new Gson().toJson(jsonElement);
        } catch (Exception e) {
            return String.valueOf(jsonElement);
        }
    }

    private static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
    }

    private static boolean bool(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() && o.get(key).getAsBoolean();
    }
}
