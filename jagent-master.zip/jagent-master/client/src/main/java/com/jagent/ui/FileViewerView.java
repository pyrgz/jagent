package com.jagent.ui;


import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.awt.Desktop;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;

/**
 * 文件只读查看器：支持文本 / 图片 / PDF / Word 预览，二进制文件可调系统打开。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class FileViewerView {

    private static final int PDF_MAX_PAGES = 50;
    private static final float PDF_DPI = 120f;
    private static final double PREVIEW_WIDTH = 800;
    private static final int TABLE_MAX_ROWS = 1000;
    private static final int TABLE_MAX_COLS = 50;

    private final VBox root;
    private final Label fileName;
    private final Label pathLabel;
    private final StackPane body;
    private final TextArea text;
    private final ImageView imageView;
    private final ScrollPane pdfScroll;
    private final VBox pdfPages;
    private final ScrollPane markdownScroll;
    private final VBox tableContainer;
    private final HBox sheetBar;
    private final ComboBox<String> sheetCombo;
    private final TableView<List<String>> tableView;
    private final Label binaryLabel;
    private final Button openBtn;
    private final Button saveBtn;
    private final CodeEditor codeEditor;

    private String currentPath;
    private List<SheetData> currentSheets;

    private static final DataFormatter FMT = new DataFormatter();

    public FileViewerView(Runnable onClose) {
        Button back = new Button();
        back.getStyleClass().add("btn-icon");
        Node backIcon = Icons.stroke(Icons.ARROW_RIGHT, 18, Color.web("#646A73"));
        backIcon.setRotate(180);
        back.setGraphic(backIcon);
        back.setTooltip(new Tooltip("返回聊天"));
        back.setOnAction(e -> { if (onClose != null) onClose.run(); });

        fileName = new Label("");
        fileName.getStyleClass().add("file-viewer-name");

        pathLabel = new Label("");
        pathLabel.getStyleClass().add("file-viewer-path");

        VBox titles = new VBox(0, fileName, pathLabel);
        HBox.setHgrow(titles, Priority.ALWAYS);

        openBtn = new Button("在系统中打开");
        openBtn.getStyleClass().add("btn-ghost");
        openBtn.setVisible(false);
        openBtn.setManaged(false);
        openBtn.setOnAction(e -> openExternally(currentPath));

        saveBtn = new Button("保存");
        saveBtn.getStyleClass().add("btn-primary");
        saveBtn.setVisible(false);
        saveBtn.setManaged(false);
        saveBtn.setOnAction(e -> saveCurrent());

        HBox header = new HBox(10, back, titles, saveBtn, openBtn);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("file-viewer-header");

        text = new TextArea();
        text.setEditable(false);
        text.setWrapText(false);
        text.getStyleClass().add("file-viewer-content");

        codeEditor = new CodeEditor();
        codeEditor.setVisible(false);
        codeEditor.setManaged(false);
        codeEditor.setOnDirtyChange(() -> {
            if (fileName.getText() != null && !fileName.getText().endsWith(" *")) {
                fileName.setText(fileName.getText() + " *");
            }
        });

        imageView = new ImageView();
        imageView.setPreserveRatio(true);
        imageView.setSmooth(true);

        pdfPages = new VBox(8);
        pdfPages.getStyleClass().add("file-pdf-pages");
        pdfScroll = new ScrollPane(pdfPages);
        pdfScroll.setFitToWidth(true);
        pdfScroll.getStyleClass().add("file-pdf-scroll");

        markdownScroll = new ScrollPane();
        markdownScroll.setFitToWidth(true);
        markdownScroll.getStyleClass().add("file-markdown-scroll");

        tableView = new TableView<>();
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        tableView.getStyleClass().add("file-table");

        sheetCombo = new ComboBox<>();
        sheetCombo.setPrefWidth(220);
        sheetCombo.getStyleClass().add("file-sheet-combo");
        sheetCombo.setOnAction(e -> {
            int idx = sheetCombo.getSelectionModel().getSelectedIndex();
            if (idx >= 0 && currentSheets != null && idx < currentSheets.size()) {
                renderTable(currentSheets.get(idx).rows);
            }
        });

        Label sheetLabel = new Label("工作表");
        sheetLabel.getStyleClass().add("file-sheet-label");
        sheetBar = new HBox(8, sheetLabel, sheetCombo);
        sheetBar.setAlignment(Pos.CENTER_LEFT);
        sheetBar.setPadding(new Insets(4, 8, 6, 8));
        sheetBar.getStyleClass().add("file-sheet-bar");
        sheetBar.setVisible(false);
        sheetBar.setManaged(false);

        tableContainer = new VBox(sheetBar, tableView);
        VBox.setVgrow(tableView, Priority.ALWAYS);

        binaryLabel = new Label();
        binaryLabel.getStyleClass().add("file-viewer-binary");
        binaryLabel.setWrapText(true);

        body = new StackPane(text, codeEditor, imageView, pdfScroll, markdownScroll, tableContainer, binaryLabel);
        StackPane.setAlignment(binaryLabel, Pos.CENTER);

        root = new VBox(header, body);
        VBox.setVgrow(body, Priority.ALWAYS);
        root.getStyleClass().add("file-viewer-root");
    }

    public Node node() {
        return root;
    }

    public void show(String path, String content, boolean binary, long size) {
        currentPath = path;
        Path p = Path.of(path);
        fileName.setText(p.getFileName() == null ? path : p.getFileName().toString());
        pathLabel.setText(path);
        String ext = ext(path);
        hideAll();
        openBtn.setVisible(false);
        openBtn.setManaged(false);
        saveBtn.setVisible(false);
        saveBtn.setManaged(false);

        if (!binary) {
            if ("csv".equals(ext)) {
                showSingle(parseCsv(content));
            } else {
                // 文本 / 代码 / Markdown：可编辑
                codeEditor.load(Path.of(path), content);
                codeEditor.setVisible(true);
                codeEditor.setManaged(true);
                saveBtn.setVisible(true);
                saveBtn.setManaged(true);
            }
            return;
        }

        // 二进制文件统一提供「在系统中打开」入口
        openBtn.setVisible(true);
        openBtn.setManaged(true);

        if (isImage(ext)) {
            showImage(path);
        } else if ("pdf".equals(ext)) {
            showPdf(path);
        } else if ("docx".equals(ext)) {
            showWord(path);
        } else if ("xlsx".equals(ext)) {
            showXlsx(path);
        } else if ("xls".equals(ext)) {
            showXls(path);
        } else {
            showBinary(size);
        }
    }

    // ================= 各类预览 =================

    private void hideAll() {
        text.setVisible(false);
        text.setManaged(false);
        codeEditor.setVisible(false);
        codeEditor.setManaged(false);
        imageView.setVisible(false);
        imageView.setManaged(false);
        pdfScroll.setVisible(false);
        pdfScroll.setManaged(false);
        markdownScroll.setVisible(false);
        markdownScroll.setManaged(false);
        tableContainer.setVisible(false);
        tableContainer.setManaged(false);
        binaryLabel.setVisible(false);
        binaryLabel.setManaged(false);
    }

    private void showMarkdown(String content) {
        markdownScroll.setContent(MarkdownText.render(content, false));
        markdownScroll.setVisible(true);
        markdownScroll.setManaged(true);
    }

    private void showBinary(long size) {
        binaryLabel.setText("二进制文件，无法内嵌预览（" + size + " 字节），可用右上角「在系统中打开」。");
        binaryLabel.setVisible(true);
        binaryLabel.setManaged(true);
    }

    private void showImage(String path) {
        try {
            Image img = new Image(Path.of(path).toUri().toString());
            imageView.setImage(img);
            imageView.setFitWidth(PREVIEW_WIDTH);
            imageView.setVisible(true);
            imageView.setManaged(true);
        } catch (Exception e) {
            binaryLabel.setText("图片加载失败：" + e.getMessage());
            binaryLabel.setVisible(true);
            binaryLabel.setManaged(true);
        }
    }

    private void showPdf(String path) {
        setLoading("正在加载 PDF…");
        Thread.ofVirtual().name("pdf-preview").start(() -> {
            try (PDDocument doc = Loader.loadPDF(new File(path))) {
                PDFRenderer renderer = new PDFRenderer(doc);
                int pages = Math.min(doc.getNumberOfPages(), PDF_MAX_PAGES);
                for (int i = 0; i < pages; i++) {
                    BufferedImage bi = renderer.renderImageWithDPI(i, PDF_DPI);
                    Image img = toFxImage(bi);
                    Platform.runLater(() -> {
                        ImageView iv = new ImageView(img);
                        iv.setPreserveRatio(true);
                        iv.setFitWidth(PREVIEW_WIDTH);
                        pdfPages.getChildren().add(iv);
                    });
                }
                Platform.runLater(() -> {
                    binaryLabel.setVisible(false);
                    binaryLabel.setManaged(false);
                    pdfScroll.setVisible(true);
                    pdfScroll.setManaged(true);
                });
            } catch (Exception e) {
                Platform.runLater(() -> showError("PDF 解析失败：" + e.getMessage()));
            }
        });
    }

    private void showWord(String path) {
        setLoading("正在解析 Word…");
        Thread.ofVirtual().name("word-preview").start(() -> {
            try {
                String txt = extractDocxText(Path.of(path));
                Platform.runLater(() -> {
                    binaryLabel.setVisible(false);
                    binaryLabel.setManaged(false);
                    text.setWrapText(true);
                    text.setText(txt);
                    text.positionCaret(0);
                    text.setVisible(true);
                    text.setManaged(true);
                });
            } catch (Exception e) {
                Platform.runLater(() -> showError("Word 解析失败：" + e.getMessage()));
            }
        });
    }

    private void showXlsx(String path) {
        setLoading("正在解析 Excel…");
        Thread.ofVirtual().name("xlsx-preview").start(() -> {
            try {
                List<SheetData> sheets = extractXlsx(Path.of(path));
                Platform.runLater(() -> showMulti(sheets));
            } catch (Exception e) {
                Platform.runLater(() -> showError("Excel 解析失败：" + e.getMessage()));
            }
        });
    }

    private void showXls(String path) {
        setLoading("正在解析 Excel…");
        Thread.ofVirtual().name("xls-preview").start(() -> {
            try {
                List<SheetData> sheets = extractXls(Path.of(path));
                Platform.runLater(() -> showMulti(sheets));
            } catch (Exception e) {
                Platform.runLater(() -> showError("Excel 解析失败：" + e.getMessage()));
            }
        });
    }

    /** 单表（CSV）：不显示工作表切换条。 */
    private void showSingle(List<String[]> rows) {
        sheetBar.setVisible(false);
        sheetBar.setManaged(false);
        renderTable(rows);
        tableContainer.setVisible(true);
        tableContainer.setManaged(true);
    }

    /** 多表（xlsx/xls）：显示工作表切换条。 */
    private void showMulti(List<SheetData> sheets) {
        currentSheets = sheets;
        if (sheets.isEmpty()) {
            binaryLabel.setText("（空表格）");
            binaryLabel.setVisible(true);
            binaryLabel.setManaged(true);
            return;
        }
        sheetCombo.getItems().setAll(sheets.stream().map(s -> s.name).toList());
        sheetCombo.getSelectionModel().select(0);
        sheetBar.setVisible(sheets.size() > 1);
        sheetBar.setManaged(sheets.size() > 1);
        renderTable(sheets.get(0).rows);
        tableContainer.setVisible(true);
        tableContainer.setManaged(true);
    }

    private void renderTable(List<String[]> rows) {
        tableView.getColumns().clear();
        tableView.getItems().clear();
        int cols = 0;
        for (String[] r : rows) cols = Math.max(cols, r.length);
        cols = Math.min(cols, TABLE_MAX_COLS);
        for (int c = 0; c < cols; c++) {
            final int ci = c;
            TableColumn<List<String>, String> col = new TableColumn<>(colName(c));
            col.setCellValueFactory(cd -> new SimpleStringProperty(
                    ci < cd.getValue().size() ? cd.getValue().get(ci) : ""));
            tableView.getColumns().add(col);
        }
        int rowCount = Math.min(rows.size(), TABLE_MAX_ROWS);
        for (int i = 0; i < rowCount; i++) {
            tableView.getItems().add(Arrays.asList(rows.get(i)));
        }
    }

    private void setLoading(String msg) {
        binaryLabel.setText(msg);
        binaryLabel.setVisible(true);
        binaryLabel.setManaged(true);
    }

    private void showError(String msg) {
        binaryLabel.setText(msg);
        binaryLabel.setVisible(true);
        binaryLabel.setManaged(true);
    }

    private void openExternally(String path) {
        if (path == null) return;
        try {
            if (Desktop.isDesktopSupported()
                    && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
                Desktop.getDesktop().open(new File(path));
            }
        } catch (Exception ignored) {
        }
    }

    /** 保存当前编辑的文件。 */
    private void saveCurrent() {
        if (codeEditor.save()) {
            String name = fileName.getText();
            if (name != null && name.endsWith(" *")) {
                fileName.setText(name.substring(0, name.length() - 2));
            }
        } else {
            binaryLabel.setText("保存失败");
            binaryLabel.setVisible(true);
            binaryLabel.setManaged(true);
        }
    }

    // ================= 工具 =================

    /** BufferedImage → JavaFX Image（按 ARGB 整型批量拷贝，避免依赖 javafx.swing）。 */
    private static Image toFxImage(BufferedImage bi) {
        int w = bi.getWidth();
        int h = bi.getHeight();
        int[] buffer = new int[w * h];
        bi.getRGB(0, 0, w, h, buffer, 0, w);
        WritableImage img = new WritableImage(w, h);
        PixelWriter pw = img.getPixelWriter();
        pw.setPixels(0, 0, w, h, PixelFormat.getIntArgbInstance(), buffer, 0, w);
        return img;
    }

    /** 无依赖提取 .docx 正文：解压 word/document.xml，剥离 XML 标签。 */
    private static String extractDocxText(Path path) throws Exception {
        try (ZipFile zip = new ZipFile(path.toFile())) {
            ZipEntry entry = zip.getEntry("word/document.xml");
            if (entry == null) throw new IllegalStateException("不是有效的 .docx 文件");
            String xml = new String(zip.getInputStream(entry).readAllBytes(), StandardCharsets.UTF_8);
            return stripXmlToText(xml);
        }
    }

    /** 把 OOXML 文档转成可读文本：段落→换行、tab→制表符、去标签、反转义。 */
    private static String stripXmlToText(String xml) {
        String s = xml.replaceAll("</w:p>", "\n");
        s = s.replaceAll("<w:tab[^>]*/>", "\t");
        s = s.replaceAll("<w:br[^>]*/>", "\n");
        s = s.replaceAll("<[^>]+>", "");
        s = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&apos;", "'").replace("&#10;", "\n");
        s = s.replaceAll("[ \t]+", " ");
        s = s.replaceAll("\\n{3,}", "\n\n");
        return s.trim();
    }

    /** 解析 CSV（支持引号包裹的字段、转义引号）。 */
    private static List<String[]> parseCsv(String content) {
        List<String[]> rows = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < content.length() && content.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field.append(c);
                }
            } else if (c == '"') {
                inQuotes = true;
            } else if (c == ',') {
                row.add(field.toString());
                field.setLength(0);
            } else if (c == '\n') {
                row.add(field.toString());
                field.setLength(0);
                rows.add(row.toArray(new String[0]));
                row.clear();
            } else if (c != '\r') {
                field.append(c);
            }
        }
        if (field.length() > 0 || !row.isEmpty()) {
            row.add(field.toString());
            rows.add(row.toArray(new String[0]));
        }
        return rows;
    }

    /** 无依赖提取 .xlsx 全部工作表（sharedStrings + workbook 表名 + sheet 单元格）。 */
    private static List<SheetData> extractXlsx(Path path) throws Exception {
        List<String> shared = new ArrayList<>();
        try (ZipFile zip = new ZipFile(path.toFile())) {
            ZipEntry ss = zip.getEntry("xl/sharedStrings.xml");
            if (ss != null) {
                String xml = new String(zip.getInputStream(ss).readAllBytes(), StandardCharsets.UTF_8);
                Matcher m = Pattern.compile("<t[^>]*>(.*?)</t>", Pattern.DOTALL).matcher(xml);
                while (m.find()) shared.add(unescape(m.group(1)));
            }
            List<String> names = new ArrayList<>();
            ZipEntry wb = zip.getEntry("xl/workbook.xml");
            if (wb != null) {
                String wxml = new String(zip.getInputStream(wb).readAllBytes(), StandardCharsets.UTF_8);
                Matcher m = Pattern.compile("<sheet[^>]*name=\"([^\"]*)\"").matcher(wxml);
                while (m.find()) names.add(unescape(m.group(1)));
            }
            List<ZipEntry> sheets = new ArrayList<>();
            for (int i = 1; ; i++) {
                ZipEntry e = zip.getEntry("xl/worksheets/sheet" + i + ".xml");
                if (e == null) break;
                sheets.add(e);
            }
            if (sheets.isEmpty()) throw new IllegalStateException("未找到工作表");
            List<SheetData> out = new ArrayList<>();
            for (int i = 0; i < sheets.size(); i++) {
                String sxml = new String(zip.getInputStream(sheets.get(i)).readAllBytes(), StandardCharsets.UTF_8);
                String name = i < names.size() ? names.get(i) : ("Sheet" + (i + 1));
                out.add(new SheetData(name, parseSheet(sxml, shared)));
            }
            return out;
        }
    }

    private static List<String[]> parseSheet(String xml, List<String> shared) {
        List<String[]> rows = new ArrayList<>();
        Matcher rowMatcher = Pattern.compile("<row[^>]*>(.*?)</row>", Pattern.DOTALL).matcher(xml);
        while (rowMatcher.find() && rows.size() < TABLE_MAX_ROWS) {
            String rowXml = rowMatcher.group(1);
            List<String> cells = new ArrayList<>();
            Matcher cellMatcher = Pattern.compile("<c[^>]*>(.*?)</c>", Pattern.DOTALL).matcher(rowXml);
            while (cellMatcher.find() && cells.size() < TABLE_MAX_COLS) {
                cells.add(parseCell(cellMatcher.group(1), shared));
            }
            rows.add(cells.toArray(new String[0]));
        }
        return rows;
    }

    private static String parseCell(String cellXml, List<String> shared) {
        Matcher t = Pattern.compile("<t[^>]*>(.*?)</t>", Pattern.DOTALL).matcher(cellXml);
        if (t.find()) return unescape(t.group(1));
        Matcher v = Pattern.compile("<v[^>]*>(.*?)</v>", Pattern.DOTALL).matcher(cellXml);
        if (v.find()) {
            String val = unescape(v.group(1));
            if (cellXml.contains("t=\"s\"") || cellXml.contains("t='s'")) {
                try {
                    int idx = Integer.parseInt(val.trim());
                    return idx >= 0 && idx < shared.size() ? shared.get(idx) : val;
                } catch (NumberFormatException e) {
                    return val;
                }
            }
            return val;
        }
        return "";
    }

    /** 用 POI 提取 .xls（老格式）全部工作表。 */
    private static List<SheetData> extractXls(Path path) throws Exception {
        List<SheetData> out = new ArrayList<>();
        try (InputStream in = Files.newInputStream(path);
             HSSFWorkbook wb = new HSSFWorkbook(in)) {
            for (int s = 0; s < wb.getNumberOfSheets(); s++) {
                Sheet sheet = wb.getSheetAt(s);
                List<String[]> rows = new ArrayList<>();
                for (Row row : sheet) {
                    if (rows.size() >= TABLE_MAX_ROWS) break;
                    List<String> cells = new ArrayList<>();
                    int last = Math.min(row.getLastCellNum(), TABLE_MAX_COLS);
                    for (int c = 0; c < last; c++) {
                        cells.add(cellString(sheet, row, c));
                    }
                    rows.add(cells.toArray(new String[0]));
                }
                out.add(new SheetData(wb.getSheetName(s), rows));
            }
        }
        return out;
    }

    /** 取单元格显示值；空单元格落在合并区域内时，回填左上角的值。 */
    private static String cellString(Sheet sheet, Row row, int c) {
        Cell cell = row.getCell(c);
        if (cell != null) return FMT.formatCellValue(cell);
        for (CellRangeAddress region : sheet.getMergedRegions()) {
            if (region.isInRange(row.getRowNum(), c)
                    && !(region.getFirstRow() == row.getRowNum() && region.getFirstColumn() == c)) {
                Row firstRow = sheet.getRow(region.getFirstRow());
                Cell firstCell = firstRow == null ? null : firstRow.getCell(region.getFirstColumn());
                if (firstCell != null) return FMT.formatCellValue(firstCell);
            }
        }
        return "";
    }

    private static String colName(int idx) {
        StringBuilder sb = new StringBuilder();
        int n = idx + 1;
        while (n > 0) {
            int rem = (n - 1) % 26;
            sb.insert(0, (char) ('A' + rem));
            n = (n - 1) / 26;
        }
        return sb.toString();
    }

    private static String unescape(String s) {
        return s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                .replace("&quot;", "\"").replace("&apos;", "'").replace("&#10;", "\n");
    }

    private static String ext(String path) {
        int i = path.lastIndexOf('.');
        if (i < 0 || i == path.length() - 1) return "";
        return path.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    private static boolean isImage(String ext) {
        return switch (ext) {
            case "png", "jpg", "jpeg", "gif", "bmp" -> true;
            default -> false;
        };
    }

    private static boolean isMarkdown(String ext) {
        return "md".equals(ext) || "markdown".equals(ext);
    }

    /** 单个工作表的数据。 */
    private static final class SheetData {
        final String name;
        final List<String[]> rows;

        SheetData(String name, List<String[]> rows) {
            this.name = name;
            this.rows = rows;
        }
    }
}
