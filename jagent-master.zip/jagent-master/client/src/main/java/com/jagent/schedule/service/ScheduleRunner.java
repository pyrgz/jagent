package com.jagent.schedule.service;

import com.jagent.schedule.CronExpression;
import com.jagent.schedule.model.ScheduledTask;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * 客户端内定时调度器：每个启用任务一个 ScheduledFuture，独立循环执行。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ScheduleRunner {

    private static final Logger log = LogManager.getLogger(ScheduleRunner.class);

    private final ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "scheduler");
        t.setDaemon(true);
        return t;
    });
    private final ConcurrentHashMap<String, ScheduledFuture<?>> futures = new ConcurrentHashMap<>();

    /** 按当前任务列表重新调度：取消旧 future，为每个启用任务注册下一次执行。 */
    public void sync(List<ScheduledTask> tasks, Consumer<ScheduledTask> onFire) {
        for (ScheduledFuture<?> f : futures.values()) f.cancel(false);
        futures.clear();
        if (tasks == null) return;
        ZonedDateTime now = ZonedDateTime.now();
        for (ScheduledTask t : tasks) {
            if (t == null || !t.enabled) continue;
            schedule(t, now, onFire);
        }
    }

    private void schedule(ScheduledTask t, ZonedDateTime from, Consumer<ScheduledTask> onFire) {
        try {
            String cron = (t.cron == null || t.cron.isBlank()) ? "0 9 * * *" : t.cron;
            CronExpression ce = CronExpression.parse(cron);
            ZonedDateTime next = ce.next(from);
            if (next == null) {
                log.warn("定时任务无匹配时间：id={}, cron={}", t.id, cron);
                return;
            }
            long delay = Duration.between(ZonedDateTime.now(), next).toMillis();
            if (delay < 0) delay = 0;
            ScheduledFuture<?> f = exec.schedule(() -> {
                try {
                    onFire.accept(t);
                } finally {
                    schedule(t, ZonedDateTime.now(), onFire);
                }
            }, delay, TimeUnit.MILLISECONDS);
            futures.put(t.id, f);
            log.info("定时任务已调度：id={}, cron={}, 下次执行={}", t.id, cron, next);
        } catch (Exception e) {
            log.warn("定时任务调度失败：id={}, cron={}, 原因={}", t.id, t.cron, e.getMessage());
        }
    }

    public void shutdown() {
        exec.shutdownNow();
    }
}
