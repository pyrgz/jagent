package com.jagent.mcp.client;

/**
 * MCP 协议 / 传输异常。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class McpException extends RuntimeException {

    public McpException(String message) {
        super(message);
    }

    public McpException(String message, Throwable cause) {
        super(message, cause);
    }
}
