package com.jagent.harness.example;

import com.jagent.chat.tool.Tool;
import com.jagent.chat.tool.ToolKit;
import com.jagent.harness.Harness;
import com.google.gson.JsonObject;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Harness 工具链示例：在一次业务动作中按顺序调用多个内置工具。
 *
 * <p>执行链：{@code Glob（找文件） → Grep（找 TODO/FIXME） → Read（读取首个文件）}，
 * 不使用大模型，演示 Harness 对工具的编排能力。</p>
 *
 * <pre>
 * /harness tools
 * /harness tools **&#47;*.md
 * </pre>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ToolChainHarness implements Harness {

    private static final String DEFAULT_PATTERN = "**/*.java";
    private static final String GREP_PATTERN = "TODO|FIXME";

    private final Supplier<String> cwdSupplier;

    public ToolChainHarness(Supplier<String> cwdSupplier) {
        this.cwdSupplier = cwdSupplier;
    }

    @Override
    public String id() {
        return "tools";
    }

    @Override
    public String name() {
        return "工具链";
    }

    @Override
    public String execute(String input) {
        Path cwd = resolveRoot();
        if (cwd == null) return "工作目录不存在，无法执行工具链。";

        String pattern = input == null || input.isBlank() ? DEFAULT_PATTERN : input.trim();
        Map<String, Tool> tools = new HashMap<>();
        for (Tool tool : ToolKit.defaults(cwd)) {
            tools.put(tool.specification().name(), tool);
        }

        StringBuilder report = new StringBuilder("工具链执行\n")
                .append("- 工作目录：").append(cwd).append('\n')
                .append("- 步骤：Glob → Grep → Read\n");

        // 1. Glob：按模式查找文件
        JsonObject globArgs = new JsonObject();
        globArgs.addProperty("pattern", pattern);
        String glob = safeExecute(tools.get("Glob"), globArgs.toString());
        List<String> files = lines(glob);
        report.append("\n[1/3] Glob  pattern=").append(pattern).append('\n')
                .append("匹配文件：").append(files.size()).append(" 个\n")
                .append(preview(glob, 1000));

        // 2. Grep：对 Glob 命中的文件逐个搜索 TODO / FIXME
        int scanLimit = Math.min(files.size(), 30);
        List<String> hits = new ArrayList<>();
        for (int i = 0; i < scanLimit && hits.size() < 200; i++) {
            JsonObject grepArgs = new JsonObject();
            grepArgs.addProperty("pattern", GREP_PATTERN);
            grepArgs.addProperty("path", files.get(i));
            String grep = safeExecute(tools.get("Grep"), grepArgs.toString());
            if (grep.startsWith("未找到") || grep.startsWith("错误") || grep.startsWith("执行失败")) continue;
            for (String line : lines(grep)) {
                hits.add(files.get(i) + " | " + line);
            }
        }
        report.append("\n\n[2/3] Grep  pattern=").append(GREP_PATTERN).append("（逐个文件）\n")
                .append("扫描文件：").append(scanLimit).append(" 个")
                .append(files.size() > scanLimit ? "（共 " + files.size() + " 个，已截断）" : "")
                .append('\n')
                .append("命中：").append(hits.size()).append(" 处\n")
                .append(preview(String.join("\n", hits), 2000));

        // 3. Read：优先读取有命中的文件，否则读取首个 Glob 结果
        String target = files.isEmpty() ? null : files.get(0);
        if (!hits.isEmpty()) {
            String hitLine = hits.get(0);
            int sep = hitLine.indexOf(" | ");
            if (sep > 0) target = hitLine.substring(0, sep);
        }
        report.append("\n\n[3/3] Read  path=").append(target == null ? "（无）" : target).append('\n');
        if (target == null) {
            report.append("没有可读取的文件");
        } else {
            JsonObject readArgs = new JsonObject();
            readArgs.addProperty("path", target);
            report.append(preview(safeExecute(tools.get("Read"), readArgs.toString()), 1500));
        }
        report.append("\n\n工具调用：Glob 1 次 + Grep ").append(scanLimit)
                .append(" 次 + Read ").append(target == null ? 0 : 1).append(" 次");
        return report.toString().trim();
    }

    private Path resolveRoot() {
        String cwd = cwdSupplier == null ? null : cwdSupplier.get();
        Path root = (cwd == null || cwd.isBlank()) ? Path.of(System.getProperty("user.dir")) : Path.of(cwd);
        try {
            return Files.isDirectory(root) ? root.toAbsolutePath().normalize() : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** 只执行只读工具；任何异常都转换为文本，避免中断整个工具链。 */
    private static String safeExecute(Tool tool, String argumentsJson) {
        if (tool == null) return "错误：工具不可用";
        if (tool.requiresPermission()) return "错误：该工具需要权限确认，工具链仅使用只读工具";
        try {
            return tool.execute(argumentsJson);
        } catch (Exception e) {
            return "执行失败：" + (e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    private static List<String> lines(String output) {
        if (output == null || output.isBlank()) return List.of();
        if (output.startsWith("未找到") || output.startsWith("错误") || output.startsWith("执行失败")) {
            return List.of();
        }
        return Arrays.stream(output.split("\\R")).filter(s -> !s.isBlank()).toList();
    }

    private static String preview(String text, int limit) {
        if (text == null) return "";
        return text.length() <= limit ? text : text.substring(0, limit) + "\n…（已截断）";
    }
}
