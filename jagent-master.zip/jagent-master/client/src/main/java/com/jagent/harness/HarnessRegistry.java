package com.jagent.harness;

import com.jagent.common.exception.BusinessException;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 业务 harness 注册器：按 id 注册、查找，并统一初始化/关闭。
 * 纯 Java，无 JavaFX 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class HarnessRegistry {

    private final Map<String, Harness> harnesses = new LinkedHashMap<>();

    /** 注册一个 harness；重复 id 抛业务异常。 */
    public void register(Harness h) {
        if (h == null) throw new BusinessException("harness 不能为空");
        if (harnesses.containsKey(h.id())) {
            throw new BusinessException("harness 重复注册：" + h.id());
        }
        harnesses.put(h.id(), h);
    }

    public Harness get(String id) {
        return harnesses.get(id);
    }

    public List<Harness> all() {
        return new ArrayList<>(harnesses.values());
    }

    /** 按注册顺序初始化所有 harness。 */
    public void initializeAll() {
        for (Harness h : harnesses.values()) {
            h.initialize();
        }
    }

    /** 按注册逆序关闭所有 harness（先停上层依赖，如 schedule → chat）。 */
    public void shutdownAll() {
        List<Harness> list = all();
        for (int i = list.size() - 1; i >= 0; i--) {
            list.get(i).shutdown();
        }
    }
}
