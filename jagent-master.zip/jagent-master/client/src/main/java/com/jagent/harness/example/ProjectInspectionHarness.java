package com.jagent.harness.example;

import com.jagent.harness.Harness;
import com.jagent.harness.HarnessPipeline;
import com.jagent.mcp.service.McpService;
import com.jagent.skill.service.SkillService;

import java.util.List;
import java.util.function.Supplier;

/**
 * Harness 编排示例：把「项目统计 → 技能检查 → MCP 工具检查」串成一条巡检流水线。
 *
 * <p>在对话框中执行：</p>
 * <pre>
 * /harness inspect
 * /harness inspect client/src/main/java
 * </pre>
 *
 * <p>使用 {@link HarnessPipeline#execute(String)} 按顺序执行多个 harness，
 * 单个步骤失败不会中断后续步骤，最终聚合为一份巡检报告。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ProjectInspectionHarness implements Harness {

    private final Supplier<String> cwdSupplier;
    private final SkillService skills;
    private final McpService mcp;

    public ProjectInspectionHarness(Supplier<String> cwdSupplier, SkillService skills, McpService mcp) {
        this.cwdSupplier = cwdSupplier;
        this.skills = skills;
        this.mcp = mcp;
    }

    @Override
    public String id() {
        return "inspect";
    }

    @Override
    public String name() {
        return "项目巡检";
    }

    @Override
    public String execute(String input) {
        HarnessPipeline pipeline = new HarnessPipeline()
                .add(new ProjectStatsHarness(cwdSupplier))
                .add(skills)
                .add(mcp);

        List<HarnessPipeline.StepResult> results = pipeline.execute(input);
        StringBuilder report = new StringBuilder("项目巡检报告\n");
        for (int i = 0; i < results.size(); i++) {
            HarnessPipeline.StepResult step = results.get(i);
            report.append('\n')
                    .append('[').append(i + 1).append('/').append(results.size()).append("] ")
                    .append(step.name()).append('\n');
            report.append(step.ok() ? step.output() : "执行失败：" + step.error()).append('\n');
        }
        return report.toString().trim();
    }
}
