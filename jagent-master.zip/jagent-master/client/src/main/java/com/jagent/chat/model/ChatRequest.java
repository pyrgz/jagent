package com.jagent.chat.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 一次聊天请求的数据持有类（后端无关）。由 {@code ChatService} 组装后交给
 * 具体后端（CodeBuddy 桥接 / langchain4j 直连）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ChatRequest {
    public String conversationId;
    public String message;
    public String model;
    /** Agent 工作目录（CodeBuddy 后端使用） */
    public String cwd;
    /** 权限模式（CodeBuddy 后端使用） */
    public String permissionMode;
    /** SDK 会话 ID，用于恢复上下文（CodeBuddy 后端使用） */
    public String resume;
    /** 追加到系统提示词的内容（技能等） */
    public String systemPromptAppend;
    /** 当前会话的历史消息（langchain4j 后端用于多轮上下文） */
    public List<ChatMessage> history = new ArrayList<>();
}
