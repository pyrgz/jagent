package com.jagent.schedule.model;

import java.util.UUID;

/**
 * 定时任务（当前仅保存配置，执行逻辑待后续版本接入）
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ScheduledTask {
    public String id = UUID.randomUUID().toString();
    /** 5 段 cron 表达式（分 时 日 月 周） */
    public String cron = "0 9 * * *";
    /** 定时发送的消息内容 */
    public String content = "";
    /** 绑定的专属会话 ID（空表示尚未绑定，触发时自动创建） */
    public String conversationId = "";
    public boolean enabled = true;
    public long createdAt = System.currentTimeMillis();
}
