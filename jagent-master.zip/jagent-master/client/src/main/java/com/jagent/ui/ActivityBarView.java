package com.jagent.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 * 最左侧竖向图标栏（仿 IDEA Activity Bar）：文件 / 定时 / 主题 + 预留按钮。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ActivityBarView {

    private final VBox root;
    private final Button chatBtn;
    private final Button explorerBtn;
    private final Button skillsBtn;
    private final Button knowledgeBtn;

    public ActivityBarView(Runnable onSchedule, Runnable onToggleTheme, Runnable onChat,
                           Runnable onExplorer, Runnable onSkills, Runnable onKnowledge, Runnable onReserved) {
        root = new VBox(8);
        root.getStyleClass().add("activity-bar");
        root.setAlignment(Pos.TOP_CENTER);
        root.setPadding(new Insets(12, 0, 12, 0));
        root.setPrefWidth(52);
        root.setMinWidth(52);
        root.setMaxWidth(52);

        chatBtn = iconButton(Icons.stroke(Icons.CHAT, 20, Color.web("#646A73")), "会话");
        chatBtn.setOnAction(e -> onChat.run());

        explorerBtn = iconButton(Icons.stroke(Icons.FOLDER, 20, Color.web("#646A73")), "文件 / 打开工作区");
        explorerBtn.setOnAction(e -> onExplorer.run());

        Button schedule = iconButton(Icons.stroke(Icons.CLOCK, 20, Color.web("#646A73")), "定时");
        schedule.setOnAction(e -> onSchedule.run());

        Button theme = iconButton(Icons.stroke(Icons.PAINT, 20, Color.web("#646A73")), "切换主题");
        theme.setOnAction(e -> onToggleTheme.run());

        skillsBtn = iconButton(Icons.stroke(Icons.SPARK, 20, Color.web("#646A73")), "技能");
        skillsBtn.setOnAction(e -> onSkills.run());

        knowledgeBtn = iconButton(Icons.stroke(Icons.BOOK, 20, Color.web("#646A73")), "知识库 / 文档问答");
        knowledgeBtn.setOnAction(e -> onKnowledge.run());

        Button reservedPlug = iconButton(Icons.stroke(Icons.PLUG, 20, Color.web("#98A0AB")), "预留功能");
        reservedPlug.setOnAction(e -> onReserved.run());

        root.getChildren().addAll(chatBtn, explorerBtn, schedule, theme, skillsBtn, knowledgeBtn, reservedPlug);
    }

    private Button iconButton(Node icon, String tip) {
        Button b = new Button();
        b.setGraphic(icon);
        b.getStyleClass().add("activity-btn");
        b.setTooltip(new Tooltip(tip));
        return b;
    }

    /** 切换「会话」按钮的选中态。 */
    public void setChatActive(boolean active) {
        if (active) {
            if (!chatBtn.getStyleClass().contains("active")) {
                chatBtn.getStyleClass().add("active");
            }
        } else {
            chatBtn.getStyleClass().remove("active");
        }
    }

    /** 切换「文件」按钮的选中态。 */
    public void setExplorerActive(boolean active) {
        if (active) {
            if (!explorerBtn.getStyleClass().contains("active")) {
                explorerBtn.getStyleClass().add("active");
            }
        } else {
            explorerBtn.getStyleClass().remove("active");
        }
    }

    /** 切换「技能」按钮的选中态。 */
    public void setSkillsActive(boolean active) {
        if (active) {
            if (!skillsBtn.getStyleClass().contains("active")) {
                skillsBtn.getStyleClass().add("active");
            }
        } else {
            skillsBtn.getStyleClass().remove("active");
        }
    }

    /** 切换「知识库」按钮的选中态。 */
    public void setKnowledgeActive(boolean active) {
        if (active) {
            if (!knowledgeBtn.getStyleClass().contains("active")) {
                knowledgeBtn.getStyleClass().add("active");
            }
        } else {
            knowledgeBtn.getStyleClass().remove("active");
        }
    }

    public Node node() {
        return root;
    }
}
