package com.jagent;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import com.jagent.ui.Theme;
import javafx.scene.image.PixelReader;
import javafx.scene.image.PixelFormat;
import javafx.scene.image.WritableImage;
import javafx.stage.Stage;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * JavaFX 客户端入口。
 * 支持 --screenshot 参数：启动 3 秒后截图保存到 data/screenshot.png 并退出（用于自检）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class App extends Application {

    /** 客户端版本号（与 pom.xml 保持一致） */
    public static final String VERSION = "1.0.0";

    private ChatController controller;

    @Override
    public void start(Stage stage) {
        controller = new ChatController(stage);
        Scene scene = new Scene(controller.getRoot(), 1240, 820);
        Theme.applyTo(scene);

        stage.setTitle("jagent Agent");
        applyIcon(stage);
        stage.setMinWidth(980);
        stage.setMinHeight(640);
        stage.setScene(scene);
        stage.show();
        stage.setOnCloseRequest(e -> {
            controller.shutdown();
            Platform.exit();
        });

        controller.bootstrap();

        List<String> params = getParameters().getRaw();
        if (params.contains("--screenshot")) {
            PauseTransition delay = new PauseTransition(Duration.seconds(4));
            delay.setOnFinished(e -> {
                try {
                    WritableImage image = scene.snapshot(null);
                    savePng(image, Path.of(System.getProperty("user.dir"), "data", "screenshot.png").toFile());
                    System.out.println("[Screenshot] 已保存 data/screenshot.png");
                } catch (Exception ex) {
                    System.err.println("[Screenshot] 失败: " + ex);
                } finally {
                    controller.shutdown();
                    Platform.exit();
                }
            });
            delay.play();
        }
    }

    /** 将 WritableImage 保存为 PNG（不依赖 javafx.swing） */
    private static void savePng(WritableImage image, File file) throws Exception {
        int w = (int) image.getWidth();
        int h = (int) image.getHeight();
        PixelReader reader = image.getPixelReader();
        int[] buffer = new int[w * h];
        reader.getPixels(0, 0, w, h, PixelFormat.getIntArgbInstance(), buffer, 0, w);
        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                bi.setRGB(x, y, buffer[y * w + x]);
            }
        }
        file.getParentFile().mkdirs();
        ImageIO.write(bi, "png", file);
    }

    public static void main(String[] args) {
        launch(args);
    }

    /** 设置窗口图标（Windows 标题栏/任务栏、macOS 窗口）与 macOS Dock 图标。 */
    private static void applyIcon(Stage stage) {
        byte[] png = loadIconPng();
        if (png != null) {
            stage.getIcons().add(new javafx.scene.image.Image(new ByteArrayInputStream(png)));
        }
        setDockIcon(png);
    }

    /** 定位 icon.png：优先从 classpath（Maven 的 target/classes）读取，
     *  失败时从文件系统向上查找（javac 流程的 src/main/resources，兼容 client/ 与仓库根两种工作目录），
     *  避免因构建方式不同导致 macOS Dock / Windows 任务栏显示默认 Java 图标。 */
    private static byte[] loadIconPng() {
        try (java.io.InputStream in = App.class.getResourceAsStream("/icon.png")) {
            if (in != null) return in.readAllBytes();
        } catch (Exception ignored) {
        }
        Path dir = Path.of(System.getProperty("user.dir"));
        for (int i = 0; i < 4 && dir != null; i++, dir = dir.getParent()) {
            for (String rel : new String[]{"src/main/resources/icon.png", "client/src/main/resources/icon.png"}) {
                Path p = dir.resolve(rel);
                if (Files.isRegularFile(p)) {
                    try {
                        return Files.readAllBytes(p);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        return null;
    }

    /** macOS Dock 图标：反射调用 com.apple.eawt.Application，避免 Windows/Linux 编译期依赖。 */
    private static void setDockIcon(byte[] png) {
        if (png == null) return;
        try {
            BufferedImage awt = ImageIO.read(new ByteArrayInputStream(png));
            if (awt == null) return;
            Class<?> appCls = Class.forName("com.apple.eawt.Application");
            Object app = appCls.getMethod("getApplication").invoke(null);
            appCls.getMethod("setDockIconImage", java.awt.Image.class).invoke(app, awt);
        } catch (Throwable ignored) {
        }
    }
}
