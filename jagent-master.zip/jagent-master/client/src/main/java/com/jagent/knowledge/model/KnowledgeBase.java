package com.jagent.knowledge.model;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 知识库（持久化到 data/knowledge.json）
 *
 * @author azhu
 * @date 2026-10-24
 */
public class KnowledgeBase {
    public String id = UUID.randomUUID().toString();
    public String name = "新建知识库";
    /** 文档拆分：最大块字符数 */
    public int chunkSize = 300;
    /** 相邻块重叠字符数 */
    public int chunkOverlap = 30;
    /** 入库所用嵌入模型名（向量一致性守卫） */
    public String embeddingModel = "";
    public long createdAt = System.currentTimeMillis();
    public long updatedAt = System.currentTimeMillis();
    public List<KnowledgeDocument> documents = new ArrayList<>();
}
