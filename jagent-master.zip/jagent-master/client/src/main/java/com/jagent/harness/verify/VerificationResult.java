package com.jagent.harness.verify;

/**
 * 单条验收规则的结果。
 *
 * @author azhu
 * @date 2026-10-24
 */
public record VerificationResult(boolean passed, String message) {

    public static VerificationResult pass(String message) {
        return new VerificationResult(true, message);
    }

    public static VerificationResult fail(String message) {
        return new VerificationResult(false, message);
    }
}
