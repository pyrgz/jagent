package com.jagent;

import com.jagent.harness.Harness;
import com.jagent.harness.HarnessRegistry;

/**
 * Headless 运行入口：无 JavaFX，通过 {@link ServiceAssembler} 复用与 GUI 相同的 service 组装，
 * 再经 {@link HarnessRegistry} 统一管理生命周期。演示 harness 框架的 headless 能力。
 *
 * <p>运行：{@code java -cp "client/out:client/lib/*" com.codebuddy.agent.HeadlessMain}</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class HeadlessMain {

    public static void main(String[] args) {
        ServiceAssembler.Services services = ServiceAssembler.assemble();
        HarnessRegistry registry = services.harnesses;

        // 统一初始化（connectivity.bootstrap 异步执行，不阻塞）
        registry.initializeAll();

        System.out.println("已注册业务 harness：");
        for (Harness h : registry.all()) {
            System.out.println("  - " + h.id() + "（" + h.name() + "）");
        }

        // 统一关闭（逆序：先停后台服务，最后保存数据）
        registry.shutdownAll();
        System.out.println("全部 harness 已关闭。");
    }
}
