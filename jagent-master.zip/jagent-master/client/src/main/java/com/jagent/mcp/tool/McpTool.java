package com.jagent.mcp.tool;

import com.jagent.chat.tool.Tool;
import com.jagent.mcp.client.McpClient;
import com.jagent.mcp.model.McpToolDef;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.langchain4j.agent.tool.ToolSpecification;

/**
 * 把 MCP Server 的工具适配为 langchain4j 后端的 {@link Tool}。
 * MCP 工具可能有副作用，统一走现有的权限确认流程。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class McpTool implements Tool {

    private static final int MAX_RESULT_CHARS = 20000;

    private final String specName;
    private final McpToolDef def;
    private final McpClient client;
    private volatile ToolSpecification specification;

    public McpTool(String specName, McpToolDef def, McpClient client) {
        this.specName = specName;
        this.def = def;
        this.client = client;
    }

    @Override
    public ToolSpecification specification() {
        ToolSpecification current = specification;
        if (current == null) {
            current = ToolSpecification.builder()
                    .name(specName)
                    .description(def.description() == null ? "" : def.description())
                    .parameters(McpSchemaMapper.toObjectSchema(def.inputSchema()))
                    .build();
            specification = current;
        }
        return current;
    }

    @Override
    public String execute(String argumentsJson) throws Exception {
        JsonObject arguments;
        if (argumentsJson == null || argumentsJson.isBlank()) {
            arguments = new JsonObject();
        } else {
            arguments = JsonParser.parseString(argumentsJson).getAsJsonObject();
        }
        JsonObject result = client.callTool(def.name(), arguments);
        boolean isError = result.has("isError") && !result.get("isError").isJsonNull()
                && result.get("isError").getAsBoolean();
        String text = formatResult(result);
        return isError ? "工具执行失败：" + text : text;
    }

    @Override
    public boolean requiresPermission() {
        // MCP 工具由第三方服务提供，默认都需要用户确认
        return true;
    }

    private static String formatResult(JsonObject result) {
        StringBuilder sb = new StringBuilder();
        if (result.has("content") && result.get("content").isJsonArray()) {
            for (JsonElement el : result.getAsJsonArray("content")) {
                if (!el.isJsonObject()) continue;
                JsonObject item = el.getAsJsonObject();
                String type = str(item, "type");
                String text = "text".equals(type) ? str(item, "text") : item.toString();
                if (text != null && !text.isEmpty()) sb.append(text).append('\n');
            }
        }
        if (sb.length() == 0 && result.has("structuredContent") && !result.get("structuredContent").isJsonNull()) {
            sb.append(result.get("structuredContent"));
        }
        if (sb.length() == 0) sb.append(result);
        String text = sb.toString().trim();
        return text.length() > MAX_RESULT_CHARS
                ? text.substring(0, MAX_RESULT_CHARS) + "\n…（结果过长已截断）"
                : text;
    }

    private static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
    }
}
