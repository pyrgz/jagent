package com.jagent.chat.service;

import com.jagent.harness.Harness;
import com.jagent.chat.model.Conversation;
import com.jagent.settings.service.SettingsService;
import com.jagent.store.Store;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 会话生命周期：增删改查、当前会话、持久化。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class SessionService implements Harness {

    private static final Logger log = LogManager.getLogger(SessionService.class);

    @Override
    public String id() { return "session"; }

    @Override
    public String name() { return "会话"; }

    @Override
    public void shutdown() { persist(); }

    private final List<Conversation> conversations = new ArrayList<>();
    private Conversation current;
    private final SettingsService settings;
    private Runnable onChange;

    public SessionService(SettingsService settings) {
        this.settings = settings;
        load();
    }

    private void load() {
        List<Conversation> loaded = Store.loadConversations();
        if (loaded != null) conversations.addAll(loaded);
        if (conversations.isEmpty()) {
            current = create(false);
        } else {
            current = conversations.get(0);
        }
        ensureLoaded(current);
        log.info("会话加载完成：共 {} 个，当前 {}", conversations.size(),
                current == null ? "无" : current.id);
    }

    public Conversation create(boolean select) {
        Conversation c = new Conversation();
        c.id = UUID.randomUUID().toString();
        if (settings.settings().model != null && !settings.settings().model.isBlank()) {
            c.model = settings.settings().model;
        }
        conversations.add(0, c);
        persist();
        if (select) select(c);
        log.info("创建会话：id={}, 总数={}", c.id, conversations.size());
        return c;
    }

    public void select(Conversation c) {
        ensureLoaded(c);
        current = c;
        notifyChanged();
        log.info("切换会话：{}", c == null ? "无" : c.id);
    }

    public void selectById(String id) {
        Conversation c = findById(id);
        if (c != null) select(c);
    }

    public void delete(Conversation c) {
        conversations.remove(c);
        if (c != null) Store.deleteMessages(c.id);
        persist();
        if (c == current) {
            if (conversations.isEmpty()) {
                current = create(false);
            } else {
                current = conversations.get(0);
                ensureLoaded(current);
            }
        }
        notifyChanged();
        log.info("删除会话：id={}, 剩余={}", c == null ? "无" : c.id, conversations.size());
    }

    public Conversation current() {
        return current;
    }

    public List<Conversation> all() {
        return conversations;
    }

    public Conversation findById(String id) {
        if (id == null || id.isBlank()) return null;
        for (Conversation c : conversations) {
            if (id.equals(c.id)) {
                ensureLoaded(c);
                return c;
            }
        }
        return null;
    }

    /** 首次访问会话时从独立文件加载消息（启动时只加载当前会话）。 */
    private void ensureLoaded(Conversation c) {
        if (c == null || c.messagesLoaded) return;
        c.messages = Store.loadMessages(c.id);
        c.messagesLoaded = true;
        log.info("加载会话消息：id={}, {} 条", c.id, c.messages.size());
    }

    public void persist() {
        Store.saveConversations(conversations);
    }

    public void setCurrentModel(String modelId) {
        if (current != null) {
            current.model = modelId;
            persist();
        }
    }

    public void setOnChanged(Runnable onChange) {
        this.onChange = onChange;
    }

    private void notifyChanged() {
        if (onChange != null) onChange.run();
    }
}
