package com.jagent.store;

import com.jagent.settings.model.AppSettings;
import com.jagent.settings.model.ProviderPreset;
import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.Conversation;
import com.jagent.knowledge.model.KnowledgeBase;
import com.jagent.schedule.model.ScheduledTask;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * 本地持久化（JSON 文件）。
 *
 * <p>会话采用「索引 + 独立消息文件」结构：{@code conversations.json} 只保存元数据，
 * 每个会话的消息保存在 {@code conversations/<id>.json}，按需加载，避免单个文件过大。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class Store {
    private static final Logger log = LogManager.getLogger(Store.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    /** 消息文件体积大且无需人工阅读，使用紧凑格式。 */
    private static final Gson GSON_COMPACT = new Gson();
    private static final Path DATA_DIR = resolveDataDir();
    private static final Path CONVERSATIONS_DIR = DATA_DIR.resolve("conversations");

    /** 会话模型的结构性变更（如 toolCalls.add）与序列化共用的锁，避免并行流式时竞态。 */
    public static final Object PERSIST_LOCK = new Object();

    private Store() {}

    private static Path resolveDataDir() {
        Path candidate = Path.of(System.getProperty("user.dir"), "data");
        try {
            Files.createDirectories(candidate);
            return candidate;
        } catch (IOException e) {
            Path home = Path.of(System.getProperty("user.home"), ".codebuddy-javafx");
            try {
                Files.createDirectories(home);
            } catch (IOException ignored) {
            }
            return home;
        }
    }

    public static Path dataDir() {
        return DATA_DIR;
    }

    public static AppSettings loadSettings() {
        try {
            Path p = DATA_DIR.resolve("settings.json");
            if (Files.exists(p)) {
                AppSettings s = GSON.fromJson(Files.readString(p), AppSettings.class);
                if (s != null) return s;
            }
        } catch (Exception ignored) {
        }
        return new AppSettings();
    }

    public static void saveSettings(AppSettings s) {
        write("settings.json", GSON.toJson(s));
    }

    /** 只加载会话元数据；消息在 {@link #loadMessages(String)} 中按需加载。 */
    public static List<Conversation> loadConversations() {
        List<Conversation> list = new ArrayList<>();
        try {
            Path p = DATA_DIR.resolve("conversations.json");
            if (Files.exists(p)) {
                List<Conversation> loaded = GSON.fromJson(Files.readString(p),
                        new TypeToken<List<Conversation>>() {
                        }.getType());
                if (loaded != null) list.addAll(loaded);
            }
        } catch (Exception ignored) {
        }
        synchronized (PERSIST_LOCK) {
            boolean migrated = false;
            for (Conversation c : list) {
                if (c.messages != null && !c.messages.isEmpty()) {
                    // 兼容旧版：消息内嵌在 conversations.json，拆分到独立文件并重写索引
                    saveMessages(c.id, c.messages);
                    c.messagesLoaded = true;
                    migrated = true;
                } else {
                    c.messages = new ArrayList<>();
                    c.messagesLoaded = false;
                }
            }
            if (migrated) writeConversationIndex(list);
        }
        return list;
    }

    /** 保存会话索引；已加载的会话同时把消息写入各自独立文件。 */
    public static void saveConversations(List<Conversation> list) {
        synchronized (PERSIST_LOCK) {
            writeConversationIndex(list);
            if (list == null) return;
            for (Conversation c : list) {
                if (c != null && c.messagesLoaded && c.messages != null && !c.messages.isEmpty()) {
                    saveMessages(c.id, c.messages);
                }
            }
        }
    }

    /** 按会话加载消息文件；文件不存在或读取失败时返回空列表。 */
    public static List<ChatMessage> loadMessages(String convId) {
        if (convId == null || convId.isBlank()) return new ArrayList<>();
        synchronized (PERSIST_LOCK) {
            try {
                Path p = messageFile(convId);
                if (Files.exists(p)) {
                    List<ChatMessage> list = GSON_COMPACT.fromJson(Files.readString(p),
                            new TypeToken<List<ChatMessage>>() {
                            }.getType());
                    if (list != null) return list;
                }
            } catch (Exception e) {
                log.error("读取会话消息失败：{}", convId, e);
            }
        }
        return new ArrayList<>();
    }

    public static void saveMessages(String convId, List<ChatMessage> messages) {
        if (convId == null || convId.isBlank()) return;
        synchronized (PERSIST_LOCK) {
            try {
                Files.createDirectories(CONVERSATIONS_DIR);
                Files.writeString(messageFile(convId),
                        GSON_COMPACT.toJson(messages == null ? new ArrayList<>() : messages));
            } catch (IOException e) {
                log.error("保存会话消息失败：{}", convId, e);
            }
        }
    }

    /** 删除会话时同步删除其消息文件。 */
    public static void deleteMessages(String convId) {
        if (convId == null || convId.isBlank()) return;
        synchronized (PERSIST_LOCK) {
            try {
                Files.deleteIfExists(messageFile(convId));
            } catch (IOException e) {
                log.warn("删除会话消息失败：{}", convId, e);
            }
        }
    }

    /** 写 conversations.json：仅元数据（不包含 messages）。 */
    private static void writeConversationIndex(List<Conversation> list) {
        List<Conversation> index = new ArrayList<>();
        if (list != null) {
            for (Conversation c : list) {
                if (c == null) continue;
                Conversation meta = new Conversation();
                meta.id = c.id;
                meta.title = c.title;
                meta.model = c.model;
                meta.skillPath = c.skillPath;
                meta.sdkSessionId = c.sdkSessionId;
                meta.createdAt = c.createdAt;
                meta.updatedAt = c.updatedAt;
                meta.messages = null; // Gson 默认忽略 null 字段
                index.add(meta);
            }
        }
        write("conversations.json", GSON.toJson(index));
    }

    private static Path messageFile(String convId) {
        String safe = convId.replaceAll("[^a-zA-Z0-9._-]", "_");
        return CONVERSATIONS_DIR.resolve(safe + ".json");
    }

    public static List<ScheduledTask> loadSchedules() {
        try {
            Path p = DATA_DIR.resolve("schedules.json");
            if (Files.exists(p)) {
                List<ScheduledTask> list = GSON.fromJson(Files.readString(p),
                        new TypeToken<List<ScheduledTask>>() {
                        }.getType());
                if (list != null) return list;
            }
        } catch (Exception ignored) {
        }
        return new ArrayList<>();
    }

    public static void saveSchedules(List<ScheduledTask> list) {
        write("schedules.json", GSON.toJson(list));
    }

    /** 已加载技能的目录路径列表（持久化到 skills.json）。 */
    public static List<String> loadLoadedSkills() {
        try {
            Path p = DATA_DIR.resolve("skills.json");
            if (Files.exists(p)) {
                List<String> list = GSON.fromJson(Files.readString(p),
                        new TypeToken<List<String>>() {
                        }.getType());
                if (list != null) return list;
            }
        } catch (Exception ignored) {
        }
        return new ArrayList<>();
    }

    public static void saveLoadedSkills(List<String> paths) {
        write("skills.json", GSON.toJson(paths == null ? new ArrayList<>() : paths));
    }

    /** 知识库元数据列表（持久化到 knowledge.json）。 */
    public static List<KnowledgeBase> loadKnowledgeBases() {
        try {
            Path p = DATA_DIR.resolve("knowledge.json");
            if (Files.exists(p)) {
                List<KnowledgeBase> list = GSON.fromJson(Files.readString(p),
                        new TypeToken<List<KnowledgeBase>>() {
                        }.getType());
                if (list != null) return list;
            }
        } catch (Exception ignored) {
        }
        return new ArrayList<>();
    }

    public static void saveKnowledgeBases(List<KnowledgeBase> list) {
        write("knowledge.json", GSON.toJson(list == null ? new ArrayList<>() : list));
    }

    /** 模型服务商预设列表（持久化到 providers.json；不存在时写入默认预设）。 */
    public static List<ProviderPreset> loadProviders() {
        try {
            Path p = DATA_DIR.resolve("providers.json");
            if (Files.exists(p)) {
                List<ProviderPreset> list = GSON.fromJson(Files.readString(p),
                        new TypeToken<List<ProviderPreset>>() {
                        }.getType());
                if (list != null && !list.isEmpty()) return list;
            }
        } catch (Exception ignored) {
        }
        List<ProviderPreset> defaults = defaultProviders();
        saveProviders(defaults);
        return defaults;
    }

    public static void saveProviders(List<ProviderPreset> list) {
        write("providers.json", GSON.toJson(list == null ? new ArrayList<>() : list));
    }

    private static List<ProviderPreset> defaultProviders() {
        List<ProviderPreset> list = new ArrayList<>();
        list.add(preset("DeepSeek", "https://api.deepseek.com/v1", "deepseek-flash", "deepseek-v4-pro"));
        list.add(preset("通义千问", "https://dashscope.aliyuncs.com/compatible-mode/v1",
                "qwen3.8-max", "qwen3.7-plus", "qwen3.7-flash"));
        list.add(preset("智谱 GLM", "https://open.bigmodel.cn/api/paas/v4",
                "GLM-5.3", "GLM-5.3-Flash", "GLM-5.2"));
        list.add(preset("Kimi", "https://api.moonshot.cn/v1", "kimi-k2.7-code", "kimi-k3"));
        list.add(preset("硅基流动", "https://api.siliconflow.cn/v1",
                "deepseek-ai/DeepSeek-V4-Flash", "Qwen/Qwen3.8-27B", "zai-org/GLM-5.3"));
        return list;
    }

    private static ProviderPreset preset(String name, String baseUrl, String... models) {
        ProviderPreset p = new ProviderPreset();
        p.name = name;
        p.baseUrl = baseUrl;
        p.models.addAll(List.of(models));
        return p;
    }

    private static void write(String name, String json) {
        try {
            Files.writeString(DATA_DIR.resolve(name), json);
        } catch (IOException e) {
            log.error("保存数据文件失败：{}", name, e);
        }
    }
}
