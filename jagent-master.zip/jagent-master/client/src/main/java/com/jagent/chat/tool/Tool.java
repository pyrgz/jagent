package com.jagent.chat.tool;

import dev.langchain4j.agent.tool.ToolSpecification;

/**
 * 供 langchain4j 后端调用的工具抽象。纯 Java，无 UI 依赖，可扩展新工具。
 *
 * @author azhu
 * @date 2026-10-24
 */
public interface Tool {

    /** 工具元数据（名称 / 描述 / 参数 JSON Schema），模型据此理解如何调用。 */
    ToolSpecification specification();

    /** 执行工具；arguments 为模型下发的参数 JSON 字符串，返回结果文本。 */
    String execute(String argumentsJson) throws Exception;

    /** 是否需要用户授权（副作用操作，如 Bash / Write）。 */
    boolean requiresPermission();
}
