package com.jagent.mcp.model;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * data/mcp.json 的根配置，格式与 Claude Desktop 的 mcpServers 保持一致。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class McpConfig {

    public Map<String, McpServerConfig> mcpServers = new LinkedHashMap<>();
}
