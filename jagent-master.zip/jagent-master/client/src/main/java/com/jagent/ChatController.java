package com.jagent;

import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.Conversation;
import com.jagent.chat.model.ModelInfo;
import com.jagent.schedule.model.ScheduledTask;
import com.jagent.skill.model.Skill;
import com.jagent.chat.model.ToolCall;
import com.jagent.chat.service.ChatService;
import com.jagent.chat.service.CodeBuddyBackend;
import com.jagent.connectivity.service.ConnectivityService;
import com.jagent.harness.Harness;
import com.jagent.harness.HarnessRegistry;
import com.jagent.harness.audit.HarnessAudit;
import com.jagent.jagent.service.JagentService;
import com.jagent.knowledge.service.KnowledgeService;
import com.jagent.knowledge.service.KnowledgeStore;
import com.jagent.chat.service.Langchain4jBackend;
import com.jagent.schedule.service.ScheduleService;
import com.jagent.chat.service.SessionService;
import com.jagent.settings.service.SettingsService;
import com.jagent.skill.service.SkillService;
import com.jagent.store.Store;
import com.jagent.ui.Icons;
import com.jagent.workspace.service.WorkspaceService;
import com.jagent.ui.ActivityBarView;
import com.jagent.ui.ChatAreaView;
import com.jagent.ui.ComposerView;
import com.jagent.ui.Dialogs;
import com.jagent.ui.FileTreeView;
import com.jagent.ui.FileViewerView;
import com.jagent.ui.KnowledgeView;
import com.jagent.ui.MessageNode;
import com.jagent.ui.SidebarView;
import com.jagent.ui.SkillView;
import com.jagent.ui.Theme;
import com.google.gson.JsonObject;
import javafx.application.Platform;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 客户端协调层：构建视图、构造 service、把 UI 动作转发给 service、把 service 事件转发给视图。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ChatController {

    private final Stage stage;

    // ---- service ----
    private final SettingsService settings;
    private final SessionService sessions;
    private final ChatService chat;
    private final ScheduleService schedule;
    private final ConnectivityService connectivity;
    private final WorkspaceService workspace;
    private final SkillService skills;
    private final CodeBuddyBackend codebuddy;
    private final Langchain4jBackend langchain4j;
    private final KnowledgeStore knowledgeStore;
    private final KnowledgeService knowledge;
    private final JagentService jagent;
    private final HarnessRegistry harnesses;

    // ---- 视图 ----
    private final SidebarView sidebar;
    private final ActivityBarView activityBar;
    private final ChatAreaView chatArea;
    private final ComposerView composer;
    private final Label topTitle;
    private final ComboBox<ModelInfo> modelCombo;
    private final HBox errorBanner;
    private final BorderPane root;
    private final StackPane sidebarHolder;
    private final FileTreeView fileTree;
    private final FileViewerView fileViewer;
    private final SkillView skillView;
    private final KnowledgeView knowledgeView;
    private final Label providerBadge;
    private final VBox chatLayer;
    private final StackPane centerStack;

    private Label bannerText;
    private MessageNode activeNode;
    private boolean sidebarExpanded = true;
    private boolean explorerMode = false;
    private boolean skillsMode = false;
    private boolean knowledgeMode = false;

    public ChatController(Stage stage) {
        this.stage = stage;

        // ---- 组装 service + 注册业务 harness ----
        ServiceAssembler.Services services = ServiceAssembler.assemble();
        this.settings = services.settings;
        this.sessions = services.sessions;
        this.skills = services.skills;
        this.codebuddy = services.codebuddy;
        this.langchain4j = services.langchain4j;
        this.knowledgeStore = services.knowledgeStore;
        this.knowledge = services.knowledge;
        this.jagent = services.jagent;
        this.chat = services.chat;
        this.schedule = services.schedule;
        this.connectivity = services.connectivity;
        this.workspace = services.workspace;
        this.harnesses = services.harnesses;

        // ---------- 顶部栏 ----------
        Button menuBtn = new Button();
        menuBtn.getStyleClass().add("btn-icon");
        menuBtn.setGraphic(IconsHolder.menu());
        menuBtn.setOnAction(e -> toggleSidebar());

        topTitle = new Label("新会话");
        topTitle.getStyleClass().add("topbar-title");

        modelCombo = new ComboBox<>();
        modelCombo.getStyleClass().add("model-combo");
        modelCombo.setPrefWidth(200);
        modelCombo.setVisibleRowCount(12);
        modelCombo.setButtonCell(new ModelCell());
        modelCombo.setCellFactory(lv -> new ModelCell());
        modelCombo.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n != null && !"langchain4j".equals(settings.settings().provider)) {
                settings.settings().model = n.modelId;
                sessions.setCurrentModel(n.modelId);
                settings.save();
            }
        });

        providerBadge = new Label();
        providerBadge.getStyleClass().add("provider-badge");
        providerBadge.setOnMouseClicked(e -> openSettings());

        Button settingsBtn = new Button();
        settingsBtn.getStyleClass().add("btn-icon");
        settingsBtn.setGraphic(IconsHolder.settings());
        settingsBtn.setOnAction(e -> showSystemMenu(settingsBtn));

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox topbar = new HBox(10, menuBtn, topTitle, sp, modelCombo, providerBadge, settingsBtn);
        topbar.getStyleClass().add("topbar");
        topbar.setAlignment(Pos.CENTER_LEFT);
        topbar.setPadding(new javafx.geometry.Insets(10, 18, 10, 14));

        // ---------- 错误横幅 ----------
        Label errText = new Label();
        errText.getStyleClass().add("banner-text");
        Button retry = new Button("重试");
        retry.getStyleClass().add("btn-secondary");
        retry.setOnAction(e -> {
            hideBanner();
            bootstrap();
        });
        errorBanner = new HBox(12, errText, retry);
        errorBanner.getStyleClass().add("error-banner");
        errorBanner.setAlignment(Pos.CENTER_LEFT);
        errorBanner.setPadding(new javafx.geometry.Insets(8, 14, 8, 14));
        errorBanner.setManaged(false);
        errorBanner.setVisible(false);
        bannerText = errText;

        // ---------- 主体 ----------
        fileTree = new FileTreeView(workspace, this::openFile, this::chooseWorkspaceDir);
        skillView = new SkillView(skills, this::editSkill, this::deleteSkill, this::newSkill);
        sidebar = new SidebarView(this::onNewChat, this::onSelect, this::onDelete, this::openSettings);
        sidebarHolder = new StackPane(sidebar.node(), fileTree.node(), skillView.node());
        sidebarHolder.getStyleClass().add("sidebar-holder");
        sidebarHolder.setPrefWidth(262);
        sidebarHolder.setMinWidth(0);
        sidebarHolder.setMaxWidth(262);
        fileTree.node().setVisible(false);
        fileTree.node().setManaged(false);
        skillView.node().setVisible(false);
        skillView.node().setManaged(false);

        activityBar = new ActivityBarView(this::openSchedule, this::toggleTheme, this::showConversations,
                this::toggleExplorer, this::toggleSkills, this::toggleKnowledge, this::onReserved);
        activityBar.setChatActive(true);

        chatArea = new ChatAreaView(this::onSuggest);
        composer = new ComposerView(this::send, this::stop, skills, this::onSkillSelected);

        chatLayer = new VBox(topbar, errorBanner, chatArea.node(), composer.node());
        VBox.setVgrow(chatArea.node(), Priority.ALWAYS);

        fileViewer = new FileViewerView(this::closeFile);
        fileViewer.node().setVisible(false);
        fileViewer.node().setManaged(false);
        knowledgeView = new KnowledgeView(stage, knowledge);
        knowledgeView.node().setVisible(false);
        knowledgeView.node().setManaged(false);
        centerStack = new StackPane(chatLayer, fileViewer.node(), knowledgeView.node());

        HBox leftPane = new HBox(activityBar.node(), sidebarHolder);
        root = new BorderPane();
        root.setLeft(leftPane);
        root.setCenter(centerStack);
        root.getStyleClass().add("app-root");

        // ---------- 绑定 service 事件 ----------
        sidebar.setOnStatusClick(this::openLogin);
        sessions.setOnChanged(this::renderCurrent);
        schedule.setOnFire(task -> Platform.runLater(() -> schedule.execute(task)));
        chat.setListener(new ChatService.Listener() {
            @Override
            public void onUserMessage(Conversation conv, ChatMessage msg) {
                if (sessions.current() == conv) {
                    chatArea.append(msg);
                }
            }

            @Override
            public void onAssistantMessage(Conversation conv, ChatMessage msg) {
                if (sessions.current() == conv) {
                    activeNode = chatArea.append(msg);
                    chatArea.scrollToBottom();
                }

                sidebar.update(sessions.all(), sessions.current() == null ? null : sessions.current().id);
            }

            @Override
            public void onTitleChanged(Conversation conv) {
                if (sessions.current() == conv) {
                    topTitle.setText(conv.title == null ? "新会话" : conv.title);
                }
            }

            @Override
            public void onTextUpdated(Conversation conv, ChatMessage msg) {
                Platform.runLater(() -> {
                    if (sessions.current() == conv && activeNode != null) {
                        activeNode.refreshText(true);
                    }
                });
            }

            @Override
            public void onToolAdded(Conversation conv, ChatMessage msg,
                                    ToolCall tool) {
                Platform.runLater(() -> {
                    if (sessions.current() == conv && activeNode != null) {
                        activeNode.addTool(tool);
                        chatArea.scrollToBottom();
                    }
                });
            }

            @Override
            public void onToolUpdated(Conversation conv, ChatMessage msg,
                                      ToolCall tool) {
                Platform.runLater(() -> {
                    if (sessions.current() == conv && activeNode != null) {
                        activeNode.updateTool(tool);
                    }
                });
            }

            @Override
            public void onPermissionRequest(String requestId, String toolName, String inputJson,
                                            java.util.function.BiConsumer<String, Boolean> responder) {
                Platform.runLater(() -> {
                    sidebar.setStatus(true, "等待工具授权…");
                    Dialogs.showPermission(stage, toolName, inputJson, (name, allow) -> {
                        sidebar.setStatus(true, "已连接");
                        responder.accept(name, allow);
                    });
                });
            }

            @Override
            public void onStreamingChanged(Conversation conv, boolean streaming) {
                Runnable r = () -> {
                    sidebar.setStreaming(conv.id, streaming);
                    if (sessions.current() == conv) {
                        composer.setStreaming(streaming);
                        if (streaming) composer.clear();
                    }
                };
                if (Platform.isFxApplicationThread()) {
                    r.run();
                } else {
                    Platform.runLater(r);
                }
            }

            @Override
            public void onFinished(Conversation conv, ChatMessage msg) {
                Platform.runLater(() -> {
                    if (sessions.current() == conv) {
                        if (activeNode != null) {
                            activeNode.refreshText(false);
                            chatArea.scrollToBottom();
                        }
                        activeNode = null;
                    }
                    // AI 用了工具可能在工作目录生成了文件，刷新文件树
                    if (explorerMode && msg.toolCalls != null && !msg.toolCalls.isEmpty()) {
                        fileTree.refresh();
                    }
                    sessions.persist();
                    sidebar.update(sessions.all(), sessions.current() == null ? null : sessions.current().id);
                });
            }

            @Override
            public void onAuthRequired() {
                Platform.runLater(() -> {
                    sidebar.setStatus(false, "未登录 · 点击登录");
                    showBanner("jagent 未登录：对话与工具不可用。");
                    Alert tip = new Alert(Alert.AlertType.CONFIRMATION,
                            "jagent 尚未登录，无法进行对话。\n\n是否现在登录？",
                            ButtonType.YES, ButtonType.NO);
                    tip.setHeaderText(null);
                    tip.initOwner(stage);
                    tip.showAndWait().ifPresent(bt -> {
                        if (bt == ButtonType.YES) openLogin();
                    });
                });
            }
        });

        connectivity.setListener(new ConnectivityService.Listener() {
            @Override
            public void onStatus(boolean ok, String text) {
                Platform.runLater(() -> {
                    if ("langchain4j".equals(settings.settings().provider)) return;
                    if (ok) {
                        hideBanner();
                        sidebar.setStatus(true, text);
                    } else {
                        sidebar.setStatus(false, text);
                        showBanner("无法连接 Agent 服务。请先运行 scripts\\start-server.bat，或在设置中检查服务地址。");
                    }
                });
            }

            @Override
            public void onModels(List<ModelInfo> models) {
                Platform.runLater(() -> {
                    if ("langchain4j".equals(settings.settings().provider)) return;
                    modelCombo.getItems().setAll(models);
                    syncModelSelection();
                });
            }

            @Override
            public void onLoginChecked(JsonObject login) {
                Platform.runLater(() -> {
                    if ("langchain4j".equals(settings.settings().provider)) return;
                    if (login != null && login.has("isLoggedIn") && login.get("isLoggedIn").getAsBoolean()) {
                        String user = login.has("user") && !login.get("user").isJsonNull()
                                ? login.get("user").getAsString() : null;
                        sidebar.setStatus(true, user != null ? ("已登录 · " + user) : "已登录 jagent");
                    } else if (login != null) {
                        sidebar.setStatus(false, "未登录 · 点击登录");
                    } else {
                        sidebar.setStatus(true, "服务已连接");
                    }
                });
            }
        });

        // ---------- 工作区文件 ----------
        workspace.setListener(new WorkspaceService.Listener() {
            @Override
            public void onRootChanged(Path root) {
                Platform.runLater(() -> {
                    if (root != null) {
                        fileTree.setRoot(root);
                    }
                });
            }

            @Override
            public void onFileOpened(String path, String content, boolean binary, long size) {
                Platform.runLater(() -> showFile(path, content, binary, size));
            }

            @Override
            public void onError(String message) {
                Platform.runLater(() -> showBanner(message));
            }
        });

        // ---------- 初始渲染与主题 ----------
        Theme.setCurrent(settings.theme());
        updateProviderBadge();
        if ("langchain4j".equals(settings.settings().provider)) {
            refreshModelComboForLangchain4j();
        }
        renderCurrent();
    }

    // 图标包装，避免在字段初始化顺序中的问题
    private static class IconsHolder {
        static javafx.scene.Node menu() {
            return Icons.stroke(
                    Icons.MENU, 18, Color.web("#3D4350"));
        }

        static javafx.scene.Node settings() {
            return Icons.stroke(
                    Icons.SETTINGS, 17, Color.web("#646A73"));
        }
    }

    public Parent getRoot() {
        return root;
    }

    // ================= 启动 =================

    public void bootstrap() {
        if ("langchain4j".equals(settings.settings().provider)) {
            applyProvider();
        } else {
            connectivity.bootstrap();
        }
    }

    // ================= 会话 UI 动作 =================

    private void onNewChat() {
        sessions.create(true);
        composer.focus();
    }

    private void onSelect(Conversation c) {
        if (c == sessions.current()) return;
        sessions.select(c);
    }

    private void onDelete(Conversation c) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "确定删除会话「" + (c.title == null ? "新会话" : c.title) + "」吗？",
                ButtonType.YES, ButtonType.NO);
        alert.setHeaderText(null);
        alert.initOwner(stage);
        alert.showAndWait().ifPresent(bt -> {
            if (bt == ButtonType.YES) {
                sessions.delete(c);
            }
        });
    }

    private void onSuggest(String text) {
        composer.setText(text);
        send(text);
    }

    private void send(String text) {
        String t = text == null ? "" : text.trim();
        if ("/jagent init".equals(t) || "/jagent:init".equals(t)) {
            runJagentInit();
            return;
        }
        if ("/harness".equals(t) || t.startsWith("/harness ")) {
            executeHarness(t);
            return;
        }
        chat.send(text, composer.getPermissionMode());
    }

    // ================= 对话框执行 harness =================

    /** 处理 {@code /harness [list | <id> <入参>]}。 */
    private void executeHarness(String command) {
        Conversation c = sessions.current();
        if (c == null) return;

        String rest = command.substring("/harness".length()).trim();
        if (rest.isEmpty() || "list".equalsIgnoreCase(rest) || "help".equalsIgnoreCase(rest)) {
            appendLocalExchange(c, command, harnessListText());
            return;
        }

        int space = rest.indexOf(' ');
        String id = space < 0 ? rest : rest.substring(0, space);
        String input = space < 0 ? "" : rest.substring(space + 1).trim();
        Harness harness = harnesses.get(id);
        if (harness == null) {
            appendLocalExchange(c, command, "未找到 harness：" + id + "\n\n" + harnessListText());
            return;
        }

        ChatMessage userMsg = localMessage("user", command);
        ChatMessage assistantMsg = localMessage("assistant", "执行中…");
        synchronized (Store.PERSIST_LOCK) {
            c.messages.add(userMsg);
            c.messages.add(assistantMsg);
        }
        sessions.persist();
        renderCurrent();

        long startedAt = System.currentTimeMillis();
        Thread.ofVirtual().name("java-harness-" + id).start(() -> {
            String result;
            String error = null;
            try {
                result = harness.execute(input);
            } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
                result = "执行失败：" + error;
            }
            HarnessAudit.record(id, harness.name(), input, result, error,
                    System.currentTimeMillis() - startedAt);
            String output = result == null || result.isBlank() ? "（无输出）" : result;
            Platform.runLater(() -> {
                assistantMsg.content = output;
                c.updatedAt = System.currentTimeMillis();
                sessions.persist();
                if (sessions.current() == c) renderCurrent();
            });
        });
    }

    /** 把命令与结果作为本地消息追加到会话（不参与模型上下文）。 */
    private void appendLocalExchange(Conversation c, String command, String result) {
        synchronized (Store.PERSIST_LOCK) {
            c.messages.add(localMessage("user", command));
            c.messages.add(localMessage("assistant", result));
        }
        c.updatedAt = System.currentTimeMillis();
        sessions.persist();
        if (sessions.current() == c) renderCurrent();
    }

    private static ChatMessage localMessage(String role, String content) {
        ChatMessage m = new ChatMessage(UUID.randomUUID().toString(), role);
        m.content = content;
        m.local = true;
        return m;
    }

    private String harnessListText() {
        StringBuilder sb = new StringBuilder("可用 harness（/harness <id> <入参>）：\n");
        for (Harness h : harnesses.all()) {
            sb.append("- ").append(h.id()).append("：").append(h.name()).append('\n');
        }
        sb.append("\n示例：\n")
                .append("/harness list\n")
                .append("/harness skill\n")
                .append("/harness knowledge 项目用了哪些依赖？");
        return sb.toString();
    }

    private void stop() {
        chat.stop();
    }

    private void renderCurrent() {
        Conversation c = sessions.current();
        sidebar.update(sessions.all(), c == null ? null : c.id);
        topTitle.setText(c == null || c.title == null ? "新会话" : c.title);
        chatArea.render(c);
        // 正在流式输出且当前查看的就是流式会话时，重新绑定活跃节点
        boolean streaming = c != null && chat.isStreaming(c.id);
        activeNode = streaming ? chatArea.getLastNode() : null;
        // 发送/停止按钮跟随当前会话的流式状态
        composer.setStreaming(streaming);
        composer.loadHistory(collectUserHistory(c));
        composer.setSelectedSkill(c == null ? null : c.skillPath);
        syncModelSelection();
    }

    /** 切换当前会话使用的技能（null 表示不使用技能）。 */
    private void onSkillSelected(String skillPath) {
        Conversation c = sessions.current();
        if (c == null) return;
        c.skillPath = skillPath;
        sessions.persist();
    }

    private List<String> collectUserHistory(Conversation c) {
        List<String> out = new ArrayList<>();
        if (c != null && c.messages != null) {
            for (ChatMessage m : c.messages) {
                if ("user".equals(m.role) && m.content != null && !m.content.isBlank()) {
                    out.add(m.content);
                }
            }
        }
        return out;
    }

    private void syncModelSelection() {
        Conversation c = sessions.current();
        String want;
        if ("langchain4j".equals(settings.settings().provider)) {
            want = settings.settings().llmModel;
        } else {
            want = c != null && c.model != null && !c.model.isBlank()
                    ? c.model : settings.settings().model;
        }
        for (int i = 0; i < modelCombo.getItems().size(); i++) {
            if (modelCombo.getItems().get(i).modelId.equals(want)) {
                modelCombo.getSelectionModel().select(i);
                break;
            }
        }
        if (modelCombo.getSelectionModel().isEmpty() && !modelCombo.getItems().isEmpty()) {
            modelCombo.getSelectionModel().select(0);
        }
    }

    // ================= 登录 / 设置 =================

    private void openLogin() {
        Dialogs.showLogin(stage, new Dialogs.LoginFlow() {
            @Override
            public String startLogin() {
                try {
                    JsonObject r = connectivity.login();
                    if (r == null) return "";
                    if (r.has("alreadyLoggedIn") && r.get("alreadyLoggedIn").getAsBoolean()) {
                        return null;
                    }
                    return r.has("authUrl") && !r.get("authUrl").isJsonNull()
                            ? r.get("authUrl").getAsString() : "";
                } catch (Exception e) {
                    return "";
                }
            }

            @Override
            public String checkLogin() {
                try {
                    JsonObject r = connectivity.checkLogin();
                    if (r != null && r.has("isLoggedIn") && r.get("isLoggedIn").getAsBoolean()) {
                        return r.has("user") && !r.get("user").isJsonNull()
                                ? r.get("user").getAsString() : "已登录";
                    }
                } catch (Exception ignored) {
                }
                return null;
            }
        }, () -> {
            hideBanner();
            sidebar.setStatus(true, "已登录 jagent");
            connectivity.refreshLoginAndModels();
        });
    }

    private void openSettings() {
        Dialogs.showSettings(stage, settings.settings(),
                (serverUrl, cwd, permissionMode, apiKey, theme, provider, llmBaseUrl, llmApiKey, llmModel, llmEmbeddingModel,
                 llmEmbeddingBaseUrl, llmEmbeddingApiKey, debug, historyRounds) -> {
                    settings.settings().serverUrl = serverUrl;
                    settings.settings().cwd = cwd;
                    settings.settings().permissionMode = permissionMode;
                    settings.settings().provider = provider;
                    settings.settings().llmBaseUrl = llmBaseUrl;
                    settings.settings().llmApiKey = llmApiKey;
                    settings.settings().llmModel = llmModel;
                    settings.settings().llmEmbeddingModel = llmEmbeddingModel;
                    settings.settings().llmEmbeddingBaseUrl = llmEmbeddingBaseUrl;
                    settings.settings().llmEmbeddingApiKey = llmEmbeddingApiKey;
                    settings.settings().historyRounds = historyRounds;
                    settings.setDebug(debug);
                    applyTheme(theme);
                    connectivity.setBaseUrl(serverUrl);
                    knowledge.reset();
                    applyProvider();
                    if ("codebuddy".equals(provider)) {
                        if (apiKey != null && !apiKey.isBlank()) {
                            Thread.ofVirtual().start(() -> {
                                connectivity.saveConfig(apiKey);
                                Platform.runLater(connectivity::bootstrap);
                            });
                        } else {
                            connectivity.bootstrap();
                        }
                    }
                    hideBanner();
                },
                Langchain4jBackend::testConnection);
    }

    // ================= 系统菜单 =================

    private void showSystemMenu(Button anchor) {
        ContextMenu menu = new ContextMenu();

        MenuItem settingsItem = new MenuItem("设置");
        settingsItem.setOnAction(e -> openSettings());

        MenuItem jagentItem = new MenuItem("初始化 jagent 指令");
        jagentItem.setOnAction(e -> runJagentInit());

        Menu styleMenu = new Menu("风格");
        ToggleGroup tg = new ToggleGroup();
        for (String t : Theme.ALL) {
            RadioMenuItem item = new RadioMenuItem(Theme.displayName(t));
            item.setToggleGroup(tg);
            item.setSelected(t.equals(settings.theme()));
            item.setOnAction(e -> applyTheme(t));
            styleMenu.getItems().add(item);
        }

        MenuItem creditsItem = new MenuItem("积分");
        creditsItem.setOnAction(e -> showCredits());

        MenuItem versionItem = new MenuItem("系统版本");
        versionItem.setOnAction(e -> showAbout());

        MenuItem feedbackItem = new MenuItem("反馈");
        feedbackItem.setOnAction(e -> showFeedback());

        menu.getItems().addAll(settingsItem, jagentItem, styleMenu, creditsItem, versionItem, feedbackItem);
        menu.show(anchor, Side.BOTTOM, 0, 8);
    }

    /** 执行 /jagent init：在工作空间下生成 jagent.md。 */
    private void runJagentInit() {
        Path ws = workspace.root();
        if (ws == null) {
            String cwd = settings.settings().cwd;
            ws = Path.of(cwd == null || cwd.isBlank() ? System.getProperty("user.dir") : cwd);
        }
        Path p = jagent.generate(ws);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(stage);
        alert.setTitle("/jagent init");
        alert.setHeaderText("已生成 jagent.md");
        alert.setContentText("文件路径：\n" + p
                + "\n\n该文件内容会作为每次与大模型交互的规则/规范/约束注入系统提示词。");
        alert.showAndWait();
    }

    private void showAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(stage);
        alert.setTitle("系统版本");
        alert.setHeaderText("jagent Agent");
        alert.setContentText("版本：v" + App.VERSION
                + "\n 支持 Windows / macOS / Linux");
        alert.showAndWait();
    }

    private void showCredits() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(stage);
        alert.setTitle("积分");
        alert.setHeaderText("积分");
        alert.setContentText("积分功能即将上线，敬请期待。");
        alert.showAndWait();
    }

    private void showFeedback() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initOwner(stage);
        alert.setTitle("反馈");
        alert.setHeaderText("意见反馈");
        alert.setContentText("如遇问题或有建议，欢迎反馈。\n反馈功能即将上线。");
        alert.showAndWait();
    }

    // ================= 主题 =================

    private void toggleTheme() {
        applyTheme(Theme.next(settings.theme()));
    }

    private void applyTheme(String theme) {
        settings.setTheme(theme);
        Theme.setCurrent(settings.theme());
        Theme.reload(root.getScene());
    }

    // ================= 模型来源（provider） =================

    private void applyProvider() {
        boolean lc = "langchain4j".equals(settings.settings().provider);
        chat.setBackend(lc ? langchain4j : codebuddy);
        updateProviderBadge();
        if (lc) {
            refreshModelComboForLangchain4j();
            if (langchain4j.isAvailable()) {
                sidebar.setStatus(true, settings.settings().llmModel + " 直连");
                hideBanner();
            } else {
                sidebar.setStatus(false, "模型未配置");
                showBanner("模型未配置：点击顶部「模型」徽标打开设置，填写接口地址、API Key 与模型。");
            }
        } else {
            modelCombo.setPromptText(null);
        }
    }

    /** langchain4j 模式下：下拉框显示当前模型名，未配置时占位「模型」。 */
    private void refreshModelComboForLangchain4j() {
        String m = settings.settings().llmModel;
        if (m == null || m.isBlank()) {
            modelCombo.getItems().clear();
            modelCombo.setPromptText("模型");
        } else {
            modelCombo.setPromptText(null);
            modelCombo.getItems().setAll(new ModelInfo(m, m));
        }
        syncModelSelection();
    }

    private void updateProviderBadge() {
        if ("langchain4j".equals(settings.settings().provider)) {
            String m = settings.settings().llmModel;
            providerBadge.setText(m == null || m.isBlank() ? "模型" : m);
        } else {
            providerBadge.setText("CodeBuddy");
        }
    }

    // ================= 定时任务 =================

    private void openSchedule() {
        Dialogs.showScheduleList(stage, schedule::all, this::openScheduleEditor,
                (id, enabled) -> schedule.setEnabled(id, enabled));
    }

    private void openScheduleEditor() {
        Dialogs.showSchedule(stage, (cron, content, enabled) -> {
            ScheduledTask t = new ScheduledTask();
            t.cron = cron;
            t.content = content;
            t.enabled = enabled;
            schedule.add(t);
            sidebar.update(sessions.all(), sessions.current() == null ? null : sessions.current().id);
            sidebar.setStatus(true, "定时任务已保存");
        });
    }

    private void onReserved() {
        Alert a = new Alert(Alert.AlertType.INFORMATION, "该功能将在后续版本开放，敬请期待。");
        a.setHeaderText(null);
        a.setTitle("功能开发中");
        a.initOwner(stage);
        a.showAndWait();
    }

    // ================= 工作区文件 =================

    /** 显示会话列表（退出工作区 / 技能 / 知识库视图）。 */
    private void showConversations() {
        if (knowledgeMode) exitKnowledge();
        explorerMode = false;
        skillsMode = false;
        activityBar.setChatActive(true);
        activityBar.setExplorerActive(false);
        activityBar.setSkillsActive(false);
        activityBar.setKnowledgeActive(false);
        closeFile();
        sidebar.node().setVisible(true);
        sidebar.node().setManaged(true);
        fileTree.node().setVisible(false);
        fileTree.node().setManaged(false);
        skillView.node().setVisible(false);
        skillView.node().setManaged(false);
    }

    private void toggleExplorer() {
        if (explorerMode) {
            exitExplorer();
        } else {
            enterExplorer();
        }
    }

    private void enterExplorer() {
        if (knowledgeMode) exitKnowledge();
        explorerMode = true;
        skillsMode = false;
        if (workspace.root() == null) {
            chooseWorkspaceDir();
        }
        if (workspace.root() == null) {
            explorerMode = false;
            activityBar.setExplorerActive(false);
            return;
        }
        sidebar.node().setVisible(false);
        sidebar.node().setManaged(false);
        skillView.node().setVisible(false);
        skillView.node().setManaged(false);
        fileTree.node().setVisible(true);
        fileTree.node().setManaged(true);
        fileTree.setRoot(workspace.root());
        activityBar.setChatActive(false);
        activityBar.setExplorerActive(true);
        activityBar.setSkillsActive(false);
    }

    private void exitExplorer() {
        explorerMode = false;
        sidebar.node().setVisible(true);
        sidebar.node().setManaged(true);
        fileTree.node().setVisible(false);
        fileTree.node().setManaged(false);
        activityBar.setExplorerActive(false);
        activityBar.setChatActive(true);
        closeFile();
    }

    // ================= 技能 =================

    private void toggleSkills() {
        if (skillsMode) {
            exitSkills();
        } else {
            enterSkills();
        }
    }

    private void enterSkills() {
        if (knowledgeMode) exitKnowledge();
        skillsMode = true;
        explorerMode = false;
        activityBar.setExplorerActive(false);
        closeFile();
        sidebar.node().setVisible(false);
        sidebar.node().setManaged(false);
        fileTree.node().setVisible(false);
        fileTree.node().setManaged(false);
        skillView.node().setVisible(true);
        skillView.node().setManaged(true);
        skills.refresh();
        activityBar.setChatActive(false);
        activityBar.setSkillsActive(true);
    }

    private void exitSkills() {
        skillsMode = false;
        skillView.node().setVisible(false);
        skillView.node().setManaged(false);
        sidebar.node().setVisible(true);
        sidebar.node().setManaged(true);
        activityBar.setSkillsActive(false);
        activityBar.setChatActive(true);
    }

    // ================= 知识库 / 文档问答 =================

    private void toggleKnowledge() {
        if (knowledgeMode) {
            exitKnowledge();
        } else {
            enterKnowledge();
        }
    }

    private void enterKnowledge() {
        knowledgeMode = true;
        explorerMode = false;
        skillsMode = false;
        activityBar.setChatActive(false);
        activityBar.setExplorerActive(false);
        activityBar.setSkillsActive(false);
        activityBar.setKnowledgeActive(true);
        // 参照工作空间：左侧不显示会话，收起侧边栏让知识库占满主区域
        sidebarHolder.setVisible(false);
        sidebarHolder.setManaged(false);
        fileViewer.node().setVisible(false);
        fileViewer.node().setManaged(false);
        chatLayer.setVisible(false);
        chatLayer.setManaged(false);
        knowledgeView.node().setVisible(true);
        knowledgeView.node().setManaged(true);
    }

    private void exitKnowledge() {
        knowledgeMode = false;
        knowledgeView.node().setVisible(false);
        knowledgeView.node().setManaged(false);
        chatLayer.setVisible(true);
        chatLayer.setManaged(true);
        // 恢复会话侧边栏
        sidebar.node().setVisible(true);
        sidebar.node().setManaged(true);
        fileTree.node().setVisible(false);
        fileTree.node().setManaged(false);
        skillView.node().setVisible(false);
        skillView.node().setManaged(false);
        sidebarHolder.setVisible(true);
        sidebarHolder.setManaged(true);
        activityBar.setKnowledgeActive(false);
    }

    private void newSkill() {
        Dialogs.showSkillEditor(stage, null, (name, description, content) ->
                skills.create(name, description, content), null);
    }

    private void editSkill(Skill skill) {
        Dialogs.showSkillEditor(stage, skill, (name, description, content) ->
                skills.save(skill, name, description, content), () -> openSkillFolder(skill));
    }

    private void deleteSkill(Skill skill) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "确定删除技能「" + skill.name + "」吗？", ButtonType.YES, ButtonType.NO);
        alert.setHeaderText(null);
        alert.initOwner(stage);
        alert.showAndWait().ifPresent(bt -> {
            if (bt == ButtonType.YES) {
                skills.delete(skill);
            }
        });
    }

    private void openSkillFolder(Skill skill) {
        try {
            java.awt.Desktop.getDesktop().open(new File(skill.path));
        } catch (Exception e) {
            showBanner("无法打开技能目录：" + skill.path);
        }
    }

    private void chooseWorkspaceDir() {
        DirectoryChooser chooser = new DirectoryChooser();
        chooser.setTitle("选择工作区文件夹");
        Path current = workspace.root();
        if (current != null && Files.isDirectory(current)) {
            chooser.setInitialDirectory(current.toFile());
        } else {
            String cwd = settings.settings().cwd;
            if (cwd != null && !cwd.isBlank()) {
                File f = new File(cwd);
                if (f.isDirectory()) chooser.setInitialDirectory(f);
            }
        }
        File dir = chooser.showDialog(stage);
        if (dir != null) {
            workspace.openWorkspace(dir.toPath());
        }
    }

    private void openFile(String path) {
        workspace.openFile(Path.of(path));
    }

    private void closeFile() {
        chatLayer.setVisible(true);
        chatLayer.setManaged(true);
        fileViewer.node().setVisible(false);
        fileViewer.node().setManaged(false);
    }

    private void showFile(String path, String content, boolean binary, long size) {
        fileViewer.show(path, content, binary, size);
        chatLayer.setVisible(false);
        chatLayer.setManaged(false);
        fileViewer.node().setVisible(true);
        fileViewer.node().setManaged(true);
    }

    // ================= UI 辅助 =================

    private void showBanner(String text) {
        bannerText.setText(text);
        errorBanner.setManaged(true);
        errorBanner.setVisible(true);
    }

    private void hideBanner() {
        errorBanner.setManaged(false);
        errorBanner.setVisible(false);
    }

    private void toggleSidebar() {
        if (sidebarExpanded) {
            Timeline t = new Timeline(new KeyFrame(Duration.millis(180),
                    new javafx.animation.KeyValue(sidebarHolder.prefWidthProperty(), 0)));
            t.setOnFinished(e -> sidebarHolder.setVisible(false));
            t.play();
        } else {
            sidebarHolder.setVisible(true);
            new Timeline(new KeyFrame(Duration.millis(180),
                    new javafx.animation.KeyValue(sidebarHolder.prefWidthProperty(), 262))).play();
        }
        sidebarExpanded = !sidebarExpanded;
    }

    public void shutdown() {
        harnesses.shutdownAll();
    }

    /** 模型下拉框单元格 */
    private static class ModelCell extends javafx.scene.control.ListCell<ModelInfo> {
        @Override
        protected void updateItem(ModelInfo item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty || item == null ? null : item.toString());
        }
    }
}
