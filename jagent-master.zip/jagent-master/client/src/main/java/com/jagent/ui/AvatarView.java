package com.jagent.ui;

import javafx.scene.Node;
import javafx.scene.layout.StackPane;

/**
 * 助手头像：蓝色渐变圆 + 星形标志
 *
 * @author azhu
 * @date 2026-10-24
 */
public class AvatarView extends StackPane {

    public AvatarView(double size) {
        setPrefSize(size, size);
        setMinSize(size, size);
        setMaxSize(size, size);
        setStyle("-fx-background-radius: " + (size / 2) + ";"
                + "-fx-background-color: linear-gradient(to bottom right, #5B9BFF, #0052D9);"
                + "-fx-effect: dropshadow(gaussian, rgba(0,82,217,0.28), 6, 0.1, 0, 2);");
        Node spark = Icons.fill(Icons.SPARK, size * 0.58, javafx.scene.paint.Color.WHITE);
        getChildren().add(spark);
    }
}
