package com.jagent.mcp.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * MCP 使用的 JSON-RPC 2.0 报文构造与解析。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class JsonRpc {

    public static final String VERSION = "2.0";

    private JsonRpc() {}

    public static JsonObject request(long id, String method, JsonObject params) {
        JsonObject o = new JsonObject();
        o.addProperty("jsonrpc", VERSION);
        o.addProperty("id", id);
        o.addProperty("method", method);
        if (params != null) o.add("params", params);
        return o;
    }

    public static JsonObject notification(String method, JsonObject params) {
        JsonObject o = new JsonObject();
        o.addProperty("jsonrpc", VERSION);
        o.addProperty("method", method);
        if (params != null) o.add("params", params);
        return o;
    }

    /** 事务响应：有 error 抛异常，否则返回 result（缺失时返回空对象）。 */
    public static JsonObject resultOrThrow(JsonObject response) {
        if (response == null) throw new McpException("MCP 响应为空");
        if (response.has("error") && !response.get("error").isJsonNull()) {
            JsonElement err = response.get("error");
            String message = err.isJsonObject() && err.getAsJsonObject().has("message")
                    ? err.getAsJsonObject().get("message").getAsString()
                    : err.toString();
            throw new McpException("MCP 错误：" + message);
        }
        JsonElement result = response.get("result");
        return result != null && result.isJsonObject() ? result.getAsJsonObject() : new JsonObject();
    }

    /** 握手参数。 */
    public static JsonObject initializeParams() {
        JsonObject params = new JsonObject();
        params.addProperty("protocolVersion", "2025-06-18");
        params.add("capabilities", new JsonObject());
        JsonObject client = new JsonObject();
        client.addProperty("name", "jagent");
        client.addProperty("version", "1.0.0");
        params.add("clientInfo", client);
        return params;
    }
}
