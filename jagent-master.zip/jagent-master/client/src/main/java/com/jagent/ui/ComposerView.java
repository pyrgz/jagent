package com.jagent.ui;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.stage.Popup;
import com.jagent.skill.model.Skill;
import com.jagent.skill.service.SkillService;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * 底部输入区：自动增高输入框 + 发送/停止按钮
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ComposerView {

    private final VBox root;
    private final TextArea input;
    private final StackPane actionBtn;
    private final ComboBox<String> modeCombo;
    private final Node sendIcon;
    private final Node stopIcon;
    private boolean streaming = false;

    private final Consumer<String> onSend;
    private final Runnable onStop;
    private final SkillService skills;
    /** 本会话选择的技能路径（null=不使用技能），由 ChatController 持久化到会话 */
    private final Consumer<String> onSkillChanged;
    private final ComboBox<Skill> skillCombo;
    private boolean updatingSkillCombo;
    private static final Skill NO_SKILL = noSkill();

    private Popup skillPopup;
    private ListView<Skill> skillList;

    /** 已发送消息历史（↑ 上一条 / ↓ 下一条） */
    private final List<String> history = new ArrayList<>();
    private int historyIndex = -1;
    private String draft = "";
    private boolean navigating = false;

    public ComposerView(Consumer<String> onSend, Runnable onStop, SkillService skills,
                        Consumer<String> onSkillChanged) {
        this.onSend = onSend;
        this.onStop = onStop;
        this.skills = skills;
        this.onSkillChanged = onSkillChanged;

        // ---------- 输入框 ----------
        input = new TextArea();
        input.getStyleClass().add("msg-input");
        input.setWrapText(true);
        input.setPromptText("给 jagent Agent 发送消息…");
        input.setPrefRowCount(1);
        input.setPrefHeight(48);
        input.setMinHeight(48);
        input.textProperty().addListener((obs, o, n) -> Platform.runLater(this::grow));
        // Enter 发送 / Shift+Enter 换行；技能下拉打开时支持方向键/Enter 选择
        input.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
            if (skillPopup != null && skillPopup.isShowing()) {
                if (e.getCode() == KeyCode.ESCAPE) {
                    e.consume();
                    hideSkillPopup();
                    return;
                }
                if (e.getCode() == KeyCode.DOWN) {
                    e.consume();
                    moveSkillSelection(1);
                    return;
                }
                if (e.getCode() == KeyCode.UP) {
                    e.consume();
                    moveSkillSelection(-1);
                    return;
                }
                if (e.getCode() == KeyCode.ENTER && !e.isShiftDown()) {
                    e.consume();
                    selectSkill(skillList.getSelectionModel().getSelectedItem());
                    return;
                }
            }
            // ↑/↓ 带入历史（仅首行/末行触发，避免干扰多行光标移动）
            if (e.getCode() == KeyCode.UP && caretAtFirstLine()) {
                e.consume();
                navigateHistory(true);
                return;
            }
            if (e.getCode() == KeyCode.DOWN && caretAtLastLine()) {
                e.consume();
                navigateHistory(false);
                return;
            }
            if (e.getCode() == KeyCode.ENTER && !e.isShiftDown() && !e.isControlDown() && !e.isAltDown()) {
                e.consume();
                doSend();
            }
        });

        // 技能下拉（输入 / 触发）
        buildSkillPopup();
        input.textProperty().addListener((obs, o, n) -> updateSkillPopup());
        input.caretPositionProperty().addListener((obs, o, n) -> updateSkillPopup());
        // 直接输入 /技能名 时，自动选中该技能（等同于在下拉框中选择）
        input.textProperty().addListener((obs, o, n) -> applySkillFromText(n));
        // 手动输入时退出历史浏览
        input.textProperty().addListener((obs, o, n) -> {
            if (!navigating) historyIndex = -1;
        });

        // ---------- 发送 / 停止按钮 ----------
        sendIcon = Icons.stroke(Icons.SEND, 17, Color.WHITE);
        stopIcon = Icons.fill(Icons.STOP, 15, Color.WHITE);
        actionBtn = new StackPane(sendIcon);
        actionBtn.getStyleClass().add("send-btn");
        actionBtn.setPrefSize(36, 36);
        actionBtn.setMinSize(36, 36);
        actionBtn.setMaxSize(36, 36);
        actionBtn.setOnMouseClicked(e -> {
            if (streaming) {
                if (onStop != null) onStop.run();
            } else {
                doSend();
            }
        });

        Label hint = new Label("Enter 发送 · Shift + Enter 换行");
        hint.getStyleClass().add("hint-label");

        modeCombo = new ComboBox<>();
        modeCombo.getItems().addAll("人工确认", "自动确认");
        modeCombo.setValue("人工确认");
        modeCombo.getStyleClass().add("mode-combo");
        modeCombo.setPrefWidth(110);

        // 会话级技能选择：选中哪个就只向模型注入哪个技能，不选则不注入任何技能
        skillCombo = new ComboBox<>();
        skillCombo.getStyleClass().add("mode-combo");
        skillCombo.setPrefWidth(150);
        skillCombo.setCellFactory(lv -> new SkillComboCell());
        skillCombo.setButtonCell(new SkillComboCell());
        skillCombo.setOnShowing(e -> refreshSkills());
        skillCombo.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (updatingSkillCombo) return;
            if (onSkillChanged != null) onSkillChanged.accept(n == null || n == NO_SKILL ? null : n.path);
        });
        refreshSkills();

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox bottom = new HBox(10, hint, skillCombo, modeCombo, spacer, actionBtn);
        bottom.setAlignment(Pos.CENTER_LEFT);
        bottom.setPadding(new Insets(8, 2, 0, 2));

        // ---------- 卡片容器 ----------
        VBox card = new VBox(4, input, bottom);
        card.getStyleClass().add("composer-card");
        card.setPadding(new Insets(10, 12, 10, 12));

        root = new VBox(card);
        root.getStyleClass().add("composer-wrap");
        root.setPadding(new Insets(4, 18, 14, 18));
        updateSendEnabled();
    }

    private void doSend() {
        String text = input.getText();
        if (text == null || text.isBlank() || streaming) return;
        // 发送前再确认一次：手动输入的 /技能名 也要生效
        applySkillFromText(text);
        if (onSend != null) onSend.accept(text);
        recordHistory(text);
    }

    /** 文本中出现 /技能名 时，自动把该技能设为当前会话使用的技能。 */
    private void applySkillFromText(String text) {
        Skill match = matchSkillToken(text);
        if (match == null) return;
        Skill current = skillCombo.getValue();
        String currentPath = current == null || current == NO_SKILL ? null : current.path;
        if (match.path.equals(currentPath)) return;
        setSelectedSkill(match.path);
        if (onSkillChanged != null) onSkillChanged.accept(match.path);
    }

    /** 匹配文本中的 /技能名（取最长的技能名，避免前缀冲突）。 */
    private Skill matchSkillToken(String text) {
        if (skills == null || text == null || text.isEmpty()) return null;
        Skill best = null;
        for (Skill s : skills.all()) {
            if (s.name == null || s.name.isBlank()) continue;
            if (best != null && s.name.length() <= best.name.length()) continue;
            if (java.util.regex.Pattern.compile("(^|\\s)/" + java.util.regex.Pattern.quote(s.name) + "(\\s|$)")
                    .matcher(text).find()) {
                best = s;
            }
        }
        return best;
    }

    // ================= 输入历史（↑ 上一条 / ↓ 下一条） =================

    private void recordHistory(String text) {
        if (history.isEmpty() || !history.get(history.size() - 1).equals(text)) {
            history.add(text);
            if (history.size() > 100) history.remove(0);
        }
        historyIndex = -1;
        draft = "";
    }

    private void navigateHistory(boolean up) {
        if (history.isEmpty()) return;
        if (up) {
            if (historyIndex == -1) {
                draft = input.getText();
                historyIndex = history.size() - 1;
            } else if (historyIndex > 0) {
                historyIndex--;
            } else {
                return; // 已是最早一条
            }
            setInputText(history.get(historyIndex));
        } else {
            if (historyIndex == -1) return; // 已在草稿
            historyIndex++;
            if (historyIndex >= history.size()) {
                historyIndex = -1;
                setInputText(draft);
            } else {
                setInputText(history.get(historyIndex));
            }
        }
    }

    private void setInputText(String text) {
        navigating = true;
        input.setText(text);
        navigating = false;
        input.positionCaret(input.getLength());
        input.requestFocus();
    }

    private boolean caretAtFirstLine() {
        return input.getText().substring(0, input.getCaretPosition()).indexOf('\n') < 0;
    }

    private boolean caretAtLastLine() {
        return input.getText().substring(input.getCaretPosition()).indexOf('\n') < 0;
    }

    public Node node() {
        return root;
    }

    public String getText() {
        return input.getText();
    }

    /** 同步会话级技能选择（不触发回调）。 */
    public void setSelectedSkill(String skillPath) {
        if (skillCombo.getItems().isEmpty()) refreshSkills();
        updatingSkillCombo = true;
        try {
            selectSkillPath(skillPath);
        } finally {
            updatingSkillCombo = false;
        }
    }

    private void refreshSkills() {
        if (skills == null) return;
        Skill current = skillCombo.getSelectionModel().getSelectedItem();
        String keepPath = current == null ? null : current.path;
        updatingSkillCombo = true;
        try {
            List<Skill> items = new ArrayList<>();
            items.add(NO_SKILL);
            items.addAll(skills.all());
            skillCombo.getItems().setAll(items);
            selectSkillPath(keepPath);
        } finally {
            updatingSkillCombo = false;
        }
    }

    private void selectSkillPath(String skillPath) {
        if (skillPath != null && !skillPath.isBlank()) {
            for (Skill s : skillCombo.getItems()) {
                if (skillPath.equals(s.path)) {
                    skillCombo.getSelectionModel().select(s);
                    return;
                }
            }
        }
        skillCombo.getSelectionModel().select(NO_SKILL);
    }

    private static Skill noSkill() {
        Skill s = new Skill();
        s.name = "不使用技能";
        return s;
    }

    private static class SkillComboCell extends ListCell<Skill> {
        @Override
        protected void updateItem(Skill s, boolean empty) {
            super.updateItem(s, empty);
            setText(empty || s == null ? null : s.name);
        }
    }

    /** 发送时的权限模式：人工确认=default，自动确认=bypassPermissions。 */
    public String getPermissionMode() {
        return "自动确认".equals(modeCombo.getValue()) ? "bypassPermissions" : "default";
    }

    public void setText(String text) {
        input.setText(text);
    }

    /** 用会话历史中的用户消息替换 ↑/↓ 浏览历史。 */
    public void loadHistory(List<String> userMessages) {
        history.clear();
        if (userMessages != null) history.addAll(userMessages);
        historyIndex = -1;
        draft = "";
    }

    public void clear() {
        input.clear();
        input.setPrefHeight(48);
    }

    public void focus() {
        Platform.runLater(() -> input.requestFocus());
    }

    /** 切换流式状态：流式时按钮变为「停止」 */
    public void setStreaming(boolean s) {
        streaming = s;
        actionBtn.getChildren().setAll(s ? stopIcon : sendIcon);
        actionBtn.getStyleClass().setAll("send-btn", s ? "stop-mode" : "");
        updateSendEnabled();
    }

    private void updateSendEnabled() {
        boolean disabled = !streaming && (input.getText() == null || input.getText().isBlank());
        actionBtn.getStyleClass().setAll("send-btn", streaming ? "stop-mode" : "", disabled ? "disabled" : "");
        actionBtn.setOpacity(disabled ? 0.45 : 1.0);
    }

    /** 根据内容自动调整高度 */
    private void grow() {
        double w = input.getWidth() - 22;
        if (w < 60) w = 420;
        double h = input.prefHeight(w);
        if (h < 48) h = 48;
        if (h > 180) h = 180;
        input.setPrefHeight(h);
        updateSendEnabled();
    }

    // ================= 技能下拉（/） =================

    private void buildSkillPopup() {
        skillList = new ListView<>();
        skillList.getStyleClass().add("skill-popup-list");
        skillList.setPrefWidth(340);
        skillList.setMaxHeight(240);
        skillList.setCellFactory(lv -> new SkillPopupCell());
        skillList.setOnMouseClicked(e -> {
            if (e.getClickCount() >= 1) {
                selectSkill(skillList.getSelectionModel().getSelectedItem());
            }
        });
        skillPopup = new Popup();
        skillPopup.setAutoHide(true);
        skillPopup.getContent().add(skillList);
    }

    /** 返回当前光标处正在输入的 / 令牌起始下标，无则 -1。 */
    private int activeSlashIndex() {
        String text = input.getText();
        int caret = input.getCaretPosition();
        if (text == null || text.isEmpty()) return -1;
        if (caret < 0 || caret > text.length()) caret = text.length();
        for (int i = caret - 1; i >= 0; i--) {
            char ch = text.charAt(i);
            if (ch == '/' && (i == 0 || Character.isWhitespace(text.charAt(i - 1)))) {
                return i;
            }
            if (Character.isWhitespace(ch)) break;
        }
        return -1;
    }

    private void updateSkillPopup() {
        if (skillPopup == null || skills == null) return;
        int slash = activeSlashIndex();
        if (slash < 0) {
            hideSkillPopup();
            return;
        }
        String text = input.getText();
        int caret = input.getCaretPosition();
        if (caret < 0 || caret > text.length()) caret = text.length();
        String query = text.substring(slash + 1, caret).toLowerCase();
        List<Skill> filtered = new ArrayList<>();
        for (Skill s : skills.all()) {
            String n = s.name == null ? "" : s.name.toLowerCase();
            if (n.contains(query)) filtered.add(s);
        }
        if (filtered.isEmpty()) {
            hideSkillPopup();
            return;
        }
        skillList.getItems().setAll(filtered);
        if (!skillPopup.isShowing()) {
            double x = input.localToScreen(0, input.getHeight()).getX();
            double y = input.localToScreen(0, input.getHeight()).getY();
            skillPopup.show(input, x, y);
        }
    }

    private void hideSkillPopup() {
        if (skillPopup != null && skillPopup.isShowing()) skillPopup.hide();
    }

    private void moveSkillSelection(int delta) {
        int size = skillList.getItems().size();
        if (size == 0) return;
        int idx = skillList.getSelectionModel().getSelectedIndex();
        int next = (idx + delta + size) % size;
        skillList.getSelectionModel().select(next);
        skillList.scrollTo(next);
    }

    private void selectSkill(Skill skill) {
        if (skill == null) return;
        int slash = activeSlashIndex();
        if (slash < 0) {
            hideSkillPopup();
            return;
        }
        String text = input.getText();
        int caret = input.getCaretPosition();
        if (caret < 0 || caret > text.length()) caret = text.length();
        String insert = "/" + skill.name + " ";
        input.replaceText(slash, caret, insert);
        input.positionCaret(slash + insert.length());
        // 选择 /技能 时同时把它设为当前会话使用的技能
        setSelectedSkill(skill.path);
        if (onSkillChanged != null) onSkillChanged.accept(skill.path);
        hideSkillPopup();
        input.requestFocus();
    }

    private static class SkillPopupCell extends ListCell<Skill> {
        private final Label label = new Label();

        SkillPopupCell() {
            label.getStyleClass().add("skill-popup-item");
            label.setMaxWidth(Double.MAX_VALUE);
            setContentDisplay(javafx.scene.control.ContentDisplay.GRAPHIC_ONLY);
        }

        @Override
        protected void updateItem(Skill s, boolean empty) {
            super.updateItem(s, empty);
            if (empty || s == null) {
                setGraphic(null);
                return;
            }
            String desc = (s.description == null || s.description.isBlank())
                    ? "" : "  ·  " + s.description.trim();
            label.setText((s.loaded ? "✓ " : "") + s.name + desc);
            setGraphic(label);
        }
    }
}
