package com.jagent.ui;

import com.jagent.settings.model.AppSettings;
import com.jagent.settings.model.ProviderPreset;
import com.jagent.store.Store;
import com.jagent.schedule.model.ScheduledTask;
import com.jagent.skill.model.Skill;
import com.jagent.schedule.CronExpression;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

/**
 * 设置 / 权限确认对话框
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class Dialogs {

    private Dialogs() {}

    /** 服务商预设：从 data/providers.json 加载（不存在则写入默认预设）。 */
    private static List<ProviderPreset> providerPresets() {
        return Store.loadProviders();
    }

    // ================= 设置 =================

    public interface SettingsSaver {
        /**
         * 保存设置。
         *
         * @param serverUrl      服务地址
         * @param cwd            Agent 工作目录
         * @param permissionMode 权限模式
         * @param apiKey         jagent API Key（为空表示不修改）
         * @param theme          界面主题
         * @param provider       模型来源：codebuddy | langchain4j
         * @param llmBaseUrl     langchain4j 接口地址
         * @param llmApiKey      langchain4j API Key
         * @param llmModel       langchain4j 模型名
         * @param llmEmbeddingModel langchain4j 嵌入模型名（文档问答）
         * @param llmEmbeddingBaseUrl 嵌入接口地址（留空复用 llmBaseUrl）
         * @param llmEmbeddingApiKey 嵌入 API Key（留空复用 llmApiKey）
         * @param debug          调试模式（全量打印模型输入输出）
         * @param historyRounds  发送给模型的历史轮数（-1 表示不限制）
         */
        void save(String serverUrl, String cwd, String permissionMode, String apiKey, String theme,
                  String provider, String llmBaseUrl, String llmApiKey, String llmModel, String llmEmbeddingModel,
                  String llmEmbeddingBaseUrl, String llmEmbeddingApiKey, boolean debug, int historyRounds);
    }

    /** 连接测试回调（阻塞，应在后台线程调用），返回结果提示文本。 */
    public interface ConnectionTester {
        String test(String baseUrl, String apiKey, String model);
    }

    public static void showSettings(Stage owner, AppSettings settings, SettingsSaver saver,
                                    ConnectionTester tester) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("设置");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(640);

        // ---------- 模型来源 ----------
        ComboBox<String> providerBox = new ComboBox<>();
        providerBox.getItems().addAll("jagent CLI", "模型直连");
        providerBox.getSelectionModel().select("langchain4j".equals(settings.provider) ? 1 : 0);
        providerBox.setMaxWidth(Double.MAX_VALUE);
        providerBox.getStyleClass().add("dialog-combo");

        // ---------- 服务连接（仅 jagent CLI） ----------
        TextField serverField = new TextField(settings.serverUrl);
        serverField.setPromptText("如 http://localhost:3210");
        serverField.getStyleClass().add("dialog-field");

        PasswordField keyField = new PasswordField();
        keyField.getStyleClass().add("dialog-field");
        keyField.setPromptText("未配置则使用 CodeBuddy CLI 登录状态");

        VBox cliPanel = new VBox(10,
                section("服务连接"),
                row("服务地址", serverField),
                row("API Key", keyField));

        // ---------- 模型接口（仅 langchain4j 直连） ----------
        ComboBox<String> providerPresetBox = new ComboBox<>();
        providerPresetBox.getItems().add("自定义");
        for (ProviderPreset p : providerPresets()) providerPresetBox.getItems().add(p.name);
        providerPresetBox.getStyleClass().add("dialog-combo");

        TextField llmBaseField = new TextField(settings.llmBaseUrl == null ? "" : settings.llmBaseUrl);
        llmBaseField.setPromptText("如 https://api.deepseek.com/v1");
        llmBaseField.getStyleClass().add("dialog-field");
        PasswordField llmKeyField = new PasswordField();
        llmKeyField.setText(settings.llmApiKey == null ? "" : settings.llmApiKey);
        llmKeyField.setPromptText("API Key");
        llmKeyField.getStyleClass().add("dialog-field");

        ComboBox<String> llmModelCombo = new ComboBox<>();
        llmModelCombo.setEditable(true);
        llmModelCombo.getStyleClass().add("dialog-combo");
        llmModelCombo.getEditor().setPromptText("模型名，如 deepseek-chat");
        llmModelCombo.getEditor().setText(settings.llmModel == null ? "" : settings.llmModel);

        // 根据当前接口地址识别服务商并填充模型列表
        String currentProvider = "自定义";
        for (ProviderPreset p : providerPresets()) {
            if (p.baseUrl.equals(settings.llmBaseUrl)) {
                currentProvider = p.name;
                llmModelCombo.getItems().setAll(p.models);
                break;
            }
        }
        providerPresetBox.setValue(currentProvider);

        // 切换服务商时自动填充接口地址与模型
        providerPresetBox.valueProperty().addListener((obs, o, n) -> {
            if (n == null || "自定义".equals(n)) return;
            for (ProviderPreset p : providerPresets()) {
                if (p.name.equals(n)) {
                    llmBaseField.setText(p.baseUrl);
                    llmModelCombo.getItems().setAll(p.models);
                    if (!p.models.isEmpty()) llmModelCombo.setValue(p.models.get(0));
                    break;
                }
            }
        });

        Label testResult = new Label();
        testResult.getStyleClass().add("dialog-tip");
        testResult.setWrapText(true);
        Button testBtn = new Button("测试连接");
        testBtn.getStyleClass().add("btn-ghost");
        testBtn.setOnAction(e -> {
            testBtn.setDisable(true);
            testResult.setText("正在测试…");
            Thread.ofVirtual().name("llm-test").start(() -> {
                String r;
                try {
                    r = tester == null ? "不可用" : tester.test(llmBaseField.getText(), llmKeyField.getText(), llmModelCombo.getEditor().getText());
                } catch (Exception ex) {
                    r = "连接失败：" + (ex.getMessage() == null ? ex.toString() : ex.getMessage());
                }
                final String result = r;
                javafx.application.Platform.runLater(() -> {
                    testResult.setText(result);
                    testBtn.setDisable(false);
                });
            });
        });
        HBox testRow = new HBox(8, testBtn, testResult);
        testRow.setAlignment(Pos.CENTER_LEFT);

        TextField llmEmbedField = new TextField(settings.llmEmbeddingModel == null ? "" : settings.llmEmbeddingModel);
        llmEmbedField.setPromptText("如 text-embedding-3-small");
        llmEmbedField.getStyleClass().add("dialog-field");
        TextField llmEmbedBaseField = new TextField(settings.llmEmbeddingBaseUrl == null ? "" : settings.llmEmbeddingBaseUrl);
        llmEmbedBaseField.setPromptText("不填则本地存储（不做向量检索）");
        llmEmbedBaseField.getStyleClass().add("dialog-field");
        PasswordField llmEmbedKeyField = new PasswordField();
        llmEmbedKeyField.setText(settings.llmEmbeddingApiKey == null ? "" : settings.llmEmbeddingApiKey);
        llmEmbedKeyField.setPromptText("不填则本地存储（不做向量检索）");
        llmEmbedKeyField.getStyleClass().add("dialog-field");

        VBox lcPanel = new VBox(10,
                section("模型接口（OpenAI 兼容）"),
                row("服务商", providerPresetBox),
                row("接口地址", llmBaseField),
                row("API Key", llmKeyField),
                row("模型名", llmModelCombo),
                testRow,
                section("文档问答嵌入（可选）"),
                row("嵌入模型名", llmEmbedField),
                row("嵌入接口地址", llmEmbedBaseField),
                row("嵌入 API Key", llmEmbedKeyField));

        // ---------- 通用 ----------
        TextField cwdField = new TextField(settings.cwd);
        cwdField.getStyleClass().add("dialog-field");
        Button browse = new Button("浏览…");
        browse.getStyleClass().add("btn-ghost");
        browse.setOnAction(e -> {
            DirectoryChooser chooser = new DirectoryChooser();
            chooser.setTitle("选择 Agent 工作目录");
            File init = new File(cwdField.getText() == null || cwdField.getText().isBlank()
                    ? System.getProperty("user.dir") : cwdField.getText());
            if (init.isDirectory()) chooser.setInitialDirectory(init);
            File dir = chooser.showDialog(dialog);
            if (dir != null) cwdField.setText(dir.getAbsolutePath());
        });
        HBox cwdRow = new HBox(8, cwdField, browse);
        HBox.setHgrow(cwdField, Priority.ALWAYS);

        ComboBox<String> permBox = new ComboBox<>();
        permBox.getItems().addAll(
                "default（每次工具调用询问）",
                "acceptEdits（自动允许文件编辑）",
                "plan（仅规划，不执行）",
                "bypassPermissions（全部允许，谨慎使用）");
        int idx = switch (settings.permissionMode == null ? "default" : settings.permissionMode) {
            case "acceptEdits" -> 1;
            case "plan" -> 2;
            case "bypassPermissions" -> 3;
            default -> 0;
        };
        permBox.getSelectionModel().select(idx);
        permBox.setMaxWidth(Double.MAX_VALUE);
        permBox.getStyleClass().add("dialog-combo");

        ComboBox<String> themeBox = new ComboBox<>();
        for (String t : Theme.ALL) themeBox.getItems().add(Theme.displayName(t));
        int themeIdx = Theme.ALL.indexOf(settings.theme == null || settings.theme.isBlank() ? "light" : settings.theme);
        if (themeIdx < 0) themeIdx = 0;
        themeBox.getSelectionModel().select(themeIdx);
        themeBox.setMaxWidth(Double.MAX_VALUE);
        themeBox.getStyleClass().add("dialog-combo");

        CheckBox debugBox = new CheckBox("全量打印模型输入输出（含系统提示词、历史与工具参数）");
        debugBox.setSelected(settings.debug);
        debugBox.getStyleClass().add("dialog-check");

        ComboBox<String> historyBox = new ComboBox<>();
        historyBox.getItems().addAll("不限制", "1 轮", "2 轮", "3 轮", "5 轮", "10 轮", "20 轮");
        String historyValue = settings.historyRounds < 0 ? "不限制" : settings.historyRounds + " 轮";
        if (!historyBox.getItems().contains(historyValue)) historyBox.getItems().add(historyValue);
        historyBox.setValue(historyValue);
        historyBox.setMaxWidth(Double.MAX_VALUE);
        historyBox.getStyleClass().add("dialog-combo");

        VBox generalPanel = new VBox(10,
                section("通用"),
                row("工作目录", cwdRow),
                row("权限模式", permBox),
                row("界面风格", themeBox),
                row("上下文轮数", historyBox),
                row("调试日志", debugBox));

        // 根据模型来源切换展示对应的属性
        Runnable refreshPanels = () -> {
            boolean lc = providerBox.getSelectionModel().getSelectedIndex() == 1;
            setVisible(cliPanel, !lc);
            setVisible(lcPanel, lc);
        };
        providerBox.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> refreshPanels.run());
        refreshPanels.run();

        // ---------- 按钮 ----------
        Button cancel = new Button("取消");
        cancel.getStyleClass().add("btn-secondary");
        cancel.setOnAction(e -> dialog.close());

        Button save = new Button("保存");
        save.getStyleClass().add("btn-primary");
        save.setOnAction(e -> {
            String mode = switch (permBox.getSelectionModel().getSelectedIndex()) {
                case 1 -> "acceptEdits";
                case 2 -> "plan";
                case 3 -> "bypassPermissions";
                default -> "default";
            };
            String key = keyField.getText();
            int ti = themeBox.getSelectionModel().getSelectedIndex();
            String theme = (ti >= 0 && ti < Theme.ALL.size()) ? Theme.ALL.get(ti) : "light";
            String provider = providerBox.getSelectionModel().getSelectedIndex() == 1 ? "langchain4j" : "codebuddy";
            saver.save(serverField.getText(), cwdField.getText(), mode,
                    key == null || key.isBlank() ? null : key, theme,
                    provider, llmBaseField.getText(), llmKeyField.getText(), llmModelCombo.getEditor().getText(),
                    llmEmbedField.getText(), llmEmbedBaseField.getText(), llmEmbedKeyField.getText(),
                    debugBox.isSelected(), parseHistoryRounds(historyBox.getValue()));
            dialog.close();
        });

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox btns = new HBox(10, sp, cancel, save);
        btns.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(row("模型来源", providerBox), cliPanel, lcPanel, generalPanel, btns);

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    /** “不限制”解析为 -1，其余为“N 轮”中的 N。 */
    private static int parseHistoryRounds(String value) {
        if (value == null || value.isBlank() || value.startsWith("不限制")) return -1;
        String digits = value.replaceAll("[^0-9]", "");
        try {
            return digits.isEmpty() ? 3 : Integer.parseInt(digits);
        } catch (NumberFormatException e) {
            return 3;
        }
    }

    private static Label section(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("dialog-section");
        return l;
    }

    private static HBox row(String label, Region field) {
        Label l = new Label(label);
        l.getStyleClass().add("dialog-label");
        l.setPrefWidth(130);
        l.setMinWidth(130);
        field.setMaxWidth(Double.MAX_VALUE);
        HBox box = new HBox(12, l, field);
        box.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(field, Priority.ALWAYS);
        return box;
    }

    private static void setVisible(javafx.scene.Node node, boolean visible) {
        node.setVisible(visible);
        node.setManaged(visible);
    }

    // ================= 定时任务 =================

    public interface ScheduleSaver {
        /**
         * 保存一个定时任务。
         *
         * @param cron    5 段 cron 表达式（分 时 日 月 周）
         * @param content 定时发送的消息
         * @param enabled 是否启用
         */
        void save(String cron, String content, boolean enabled);
    }

    private static final DateTimeFormatter SCHEDULE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static void showSchedule(Stage owner, ScheduleSaver saver) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("定时任务");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(520);

        Label title = new Label("定时任务");
        title.getStyleClass().add("dialog-title");

        Label tip = new Label("每个定时任务对应一个专属会话，到点后向该会话发送内容并触发 Agent。");
        tip.getStyleClass().add("dialog-tip");
        tip.setWrapText(true);

        Label l2 = new Label("要发送的消息");
        l2.getStyleClass().add("dialog-label");
        TextArea contentField = new TextArea();
        contentField.getStyleClass().add("dialog-field");
        contentField.setPrefRowCount(3);
        contentField.setWrapText(true);
        contentField.setPromptText("定时发送的内容…");

        // ---------- 分字段 cron 构建器 ----------
        Label lc = new Label("执行计划（cron：分 时 日 月 周）");
        lc.getStyleClass().add("dialog-label");
        String[] labels = {"分钟", "小时", "日", "月", "周"};
        String[][] options = {
                {"*", "*/5", "*/10", "*/15", "*/30", "0"},
                {"*", "0", "9", "12", "18", "*/2"},
                {"*", "1", "15"},
                {"*", "1", "6", "12"},
                {"*", "1", "2", "3", "4", "5", "0", "1-5"},
        };
        String[] defaults = {"0", "9", "*", "*", "*"};

        List<ComboBox<String>> boxes = new ArrayList<>();
        HBox fields = new HBox(8);
        for (int i = 0; i < 5; i++) {
            ComboBox<String> cb = new ComboBox<>();
            cb.setEditable(true);
            cb.getItems().addAll(options[i]);
            cb.setValue(defaults[i]);
            cb.getStyleClass().add("cron-field");
            cb.setPrefWidth(76);
            boxes.add(cb);
            Label lbl = new Label(labels[i]);
            lbl.getStyleClass().add("cron-label");
            VBox col = new VBox(4, lbl, cb);
            fields.getChildren().add(col);
        }

        Label preview = new Label();
        preview.getStyleClass().add("dialog-tip");
        preview.setWrapText(true);

        Runnable refresh = () -> {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 5; i++) {
                String v = boxes.get(i).getEditor().getText();
                sb.append(v == null ? "*" : v.trim());
                if (i < 4) sb.append(' ');
            }
            String cron = sb.toString();
            try {
                CronExpression ce = CronExpression.parse(cron);
                ZonedDateTime next = ce.next(ZonedDateTime.now());
                preview.setText("cron: " + ce.expression() + "\n含义: " + ce.describe()
                        + "\n下次执行: " + (next == null ? "无匹配时间" : SCHEDULE_FMT.format(next)));
            } catch (Exception ex) {
                preview.setText("cron: " + cron + "\n表达式无效");
            }
        };
        for (ComboBox<String> cb : boxes) {
            cb.getEditor().textProperty().addListener((obs, o, n) -> refresh.run());
        }

        // 常用预设
        HBox presets = new HBox(8);
        String[][] presetDefs = {
                {"每分钟", "* * * * *"},
                {"每小时", "0 * * * *"},
                {"每天", "0 9 * * *"},
                {"每周一", "0 9 * * 1"},
        };
        for (String[] p : presetDefs) {
            Button b = new Button(p[0]);
            b.getStyleClass().add("preset-chip");
            String[] parts = p[1].split(" ");
            b.setOnAction(e -> {
                for (int i = 0; i < 5; i++) boxes.get(i).setValue(parts[i]);
                refresh.run();
            });
            presets.getChildren().add(b);
        }

        CheckBox enabled = new CheckBox("启用该定时任务");
        enabled.setSelected(true);

        Button cancel = new Button("取消");
        cancel.getStyleClass().add("btn-secondary");
        cancel.setOnAction(e -> dialog.close());

        Button save = new Button("保存");
        save.getStyleClass().add("btn-primary");
        save.setOnAction(e -> {
            String content = contentField.getText() == null ? "" : contentField.getText().trim();
            if (content.isBlank()) {
                tip.setText("请填写消息内容。");
                return;
            }
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 5; i++) {
                String v = boxes.get(i).getEditor().getText();
                sb.append(v == null ? "*" : v.trim());
                if (i < 4) sb.append(' ');
            }
            String cron = sb.toString();
            CronExpression ce;
            try {
                ce = CronExpression.parse(cron);
            } catch (Exception ex) {
                tip.setText("cron 表达式无效，请检查各字段。");
                return;
            }
            if (ce.next(ZonedDateTime.now()) == null) {
                tip.setText("该 cron 没有可匹配的时间，请调整。");
                return;
            }
            saver.save(ce.expression(), content, enabled.isSelected());
            dialog.close();
        });

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox btns = new HBox(10, sp, cancel, save);
        btns.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title, tip, l2, contentField, lc, fields, presets, preview, enabled, btns);

        refresh.run();

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    // ================= 新建知识库 =================

    public interface KnowledgeBaseSaver {
        void save(String name, int chunkSize, int chunkOverlap);
    }

    public static void showKnowledgeBase(Stage owner, String initialName,
                                         int defaultChunkSize, int defaultChunkOverlap,
                                         KnowledgeBaseSaver saver) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("新建知识库");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(460);

        Label title = new Label("新建知识库");
        title.getStyleClass().add("dialog-title");

        Label tip = new Label("每个知识库独立管理文档；分块大小决定文档切分粒度（重叠需小于分块大小）。");
        tip.getStyleClass().add("dialog-tip");
        tip.setWrapText(true);

        Label nameLabel = new Label("名称");
        nameLabel.getStyleClass().add("dialog-label");
        TextField nameField = new TextField(initialName == null ? "" : initialName);
        nameField.getStyleClass().add("dialog-field");
        nameField.setPromptText("知识库名称…");

        Label sizeLabel = new Label("分块大小（字符）");
        sizeLabel.getStyleClass().add("dialog-label");
        TextField sizeField = new TextField(String.valueOf(defaultChunkSize > 0 ? defaultChunkSize : 300));
        sizeField.getStyleClass().add("dialog-field");

        Label overlapLabel = new Label("重叠（字符）");
        overlapLabel.getStyleClass().add("dialog-label");
        TextField overlapField = new TextField(String.valueOf(defaultChunkOverlap >= 0 ? defaultChunkOverlap : 30));
        overlapField.getStyleClass().add("dialog-field");

        VBox sizeCol = new VBox(4, sizeLabel, sizeField);
        HBox.setHgrow(sizeCol, Priority.ALWAYS);
        VBox overlapCol = new VBox(4, overlapLabel, overlapField);
        HBox.setHgrow(overlapCol, Priority.ALWAYS);
        HBox nums = new HBox(12, sizeCol, overlapCol);

        Button cancel = new Button("取消");
        cancel.getStyleClass().add("btn-secondary");
        cancel.setOnAction(e -> dialog.close());

        Button save = new Button("创建");
        save.getStyleClass().add("btn-primary");
        save.setOnAction(e -> {
            String name = nameField.getText() == null ? "" : nameField.getText().trim();
            if (name.isBlank()) {
                tip.setText("请填写知识库名称。");
                return;
            }
            int size;
            int overlap;
            try {
                size = Integer.parseInt(sizeField.getText().trim());
                overlap = Integer.parseInt(overlapField.getText().trim());
            } catch (NumberFormatException ex) {
                tip.setText("分块大小和重叠必须是整数。");
                return;
            }
            if (size <= 0) {
                tip.setText("分块大小必须大于 0。");
                return;
            }
            if (overlap < 0 || overlap >= size) {
                tip.setText("重叠必须满足 0 ≤ 重叠 < 分块大小。");
                return;
            }
            saver.save(name, size, overlap);
            dialog.close();
        });

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox btns = new HBox(10, sp, cancel, save);
        btns.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title, tip, nameLabel, nameField, nums, btns);

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    // ================= 定时任务列表 =================

    public static void showScheduleList(Stage owner, Supplier<List<ScheduledTask>> tasksSupplier,
                                        Runnable onNew, BiConsumer<String, Boolean> onToggle) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("定时任务");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(560);

        Label title = new Label("定时任务");
        title.getStyleClass().add("dialog-title");

        Label tip = new Label("到点后向专属会话发送内容并触发 Agent；可随时停用 / 启用。");
        tip.getStyleClass().add("dialog-tip");
        tip.setWrapText(true);

        VBox listBox = new VBox(8);
        ScrollPane scroll = new ScrollPane(listBox);
        scroll.getStyleClass().add("schedule-scroll");
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setPrefHeight(340);
        scroll.setMaxHeight(340);

        final Runnable[] render = new Runnable[1];
        render[0] = () -> {
            listBox.getChildren().clear();
            List<ScheduledTask> tasks = tasksSupplier == null ? new ArrayList<>() : tasksSupplier.get();
            if (tasks == null || tasks.isEmpty()) {
                Label empty = new Label("暂无定时任务，点击下方「新建定时任务」创建。");
                empty.getStyleClass().add("dialog-tip");
                empty.setWrapText(true);
                listBox.getChildren().add(empty);
                return;
            }
            for (ScheduledTask t : tasks) {
                listBox.getChildren().add(buildScheduleRow(t, (id, enabled) -> {
                    if (onToggle != null) onToggle.accept(id, enabled);
                    render[0].run();
                }));
            }
        };

        Button newBtn = new Button("新建定时任务");
        newBtn.getStyleClass().add("btn-primary");
        newBtn.setOnAction(e -> {
            if (onNew != null) onNew.run();
            render[0].run();
        });

        Button close = new Button("关闭");
        close.getStyleClass().add("btn-secondary");
        close.setOnAction(e -> dialog.close());

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox btns = new HBox(10, sp, newBtn, close);
        btns.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title, tip, scroll, btns);
        render[0].run();

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private static VBox buildScheduleRow(ScheduledTask t, BiConsumer<String, Boolean> onToggle) {
        CheckBox toggle = new CheckBox("启用");
        toggle.getStyleClass().add("skill-toggle");
        toggle.setSelected(t.enabled);
        toggle.setOnAction(e -> {
            if (onToggle != null) onToggle.accept(t.id, toggle.isSelected());
        });

        Label cronLbl = new Label(cronText(t));
        cronLbl.getStyleClass().add("schedule-cron");

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox header = new HBox(8, toggle, sp, cronLbl);
        header.setAlignment(Pos.CENTER_LEFT);

        Label content = new Label(t.content == null ? "" : t.content.replace("\n", " ").trim());
        content.getStyleClass().add("schedule-content");
        content.setWrapText(true);

        Label next = new Label(t.enabled ? nextText(t) : "已停用");
        next.getStyleClass().add("schedule-next");

        VBox row = new VBox(4, header, content, next);
        row.getStyleClass().add("schedule-row");
        if (!t.enabled) row.getStyleClass().add("schedule-disabled");
        return row;
    }

    private static String cronText(ScheduledTask t) {
        try {
            CronExpression ce = CronExpression.parse(t.cron);
            return ce.expression() + "  ·  " + ce.describe();
        } catch (Exception e) {
            return t.cron == null ? "" : t.cron;
        }
    }

    private static String nextText(ScheduledTask t) {
        try {
            CronExpression ce = CronExpression.parse(t.cron);
            ZonedDateTime next = ce.next(ZonedDateTime.now());
            return "下次执行：" + (next == null ? "无匹配时间" : SCHEDULE_FMT.format(next));
        } catch (Exception e) {
            return "下次执行：无匹配时间";
        }
    }

    // ================= 技能编辑 =================

    public interface SkillSaver {
        void save(String name, String description, String content);
    }

    public static void showSkillEditor(Stage owner, Skill skill, SkillSaver saver, Runnable onOpenFolder) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle(skill == null ? "新建技能" : "编辑技能");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(560);

        Label title = new Label(skill == null ? "新建技能" : "编辑技能");
        title.getStyleClass().add("dialog-title");

        Label tip = new Label("技能为目录内的 SKILL.md（frontmatter 含 name/description），正文为 markdown 指令；目录内可附带脚本。");
        tip.getStyleClass().add("dialog-tip");
        tip.setWrapText(true);

        Label l1 = new Label("技能名称");
        l1.getStyleClass().add("dialog-label");
        TextField nameField = new TextField(skill == null ? "" : skill.name);
        nameField.getStyleClass().add("dialog-field");
        nameField.setPromptText("例如：pdf 处理");

        Label l2 = new Label("技能描述");
        l2.getStyleClass().add("dialog-label");
        TextField descField = new TextField(skill == null ? "" : skill.description);
        descField.getStyleClass().add("dialog-field");
        descField.setPromptText("说明该技能何时使用");

        Label l3 = new Label("指令内容（Markdown）");
        l3.getStyleClass().add("dialog-label");
        TextArea contentField = new TextArea(skill == null ? "" : skill.content);
        contentField.getStyleClass().add("dialog-field");
        contentField.setPrefRowCount(12);
        contentField.setWrapText(true);
        contentField.setPromptText("# 技能说明\n\n在此编写该技能的指令…");

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);

        Button cancel = new Button("取消");
        cancel.getStyleClass().add("btn-secondary");
        cancel.setOnAction(e -> dialog.close());

        Button save = new Button("保存");
        save.getStyleClass().add("btn-primary");
        save.setOnAction(e -> {
            String name = nameField.getText() == null ? "" : nameField.getText().trim();
            if (name.isBlank()) {
                tip.setText("请填写技能名称。");
                return;
            }
            saver.save(name, descField.getText(), contentField.getText());
            dialog.close();
        });

        HBox row = new HBox(10);
        row.getChildren().add(sp);
        if (skill != null && onOpenFolder != null) {
            Button open = new Button("打开目录");
            open.getStyleClass().add("btn-ghost");
            open.setOnAction(e -> onOpenFolder.run());
            row.getChildren().add(open);
        }
        row.getChildren().addAll(cancel, save);
        row.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title, tip, l1, nameField, l2, descField, l3, contentField, row);

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    // ================= jagent 登录 =================

    /** 登录流程回调 */
    public interface LoginFlow {
        /** 发起登录，返回登录 URL；已登录返回 null */
        String startLogin();

        /** 检查登录状态；已登录返回用户名，否则 null */
        String checkLogin();
    }

    public static void showLogin(Stage owner, LoginFlow flow, Runnable onLoggedIn) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("登录 CodeBuddy");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(520);

        Label title = new Label("登录 CodeBuddy");
        title.getStyleClass().add("dialog-title");

        Label desc = new Label("点击「开始登录」获取登录链接，在浏览器中完成授权后，回到此处点击「我已完成登录」。");
        desc.getStyleClass().add("dialog-tip");
        desc.setWrapText(true);

        TextField urlField = new TextField();
        urlField.getStyleClass().add("dialog-field");
        urlField.setEditable(false);
        urlField.setPromptText("点击「开始登录」生成登录链接…");

        Label status = new Label();
        status.getStyleClass().add("dialog-tip");
        status.setWrapText(true);

        Button startBtn = new Button("开始登录");
        startBtn.getStyleClass().add("btn-primary");

        Button openBtn = new Button("在浏览器中打开");
        openBtn.getStyleClass().add("btn-secondary");
        openBtn.setDisable(true);

        Button copyBtn = new Button("复制链接");
        copyBtn.getStyleClass().add("btn-secondary");
        copyBtn.setDisable(true);

        Button doneBtn = new Button("我已完成登录");
        doneBtn.getStyleClass().add("btn-primary");
        doneBtn.setDisable(true);

        Button cancel = new Button("关闭");
        cancel.getStyleClass().add("btn-secondary");

        Runnable openBrowser = () -> {
            String url = urlField.getText();
            if (url == null || url.isBlank()) return;
            try {
                java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
            } catch (Exception e) {
                status.setText("无法自动打开浏览器，请手动复制链接到浏览器。");
            }
        };
        openBtn.setOnAction(e -> openBrowser.run());

        copyBtn.setOnAction(e -> {
            String url = urlField.getText();
            if (url == null || url.isBlank()) return;
            try {
                javafx.scene.input.Clipboard cb = javafx.scene.input.Clipboard.getSystemClipboard();
                cb.setContent(java.util.Map.of(javafx.scene.input.DataFormat.PLAIN_TEXT, url));
                status.setText("链接已复制到剪贴板。");
            } catch (Exception ignored) {
            }
        });

        startBtn.setOnAction(e -> {
            startBtn.setDisable(true);
            status.setText("正在生成登录链接…");
            Thread.ofVirtual().name("login-flow").start(() -> {
                String url = null;
                try {
                    url = flow.startLogin();
                } catch (Exception ignored) {
                }
                final String authUrl = url;
                javafx.application.Platform.runLater(() -> {
                    if (authUrl == null) {
                        status.setText("已登录，无需再次登录。");
                        startBtn.setDisable(false);
                    } else {
                        urlField.setText(authUrl);
                        openBtn.setDisable(false);
                        copyBtn.setDisable(false);
                        doneBtn.setDisable(false);
                        status.setText("请在浏览器中完成登录，然后点击「我已完成登录」。");
                        openBrowser.run();
                    }
                });
            });
        });

        doneBtn.setOnAction(e -> {
            doneBtn.setDisable(true);
            status.setText("正在检查登录状态…");
            Thread.ofVirtual().name("login-check").start(() -> {
                String user = null;
                try {
                    user = flow.checkLogin();
                } catch (Exception ignored) {
                }
                final String userName = user;
                javafx.application.Platform.runLater(() -> {
                    if (userName != null) {
                        status.setText("登录成功：" + userName);
                        dialog.close();
                        if (onLoggedIn != null) onLoggedIn.run();
                    } else {
                        doneBtn.setDisable(false);
                        status.setText("尚未检测到登录状态，请完成浏览器授权后重试。");
                    }
                });
            });
        });

        cancel.setOnAction(e -> dialog.close());

        HBox row1 = new HBox(10, startBtn, openBtn, copyBtn);
        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox row2 = new HBox(10, sp, cancel, doneBtn);
        row2.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title, desc, urlField, row1, status, row2);

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.show();
    }

    // ================= 权限确认 =================

    public static void showPermission(Stage owner, String toolName, String inputJson,
                                      BiConsumer<String, Boolean> responder) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("工具权限请求");
        dialog.setResizable(false);

        VBox root = new VBox(12);
        root.getStyleClass().add("dialog-root");
        root.setPadding(new Insets(20, 22, 18, 22));
        root.setPrefWidth(520);

        Label title = new Label("Agent 请求使用工具");
        title.getStyleClass().add("dialog-title");

        HBox toolRow = new HBox(8);
        toolRow.getStyleClass().add("perm-tool-name");
        toolRow.getChildren().addAll(
                Icons.stroke(Icons.FOLDER, 16, javafx.scene.paint.Color.web("#0052D9")),
                new Label(toolName));

        Label desc = new Label("该操作将访问你的工作目录，是否允许执行？");
        desc.getStyleClass().add("dialog-tip");
        desc.setWrapText(true);

        TextFlow code = new TextFlow();
        code.getStyleClass().add("md-code-flow");
        Text t = new Text(pretty(inputJson));
        t.getStyleClass().add("md-code-text");
        code.getChildren().add(t);
        ScrollPane scroll = new ScrollPane(code);
        scroll.getStyleClass().add("perm-code-scroll");
        scroll.setPrefHeight(200);
        scroll.setMaxHeight(200);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        Button deny = new Button("拒绝");
        deny.getStyleClass().add("btn-secondary");
        deny.setOnAction(e -> {
            responder.accept(toolName, false);
            dialog.close();
        });

        Button allow = new Button("允许");
        allow.getStyleClass().add("btn-primary");
        allow.setOnAction(e -> {
            responder.accept(toolName, true);
            dialog.close();
        });

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        HBox btns = new HBox(10, sp, deny, allow);
        btns.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().addAll(title, toolRow, desc, scroll, btns);

        // 直接关闭窗口视为拒绝
        dialog.setOnCloseRequest(e -> responder.accept(toolName, false));

        Scene scene = new Scene(root);
        Theme.applyTo(scene);
        dialog.setScene(scene);
        dialog.showAndWait();
    }

    private static String pretty(String json) {
        if (json == null || json.isBlank()) return "{}";
        try {
            return new com.google.gson.GsonBuilder().setPrettyPrinting().create()
                    .toJson(com.google.gson.JsonParser.parseString(json));
        } catch (Exception e) {
            return json;
        }
    }
}
