package com.jagent.harness.permission;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.Set;

/**
 * Harness 权限闸门：无 UI 场景下的工具调用审批策略。
 *
 * <p>设计为不可绕过的基础层：只读工具/MCP 工具允许；Bash 仅允许只读白名单命令；
 * 联网命令必须显式开启；写操作始终拒绝。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class HarnessPermissionPolicy {

    /** 默认允许的只读命令。 */
    private static final Set<String> SAFE_COMMANDS = Set.of(
            "pwd", "ls", "date", "echo", "printf", "wc", "which", "whoami", "uname", "find");

    /** 允许的 git 只读子命令。 */
    private static final Set<String> SAFE_GIT_SUBCOMMANDS = Set.of(
            "status", "log", "diff", "show", "branch", "rev-parse");

    private HarnessPermissionPolicy() {}

    /**
     * @param toolName     工具名（Read / Glob / Grep / Bash / Write / server__tool）
     * @param inputJson    工具入参 JSON
     * @param allowNetwork 是否允许 curl/wget 发起 GET 请求
     */
    public static boolean permitted(String toolName, String inputJson, boolean allowNetwork) {
        if (toolName == null) return false;
        if (toolName.startsWith("Read") || toolName.startsWith("Glob") || toolName.startsWith("Grep")) {
            return true;
        }
        if (toolName.contains("__")) return true; // MCP 工具：server__tool
        if ("Bash".equals(toolName)) {
            return safeBash(commandOf(inputJson), allowNetwork);
        }
        return false; // Write 等写操作始终拒绝
    }

    private static String commandOf(String inputJson) {
        try {
            JsonObject args = JsonParser.parseString(inputJson).getAsJsonObject();
            return args.has("command") && !args.get("command").isJsonNull()
                    ? args.get("command").getAsString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    /** 校验 Bash 命令：禁止重定向/命令替换/后台，并按段检查只读白名单。 */
    private static boolean safeBash(String command, boolean allowNetwork) {
        if (command == null || command.isBlank()) return false;
        String normalized = command.trim();
        if (normalized.contains(">") || normalized.contains("<")
                || normalized.contains("`") || normalized.contains("$(") || normalized.contains("${")
                || normalized.contains("&")) {
            return false;
        }
        String[] segments = normalized.split("\\s*(?:;|&&|\\|\\||\\|)\\s*");
        if (segments.length == 0) return false;
        for (String segment : segments) {
            if (segment.isBlank()) continue;
            String[] tokens = segment.trim().split("\\s+");
            int index = 0;
            while (index < tokens.length && tokens[index].contains("=")) index++; // 跳过 FOO=bar
            if (index >= tokens.length) return false;
            String cmd = tokens[index];
            if (SAFE_COMMANDS.contains(cmd)) {
                if ("find".equals(cmd) && containsAny(segment, "-exec", "-execdir", "-delete", "-ok")) {
                    return false;
                }
                continue;
            }
            if ("git".equals(cmd)) {
                if (index + 1 >= tokens.length || !SAFE_GIT_SUBCOMMANDS.contains(tokens[index + 1])) {
                    return false;
                }
                continue;
            }
            if ("curl".equals(cmd) || "wget".equals(cmd)) {
                if (!allowNetwork || !safeNetworkCommand(segment, cmd)) return false;
                continue;
            }
            return false;
        }
        return true;
    }

    private static boolean safeNetworkCommand(String segment, String cmd) {
        if (!segment.contains("http://") && !segment.contains("https://")) return false;
        if ("curl".equals(cmd)) {
            return !containsAny(segment, "-o ", "-O", "--output", "-d ", "--data", "-F ", "--form",
                    "-T ", "--upload-file", "-X ", "--config", "--netrc");
        }
        return !containsAny(segment, "-O ", "-o ", "--post-data", "--post-file");
    }

    private static boolean containsAny(String text, String... needles) {
        for (String needle : needles) {
            if (text.contains(needle)) return true;
        }
        return false;
    }
}
