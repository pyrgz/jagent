package com.jagent.harness;

import com.jagent.common.exception.BusinessException;
import com.jagent.harness.checkpoint.HarnessCheckpointStore;
import com.jagent.harness.checkpoint.RunState;
import com.jagent.harness.checkpoint.StepState;
import com.jagent.harness.verify.HarnessVerifier;
import com.jagent.harness.verify.VerificationResult;
import com.jagent.harness.verify.VerifyDef;
import com.jagent.harness.verify.Verifiers;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 配置文件驱动的 Harness 编排：读取 {@code data/pipelines.json}，
 * 按配置顺序组装 {@link HarnessPipeline} 并执行。
 *
 * <p>支持 checkpoint 断点续跑与独立验收：</p>
 * <pre>
 * /harness pipeline list
 * /harness pipeline inspect
 * /harness pipeline --runs
 * /harness pipeline --resume &lt;runId&gt;
 * </pre>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class HarnessPipelineService implements Harness {

    @Override
    public String id() { return "pipeline"; }

    @Override
    public String name() { return "编排"; }

    private static final Logger log = LogManager.getLogger(HarnessPipelineService.class);
    private static final Gson GSON = new GsonBuilder().create();

    private final HarnessRegistry registry;
    private final Path configFile;
    private final HarnessCheckpointStore checkpoints;

    private long loadedMtime = Long.MIN_VALUE;
    private Map<String, PipelineDef> pipelines = new LinkedHashMap<>();

    public HarnessPipelineService(HarnessRegistry registry, Path configFile) {
        this(registry, configFile, new HarnessCheckpointStore());
    }

    public HarnessPipelineService(HarnessRegistry registry, Path configFile,
                                  HarnessCheckpointStore checkpoints) {
        this.registry = registry;
        this.configFile = configFile;
        this.checkpoints = checkpoints;
    }

    /** 入参：{@code <编排名> [参数]} / {@code list} / {@code --runs} / {@code --resume <runId>}。 */
    @Override
    public String execute(String input) {
        loadIfChanged();
        String arg = input == null ? "" : input.trim();

        if ("--runs".equalsIgnoreCase(arg) || "runs".equalsIgnoreCase(arg)) {
            return listRuns();
        }
        if (arg.startsWith("--resume")) {
            String runId = arg.substring("--resume".length()).trim();
            return runId.isEmpty() ? usage() : resume(runId);
        }
        if (pipelines.isEmpty()) {
            return "未配置编排（" + configFile + "）\n\n" + usage();
        }
        if (arg.isEmpty() || "list".equalsIgnoreCase(arg)) {
            return listPipelines();
        }

        int space = arg.indexOf(' ');
        String name = space < 0 ? arg : arg.substring(0, space);
        String stepInput = space < 0 ? "" : arg.substring(space + 1).trim();

        PipelineDef def = pipelines.get(name);
        if (def == null) {
            return "未找到编排：" + name + "\n\n" + listPipelines();
        }
        if (!def.enabled) {
            return "编排已停用：" + name;
        }
        return runNew(name, def, stepInput);
    }

    // ================= 新建运行 =================

    private String runNew(String pipelineId, PipelineDef def, String stepInput) {
        List<StepState> states = buildStepStates(def.steps);
        if (states.isEmpty()) {
            return "编排没有有效步骤：" + pipelineId;
        }

        String title = def.name == null || def.name.isBlank() ? pipelineId : def.name;
        RunState state = checkpoints.create(pipelineId, title, stepInput, def.chain,
                states, def.verify == null ? new ArrayList<>() : def.verify);
        checkpoints.save(state);

        HarnessPipeline pipeline = buildPipeline(state.steps, state.chain);
        List<HarnessPipeline.StepResult> results = pipeline.execute(stepInput, saveInterceptor(state, -1));
        return finish("编排：" + title, state, results);
    }

    // ================= 断点续跑 =================

    private String resume(String runId) {
        RunState state = checkpoints.load(runId);
        if (state == null) {
            return "未找到运行记录：" + runId + "\n\n" + listRuns();
        }
        if (state.steps == null || state.steps.isEmpty()) {
            return "运行记录没有有效步骤，无法续跑：" + runId;
        }
        int startAt = firstUnfinished(state.steps);
        if (startAt < 0) {
            return "该运行已全部成功，无需续跑。\n运行 ID：" + state.runId;
        }

        // 失败步骤及其后续步骤重新执行，之前成功的步骤复用 checkpoint
        for (int i = startAt; i < state.steps.size(); i++) {
            StepState step = state.steps.get(i);
            step.status = "pending";
            step.output = null;
            step.error = null;
        }
        state.status = "running";
        checkpoints.save(state);

        HarnessPipeline pipeline = buildPipeline(state.steps, state.chain);
        List<HarnessPipeline.StepResult> results = pipeline.execute(
                state.invocationInput, saveInterceptor(state, startAt));
        return finish("续跑：" + state.name + "（" + state.runId + "）", state, results);
    }

    /** 返回第一个未完成（非 ok / skipped）步骤下标；全部完成返回 -1。 */
    private static int firstUnfinished(List<StepState> steps) {
        for (int i = 0; i < steps.size(); i++) {
            String status = steps.get(i).status;
            if (!"ok".equals(status) && !"skipped".equals(status)) return i;
        }
        return -1;
    }

    // ================= checkpoint / 验收 / 报告 =================

    private HarnessPipeline.StepInterceptor saveInterceptor(RunState state, int reuseBefore) {
        return new HarnessPipeline.StepInterceptor() {
            @Override
            public HarnessPipeline.StepResult reuse(int index) {
                if (index >= reuseBefore) return null;
                StepState step = state.steps.get(index);
                if ("skipped".equals(step.status)) {
                    return new HarnessPipeline.StepResult(step.harness, step.name, null, null, true);
                }
                if (!"ok".equals(step.status)) return null;
                return new HarnessPipeline.StepResult(step.harness, step.name, step.output, null);
            }

            @Override
            public void completed(int index, HarnessPipeline.StepResult result) {
                StepState step = state.steps.get(index);
                step.status = result.skipped() ? "skipped" : (result.ok() ? "ok" : "error");
                step.output = result.output();
                step.error = result.error();
                checkpoints.save(state);
            }
        };
    }

    private String finish(String header, RunState state, List<HarnessPipeline.StepResult> results) {
        List<VerificationResult> verifications = verify(state.verify, results);
        state.verification = state.verify == null || state.verify.isEmpty() ? null
                : (allPassed(verifications) ? "passed" : "failed");
        state.status = results.stream().allMatch(HarnessPipeline.StepResult::ok) ? "ok" : "error";
        checkpoints.save(state);

        StringBuilder report = new StringBuilder(header)
                .append("\n运行 ID：").append(state.runId)
                .append("\n状态：").append(state.status);
        for (int i = 0; i < results.size(); i++) {
            HarnessPipeline.StepResult step = results.get(i);
            report.append("\n\n[").append(i + 1).append('/').append(results.size()).append("] ")
                    .append(step.name()).append('\n')
                    .append(step.skipped() ? "已跳过（条件不满足）"
                            : (step.ok() ? step.output() : "执行失败：" + step.error()));
        }
        if (!verifications.isEmpty()) {
            report.append("\n\n验收结果：").append(allPassed(verifications) ? "通过" : "失败");
            for (VerificationResult r : verifications) {
                report.append("\n- ").append(r.passed() ? "通过" : "失败").append("：").append(r.message());
            }
        }
        if ("error".equals(state.status)) {
            report.append("\n\n续跑：/harness pipeline --resume ").append(state.runId);
        }
        return report.toString().trim();
    }

    private static List<VerificationResult> verify(List<VerifyDef> defs,
                                                   List<HarnessPipeline.StepResult> results) {
        List<VerificationResult> out = new ArrayList<>();
        if (defs == null) return out;
        for (VerifyDef def : defs) {
            HarnessVerifier verifier = Verifiers.of(def);
            out.add(verifier.verify(results));
        }
        return out;
    }

    private static boolean allPassed(List<VerificationResult> results) {
        for (VerificationResult r : results) {
            if (!r.passed()) return false;
        }
        return true;
    }

    private HarnessPipeline buildPipeline(List<StepState> steps, boolean chain) {
        HarnessPipeline pipeline = new HarnessPipeline().chain(chain);
        for (StepState step : steps) {
            Harness harness = registry.get(step.harness);
            pipeline.add(harness == null ? new MissingHarness(step.harness) : harness,
                    step.inputTemplate, step.when);
        }
        return pipeline;
    }

    private List<StepState> buildStepStates(List<StepDef> defs) {
        List<StepState> states = new ArrayList<>();
        if (defs == null) return states;
        for (StepDef def : defs) {
            if (def == null || def.harness == null || def.harness.isBlank()) continue;
            String harnessId = def.harness.trim();
            Harness harness = registry.get(harnessId);
            StepState state = new StepState();
            state.index = states.size();
            state.harness = harnessId;
            state.name = harness == null ? harnessId : harness.name();
            state.inputTemplate = def.input;
            state.when = def.when;
            states.add(state);
        }
        return states;
    }

    private String listRuns() {
        List<RunState> runs = checkpoints.recent(10);
        if (runs.isEmpty()) return "暂无运行记录。";
        StringBuilder sb = new StringBuilder("最近的编排运行：\n");
        for (RunState run : runs) {
            sb.append("- ").append(run.runId)
                    .append(" | ").append(run.pipeline)
                    .append(" | ").append(run.status);
            if (run.verification != null) sb.append(" | 验收=").append(run.verification);
            sb.append(" | ").append(run.updatedAt).append('\n');
        }
        return sb.append('\n').append(usage()).toString().trim();
    }

    private synchronized void loadIfChanged() {
        long mtime = configMtime();
        if (mtime == loadedMtime) return;
        loadedMtime = mtime;
        pipelines = new LinkedHashMap<>();

        if (mtime == 0) {
            log.info("未配置 harness 编排（{}）", configFile);
            return;
        }
        try {
            PipelineConfig config = GSON.fromJson(Files.readString(configFile), PipelineConfig.class);
            if (config != null && config.pipelines != null) {
                pipelines.putAll(config.pipelines);
            }
            log.info("harness 编排加载完成：{} 个（{}）", pipelines.size(), configFile);
        } catch (Exception e) {
            log.error("读取 harness 编排配置失败：{}", configFile, e);
        }
    }

    private long configMtime() {
        try {
            return Files.exists(configFile) ? Files.getLastModifiedTime(configFile).toMillis() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private String listPipelines() {
        StringBuilder sb = new StringBuilder("可用编排：\n");
        for (Map.Entry<String, PipelineDef> entry : pipelines.entrySet()) {
            PipelineDef def = entry.getValue();
            sb.append("- ").append(entry.getKey());
            if (def.name != null && !def.name.isBlank()) sb.append("：").append(def.name);
            sb.append("（").append(def.steps == null ? 0 : def.steps.size()).append(" 步）");
            if (!def.enabled) sb.append(" [已停用]");
            sb.append('\n');
        }
        return sb.append('\n').append(usage()).toString().trim();
    }

    private static String usage() {
        return "用法：\n"
                + "/harness pipeline <名称> [步骤参数]\n"
                + "/harness pipeline --runs\n"
                + "/harness pipeline --resume <runId>";
    }

    /** 配置中引用了不存在的 harness 时的占位步骤，保证其余步骤继续执行。 */
    private record MissingHarness(String missingId) implements Harness {
        @Override
        public String id() {
            return missingId;
        }

        @Override
        public String name() {
            return missingId;
        }

        @Override
        public String execute(String input) {
            throw new BusinessException("未找到 harness：" + missingId);
        }
    }

    // ---- 配置文件结构 ----

    private static final class PipelineConfig {
        Map<String, PipelineDef> pipelines = new LinkedHashMap<>();
    }

    private static final class PipelineDef {
        String name;
        boolean enabled = true;
        /** true：未显式指定 input 的步骤自动接收上一步输出 */
        boolean chain = false;
        List<StepDef> steps = new ArrayList<>();
        /** 独立验收规则 */
        List<VerifyDef> verify = new ArrayList<>();
    }

    private static final class StepDef {
        String harness;
        /** 固定入参；为 null 时继承命令参数 */
        String input;
        /** 执行条件；不满足时跳过该步骤 */
        VerifyDef when;
    }
}
