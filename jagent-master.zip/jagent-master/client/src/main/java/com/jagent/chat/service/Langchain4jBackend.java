package com.jagent.chat.service;

import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.ChatRequest;
import com.jagent.common.exception.BaseException;
import com.jagent.common.util.ModelLog;
import com.jagent.mcp.service.McpService;
import com.jagent.chat.tool.Tool;
import com.jagent.chat.tool.ToolKit;
import com.jagent.settings.model.AppSettings;
import com.google.gson.JsonObject;
import dev.langchain4j.agent.tool.ToolExecutionRequest;
import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.SystemMessage;
import dev.langchain4j.data.message.ToolExecutionResultMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.model.chat.StreamingChatModel;
import dev.langchain4j.model.chat.response.ChatResponse;
import dev.langchain4j.model.chat.response.PartialThinking;
import dev.langchain4j.model.chat.response.StreamingChatResponseHandler;
import dev.langchain4j.model.openai.OpenAiStreamingChatModel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * langchain4j 聊天后端：直连 OpenAI 兼容接口（DeepSeek / Qwen / Kimi / GLM 等）
 * 进行流式对话，支持多轮上下文与工具调用（Read / Write / Bash / Glob / Grep）。纯 Java，无 javafx 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class Langchain4jBackend implements ChatBackend {

    private static final Logger log = LogManager.getLogger(Langchain4jBackend.class);
    private static final int MAX_TOOL_TURNS = 10;
    private static final long PERMISSION_TIMEOUT_MINUTES = 5;

    private final AppSettings settings;
    private final McpService mcp;
    private final Map<String, CompletableFuture<Boolean>> pendingPermissions = new ConcurrentHashMap<>();
    /** 每个会话当前有效的请求代号；中断或新请求会使其变化，用于忽略迟到回调。 */
    private final Map<String, Long> generations = new ConcurrentHashMap<>();
    private final java.util.concurrent.atomic.AtomicLong sequence = new java.util.concurrent.atomic.AtomicLong();
    /** 正在阻塞等待响应的会话线程，中断时用于尽快结束等待。 */
    private final Map<String, Thread> running = new ConcurrentHashMap<>();

    public Langchain4jBackend(AppSettings settings, McpService mcp) {
        this.settings = settings;
        this.mcp = mcp;
    }

    @Override
    public String id() {
        return "langchain4j";
    }

    @Override
    public boolean isAvailable() {
        return settings.llmBaseUrl != null && !settings.llmBaseUrl.isBlank()
                && settings.llmApiKey != null && !settings.llmApiKey.isBlank()
                && settings.llmModel != null && !settings.llmModel.isBlank();
    }

    /** 构建流式聊天模型（每次按最新配置构建，开销小、无状态）。 */
    private StreamingChatModel model() {
        return OpenAiStreamingChatModel.builder()
                .baseUrl(settings.llmBaseUrl.trim())
                .apiKey(settings.llmApiKey.trim())
                .modelName(settings.llmModel.trim())
                .build();
    }

    @Override
    public void chat(ChatRequest request, ChatBackend.StreamListener listener) {
        String convId = request.conversationId == null ? "" : request.conversationId;
        long gen = sequence.incrementAndGet();
        generations.put(convId, gen);
        List<dev.langchain4j.data.message.ChatMessage> messages = new ArrayList<>();
        if (request.systemPromptAppend != null && !request.systemPromptAppend.isBlank()) {
            messages.add(SystemMessage.from(request.systemPromptAppend));
        }
        if (request.history != null) {
            for (ChatMessage m : request.history) {
                if (m.content == null || m.content.isBlank()) continue;
                if ("user".equals(m.role)) {
                    messages.add(UserMessage.from(m.content));
                } else if ("assistant".equals(m.role)) {
                    messages.add(AiMessage.from(m.content));
                }
            }
        }
        messages.add(UserMessage.from(request.message));

        List<Tool> tools = new ArrayList<>(ToolKit.defaults(resolveCwd(request)));
        if (mcp != null) {
            List<Tool> mcpTools = mcp.tools();
            if (!mcpTools.isEmpty()) {
                tools.addAll(mcpTools);
                log.info("已加载 MCP 工具：{} 个（将随模型请求发送）", mcpTools.size());
            }
        }
        boolean bypass = "bypassPermissions".equals(request.permissionMode);
        try {
            running.put(convId, Thread.currentThread());
            run(messages, tools, bypass, listener, 0, convId, gen);
        } finally {
            running.remove(convId, Thread.currentThread());
            generations.remove(convId, gen);
        }
    }

    /** 流式发送任意消息列表（供 RAG 复用，无工具）。 */
    public void stream(List<dev.langchain4j.data.message.ChatMessage> messages,
                       ChatBackend.StreamListener listener) {
        String convId = "rag-" + UUID.randomUUID();
        long gen = sequence.incrementAndGet();
        generations.put(convId, gen);
        try {
            run(messages, List.of(), false, listener, 0, convId, gen);
        } finally {
            generations.remove(convId, gen);
        }
    }

    /** 工具调用循环：流式获取回复，若有工具请求则执行并继续，否则结束。 */
    private void run(List<dev.langchain4j.data.message.ChatMessage> messages, List<Tool> tools,
                     boolean bypassPermission, ChatBackend.StreamListener listener, int turn,
                     String convId, long gen) {
        if (!active(convId, gen)) return;
        if (turn >= MAX_TOOL_TURNS) {
            listener.onError("工具调用轮次过多（>" + MAX_TOOL_TURNS + "），已停止");
            return;
        }

        List<ToolSpecification> specs = tools.stream().map(Tool::specification).collect(Collectors.toList());
        Map<String, Tool> byName = tools.stream()
                .collect(Collectors.toMap(t -> t.specification().name(), t -> t, (a, b) -> a));
        if (specs.isEmpty()) {
            log.info("模型请求：第 {} 轮，消息 {} 条，无工具", turn, messages.size());
        } else {
            log.info("模型请求：第 {} 轮，消息 {} 条，工具 {} 个：{}", turn, messages.size(), specs.size(),
                    specs.stream().map(ToolSpecification::name).collect(Collectors.joining(", ")));
        }
        ModelLog.inputMessages(id(), convId, turn, messages, specs);

        CountDownLatch done = new CountDownLatch(1);
        AtomicReference<AiMessage> result = new AtomicReference<>();
        AtomicReference<Throwable> error = new AtomicReference<>();

        dev.langchain4j.model.chat.request.ChatRequest.Builder reqBuilder =
                dev.langchain4j.model.chat.request.ChatRequest.builder().messages(messages);
        if (!specs.isEmpty()) reqBuilder.toolSpecifications(specs);
        dev.langchain4j.model.chat.request.ChatRequest lcRequest = reqBuilder.build();

        try {
            model().chat(lcRequest, new StreamingChatResponseHandler() {
                @Override
                public void onPartialResponse(String partialResponse) {
                    if (!active(convId, gen)) return;
                    listener.onText(partialResponse);
                }

                @Override
                public void onPartialThinking(PartialThinking partialThinking) {
                    if (!active(convId, gen)) return;
                    listener.onThinking(partialThinking.text());
                }

                @Override
                public void onCompleteResponse(ChatResponse response) {
                    result.set(response.aiMessage());
                    done.countDown();
                }

                @Override
                public void onError(Throwable t) {
                    error.set(t);
                    done.countDown();
                }
            });
        } catch (Exception e) {
            BaseException be = ModelErrorMapper.toUserError(e);
            log.error("langchain4j 请求异常：{}", be.getMessage(), e);
            listener.onError(be.getCode(), be.getMessage());
            return;
        }

        try {
            done.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        if (!active(convId, gen)) return;

        if (error.get() != null) {
            BaseException be = ModelErrorMapper.toUserError(error.get());
            log.error("langchain4j 流式响应失败：{}", be.getMessage(), error.get());
            listener.onError(be.getCode(), be.getMessage());
            return;
        }

        AiMessage ai = result.get();
        List<ToolExecutionRequest> toolReqs = ai == null ? List.of() : ai.toolExecutionRequests();
        if (toolReqs == null || toolReqs.isEmpty()) {
            listener.onDone(new JsonObject());
            return;
        }

        messages.add(AiMessage.from(toolReqs));
        for (ToolExecutionRequest tr : toolReqs) {
            listener.onTool(tr.id(), tr.name(), tr.arguments());
            Tool tool = byName.get(tr.name());
            boolean isError = false;
            String toolResult;
            if (tool == null) {
                toolResult = "未知工具：" + tr.name();
                isError = true;
            } else if (tool.requiresPermission() && !bypassPermission) {
                if (requestPermission(tr.name(), tr.arguments(), listener)) {
                    toolResult = execute(tool, tr.arguments());
                    isError = toolResult.startsWith("工具执行失败：");
                } else {
                    toolResult = "用户拒绝了该操作";
                    isError = true;
                }
            } else {
                toolResult = execute(tool, tr.arguments());
                isError = toolResult.startsWith("工具执行失败：");
            }
            listener.onToolResult(tr.id(), toolResult, isError);
            messages.add(ToolExecutionResultMessage.from(tr.id(), tr.name(), toolResult));
        }
        run(messages, tools, bypassPermission, listener, turn + 1, convId, gen);
    }

    private static String execute(Tool tool, String argumentsJson) {
        try {
            return tool.execute(argumentsJson);
        } catch (Exception e) {
            return "工具执行失败：" + (e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    /** 弹出权限确认并阻塞等待用户决策（在工具执行线程上）。 */
    private boolean requestPermission(String toolName, String inputJson, ChatBackend.StreamListener listener) {
        String requestId = UUID.randomUUID().toString();
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        pendingPermissions.put(requestId, future);
        try {
            listener.onPermissionRequest(requestId, toolName, inputJson);
            return future.get(PERMISSION_TIMEOUT_MINUTES, TimeUnit.MINUTES);
        } catch (Exception e) {
            return false;
        } finally {
            pendingPermissions.remove(requestId);
        }
    }

    /** 权限响应（由 ChatService 在用户决策后回调）。 */
    @Override
    public void respondPermission(String requestId, boolean allow, String message) {
        CompletableFuture<Boolean> future = pendingPermissions.remove(requestId);
        if (future != null) future.complete(allow);
    }

    private Path resolveCwd(ChatRequest request) {
        String cwd = request.cwd;
        if (cwd == null || cwd.isBlank()) cwd = settings.cwd;
        if (cwd == null || cwd.isBlank()) cwd = System.getProperty("user.dir");
        try {
            return Path.of(cwd);
        } catch (Exception e) {
            return Path.of(System.getProperty("user.dir"));
        }
    }

    /** 连接测试：发一条极短消息，返回成功提示或失败原因。 */
    public String testConnection() {
        return testConnection(settings.llmBaseUrl, settings.llmApiKey, settings.llmModel);
    }

    /** 连接测试（按指定配置，供设置对话框使用）。 */
    public static String testConnection(String baseUrl, String apiKey, String modelName) {
        if (baseUrl == null || baseUrl.isBlank()
                || apiKey == null || apiKey.isBlank()
                || modelName == null || modelName.isBlank()) {
            return "请先填写接口地址、API Key 和模型名";
        }
        AtomicBoolean ok = new AtomicBoolean(false);
        AtomicReference<String> err = new AtomicReference<>();
        try {
            OpenAiStreamingChatModel.builder()
                    .baseUrl(baseUrl.trim())
                    .apiKey(apiKey.trim())
                    .modelName(modelName.trim())
                    .build()
                    .chat(List.of(UserMessage.from("你好")), new StreamingChatResponseHandler() {
                        @Override
                        public void onPartialResponse(String partialResponse) {
                            ok.set(true);
                        }

                        @Override
                        public void onCompleteResponse(ChatResponse response) {
                            ok.set(true);
                        }

                        @Override
                        public void onError(Throwable error) {
                            err.set(ModelErrorMapper.toUserError(error).getMessage());
                        }
                    });
        } catch (Exception e) {
            err.set(ModelErrorMapper.toUserError(e).getMessage());
        }
        return ok.get() ? "连接成功" : "连接失败：" + (err.get() == null ? "未知错误" : err.get());
    }

    @Override
    public void abort(String conversationId) {
        if (conversationId == null) return;
        // 移除当前代号，后续迟到回调会被忽略
        generations.remove(conversationId);
        Thread worker = running.get(conversationId);
        if (worker != null && worker != Thread.currentThread()) {
            worker.interrupt();
        }
    }

    /** 当前回调是否仍属于有效请求（未被中断且未开始新请求）。 */
    private boolean active(String convId, long gen) {
        return Long.valueOf(gen).equals(generations.get(convId));
    }

    @Override
    public void shutdown() {
    }
}
