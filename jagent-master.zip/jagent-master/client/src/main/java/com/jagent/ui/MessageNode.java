package com.jagent.ui;

import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.ToolCall;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Tooltip;
import javafx.scene.input.Clipboard;
import javafx.scene.input.DataFormat;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.transform.Rotate;

import java.util.HashMap;
import java.util.Map;

/**
 * 单条消息的 UI 节点：
 * 用户消息（右侧气泡）/ 助手消息（左侧头像 + Markdown + 工具卡片）
 *
 * @author azhu
 * @date 2026-10-24
 */
public class MessageNode extends VBox {

    private final ChatMessage message;
    private final VBox assistantContent;
    private Node mdNode;
    private Node placeholder;
    private VBox thinkingCard;
    private Region thinkingChevron;
    private VBox thinkingBody;
    private boolean thinkingExpanded = false;
    private final Map<String, ToolCard> cards = new HashMap<>();

    public MessageNode(ChatMessage message) {
        this.message = message;
        getStyleClass().add("message-node");
        if ("user".equals(message.role)) {
            buildUser();
            assistantContent = null;
        } else {
            assistantContent = buildAssistant();
            // 重开会话时，恢复已持久化的工具调用卡片（数据未丢，仅需重新渲染）
            if (message.toolCalls != null) {
                for (ToolCall tc : message.toolCalls) {
                    ToolCard card = addTool(tc);
                    if (card != null) card.markRestored();
                }
            }
        }
        attachContextMenu();
    }

    private void buildUser() {
        setAlignment(Pos.CENTER_RIGHT);
        TextFlow bubble = new TextFlow();
        bubble.getStyleClass().add("user-bubble");
        bubble.setMaxWidth(560);
        Text text = new Text(message.content == null ? "" : message.content);
        text.getStyleClass().add("user-text");
        text.setLineSpacing(3);
        bubble.getChildren().add(text);

        HBox row = new HBox(8, bubble, copyButton());
        row.setAlignment(Pos.CENTER_LEFT);
        getChildren().add(row);
    }

    private VBox buildAssistant() {
        HBox row = new HBox(10);
        row.setMaxWidth(Double.MAX_VALUE);

        AvatarView avatar = new AvatarView(30);
        avatar.getStyleClass().add("assistant-avatar");

        VBox content = new VBox(8);
        content.getStyleClass().add("assistant-content");
        HBox.setHgrow(content, Priority.ALWAYS);

        row.getChildren().addAll(avatar, content, copyButton());
        getChildren().add(row);
        return content;
    }

    /** 流式/最终刷新文本内容（重新渲染 Markdown） */
    public void refreshText(boolean streaming) {
        if (assistantContent == null) return;

        // 移除旧节点
        if (mdNode != null) {
            assistantContent.getChildren().remove(mdNode);
            mdNode = null;
        }
        if (placeholder != null) {
            assistantContent.getChildren().remove(placeholder);
            placeholder = null;
        }

        String text = message.content == null ? "" : message.content;
        updateThinkingCard(message.thinking == null ? "" : message.thinking);

        if (text.isBlank() && message.toolCalls.isEmpty()) {
            // 思考中占位
            HBox ph = new HBox(6);
            ph.setAlignment(Pos.CENTER_LEFT);
            ProgressIndicator pi = new ProgressIndicator();
            pi.setPrefSize(14, 14);
            pi.setMinSize(14, 14);
            pi.setMaxSize(14, 14);
            Label thinking = new Label(message.error ? "出错了" : "思考中…");
            thinking.getStyleClass().add("thinking-label");
            ph.getChildren().addAll(pi, thinking);
            placeholder = ph;
            assistantContent.getChildren().add(ph);
            return;
        }

        if (!text.isBlank()) {
            mdNode = MarkdownText.render(text, streaming);
            assistantContent.getChildren().add(mdNode);
        }
    }

    /** 追加工具调用卡片 */
    public ToolCard addTool(ToolCall tool) {
        if (assistantContent == null) return null;
        if (placeholder != null) {
            assistantContent.getChildren().remove(placeholder);
            placeholder = null;
        }
        ToolCard card = new ToolCard(tool);
        cards.put(tool.id, card);
        assistantContent.getChildren().add(card);
        return card;
    }

    public void updateTool(ToolCall tool) {
        ToolCard card = cards.get(tool.id);
        if (card != null) card.update(tool);
    }

    // ================= 思考过程（折叠区块） =================

    /** 依据思考内容刷新折叠的「思考过程」区块；为空时移除。 */
    private void updateThinkingCard(String thinking) {
        if (thinking == null || thinking.isBlank()) {
            if (thinkingCard != null) {
                assistantContent.getChildren().remove(thinkingCard);
                thinkingCard = null;
                thinkingBody = null;
                thinkingChevron = null;
                thinkingExpanded = false;
            }
            return;
        }
        if (thinkingCard == null) {
            buildThinkingCard();
            assistantContent.getChildren().add(0, thinkingCard);
        }
        if (thinkingExpanded) {
            renderThinkingBody(thinking);
        }
    }

    private void buildThinkingCard() {
        thinkingCard = new VBox(0);
        thinkingCard.getStyleClass().add("thinking-card");

        HBox header = new HBox(8);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("thinking-header");
        header.setPadding(new Insets(6, 10, 6, 10));

        thinkingChevron = new Region();
        thinkingChevron.getStyleClass().add("tool-chevron");
        thinkingChevron.setPrefSize(14, 14);
        thinkingChevron.setMinSize(14, 14);
        thinkingChevron.setMaxSize(14, 14);
        thinkingChevron.getTransforms().add(new Rotate(0, 7, 7));

        Label title = new Label("思考过程");
        title.getStyleClass().add("thinking-label-title");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(thinkingChevron, title, spacer);
        header.setOnMouseClicked(e -> toggleThinking());

        thinkingBody = new VBox(6);
        thinkingBody.getStyleClass().add("thinking-body");
        thinkingBody.setManaged(false);
        thinkingBody.setVisible(false);
        thinkingBody.setPadding(new Insets(4, 12, 10, 12));

        thinkingCard.getChildren().addAll(header, thinkingBody);
    }

    private void toggleThinking() {
        thinkingExpanded = !thinkingExpanded;
        thinkingBody.setManaged(thinkingExpanded);
        thinkingBody.setVisible(thinkingExpanded);
        ((Rotate) thinkingChevron.getTransforms().get(0)).setAngle(thinkingExpanded ? 180 : 0);
        if (thinkingExpanded) {
            renderThinkingBody(message.thinking == null ? "" : message.thinking);
        }
    }

    private void renderThinkingBody(String thinking) {
        thinkingBody.getChildren().clear();
        if (thinking != null && !thinking.isBlank()) {
            thinkingBody.getChildren().add(MarkdownText.render(thinking, false));
        }
    }

    public ChatMessage getMessage() {
        return message;
    }

    // ================= 复制 =================

    private StackPane copyButton() {
        StackPane btn = new StackPane(Icons.stroke(Icons.COPY, 14, Color.web("#9AA3B2")));
        btn.getStyleClass().add("msg-copy-btn");
        btn.setPrefSize(26, 26);
        btn.setMinSize(26, 26);
        btn.setMaxSize(26, 26);
        Tooltip.install(btn, new Tooltip("复制"));
        btn.setOnMouseClicked(e -> {
            e.consume();
            copyMessage();
        });
        return btn;
    }

    private void copyMessage() {
        Clipboard.getSystemClipboard().setContent(
                Map.of(DataFormat.PLAIN_TEXT, message.content == null ? "" : message.content));
    }

    private void attachContextMenu() {
        MenuItem copy = new MenuItem("复制");
        copy.setOnAction(e -> copyMessage());
        ContextMenu menu = new ContextMenu(copy);
        setOnContextMenuRequested(e -> menu.show(this, e.getScreenX(), e.getScreenY()));
    }
}
