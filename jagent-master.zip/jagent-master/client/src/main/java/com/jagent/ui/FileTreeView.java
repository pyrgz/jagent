package com.jagent.ui;

import com.jagent.workspace.model.FileNode;
import com.jagent.workspace.service.WorkspaceService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;

/**
 * 工作区文件树（懒加载）：目录首次展开时才列出子项。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class FileTreeView {

    private static final FileNode LOADING = new FileNode("…", "", true, 0);

    private final WorkspaceService workspace;
    private final Consumer<String> onOpenFile;

    private final VBox root;
    private final Label rootName;
    private final TreeView<FileNode> tree;

    public FileTreeView(WorkspaceService workspace, Consumer<String> onOpenFile, Runnable onChangeRoot) {
        this.workspace = workspace;
        this.onOpenFile = onOpenFile;

        rootName = new Label("未打开工作区");
        rootName.getStyleClass().add("file-tree-title");

        Button refreshBtn = new Button("刷新");
        refreshBtn.getStyleClass().add("btn-ghost");
        refreshBtn.setOnAction(e -> refresh());

        Button switchBtn = new Button("切换目录");
        switchBtn.getStyleClass().add("btn-ghost");
        switchBtn.setOnAction(e -> { if (onChangeRoot != null) onChangeRoot.run(); });

        HBox header = new HBox(8, rootName, refreshBtn, switchBtn);
        HBox.setHgrow(rootName, Priority.ALWAYS);
        header.setAlignment(Pos.CENTER_LEFT);
        header.getStyleClass().add("file-tree-header");

        tree = new TreeView<>();
        tree.getStyleClass().add("file-tree");
        tree.setShowRoot(true);
        tree.setCellFactory(v -> new FileCell());
        tree.setOnMouseClicked(e -> {
            TreeItem<FileNode> item = tree.getSelectionModel().getSelectedItem();
            if (item != null && item.getValue() != null && !item.getValue().directory) {
                onOpenFile.accept(item.getValue().path);
            }
        });

        root = new VBox(header, tree);
        VBox.setVgrow(tree, Priority.ALWAYS);
        root.getStyleClass().add("sidebar");
        root.setPadding(new Insets(12, 8, 12, 8));
    }

    public Node node() {
        return root;
    }

    /** 重建树，根节点为工作区目录并自动展开第一层。 */
    public void setRoot(Path dir) {
        if (dir == null) {
            return;
        }
        String name = dir.getFileName() == null ? dir.toString() : dir.getFileName().toString();
        rootName.setText(name);
        TreeItem<FileNode> rootItem = createItem(new FileNode(name, dir.toString(), true, 0));
        tree.setRoot(rootItem);
        rootItem.setExpanded(true);
    }

    /** 刷新文件树（重建，根目录展开第一层）。 */
    public void refresh() {
        Path dir = workspace.root();
        if (dir != null) {
            setRoot(dir);
        }
    }

    private TreeItem<FileNode> createItem(FileNode node) {
        TreeItem<FileNode> item = new TreeItem<>(node);
        if (node.directory) {
            item.getChildren().add(new TreeItem<>(LOADING));
            item.expandedProperty().addListener((obs, was, now) -> {
                if (now && hasLoading(item)) {
                    loadChildren(item);
                }
            });
        }
        return item;
    }

    private boolean hasLoading(TreeItem<FileNode> item) {
        return item.getChildren().size() == 1 && item.getChildren().get(0).getValue() == LOADING;
    }

    private void loadChildren(TreeItem<FileNode> item) {
        FileNode node = item.getValue();
        Thread.ofVirtual().name("file-list").start(() -> {
            List<FileNode> children = workspace.listChildren(Path.of(node.path));
            Platform.runLater(() -> {
                item.getChildren().clear();
                for (FileNode c : children) {
                    item.getChildren().add(createItem(c));
                }
            });
        });
    }

    private static class FileCell extends TreeCell<FileNode> {
        @Override
        protected void updateItem(FileNode node, boolean empty) {
            super.updateItem(node, empty);
            if (empty || node == null) {
                setText(null);
                setGraphic(null);
                return;
            }
            setText(node.name);
            String icon = node.directory ? Icons.FOLDER : Icons.FILE;
            setGraphic(Icons.stroke(icon, 15, Color.web("#7C828A")));
        }
    }
}
