package com.jagent.ui;

import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.Conversation;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

import java.util.function.Consumer;

/**
 * 聊天主区域：消息列表 + 空状态欢迎页
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ChatAreaView {

    private final StackPane root;
    private final ScrollPane scroll;
    private final VBox messages;
    private final VBox emptyState;
    private MessageNode lastNode;

    public ChatAreaView(Consumer<String> onSuggest) {
        messages = new VBox(20);
        messages.getStyleClass().add("messages");
        messages.setMaxWidth(840);
        messages.setPadding(new Insets(22, 18, 26, 18));

        StackPane center = new StackPane(messages);
        center.setAlignment(Pos.TOP_CENTER);
        center.setPadding(new Insets(0, 8, 0, 8));

        scroll = new ScrollPane(center);
        scroll.getStyleClass().add("chat-scroll");
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        VBox.setVgrow(scroll, Priority.ALWAYS);

        emptyState = buildEmptyState(onSuggest);

        root = new StackPane(scroll, emptyState);

        // 内容增高时自动滚动（仅当用户本来就在底部附近）
        messages.heightProperty().addListener((obs, o, n) -> {
            if (isNearBottom()) {
                Platform.runLater(() -> scroll.setVvalue(1.0));
            }
        });
    }

    public Node node() {
        return root;
    }

    public void showEmpty(boolean b) {
        emptyState.setVisible(b);
        emptyState.setManaged(b);
    }

    public void clear() {
        messages.getChildren().clear();
        lastNode = null;
    }

    /** 渲染完整会话 */
    public void render(Conversation c) {
        clear();
        showEmpty(c.messages.isEmpty());
        for (ChatMessage m : c.messages) {
            append(m);
        }
        scrollToBottom();
    }

    public MessageNode append(ChatMessage msg) {
        MessageNode node = new MessageNode(msg);
        if (!"user".equals(msg.role)) {
            node.refreshText(true);
        }
        messages.getChildren().add(node);
        lastNode = node;
        showEmpty(false);
        scrollToBottom();
        return node;
    }

    public MessageNode getLastNode() {
        return lastNode;
    }

    public void scrollToBottom() {
        Platform.runLater(() -> scroll.setVvalue(1.0));
    }

    private boolean isNearBottom() {
        double contentH = scroll.getContent() == null ? 0 : scroll.getContent().getBoundsInLocal().getHeight();
        double viewH = scroll.getViewportBounds() == null ? 0 : scroll.getViewportBounds().getHeight();
        return contentH <= viewH + 12 || scroll.getVvalue() >= 0.9;
    }

    // ---------------- 空状态欢迎页 ----------------

    private VBox buildEmptyState(Consumer<String> onSuggest) {
        VBox box = new VBox(10);
        box.setAlignment(Pos.CENTER);
        box.getStyleClass().add("empty-state");
        box.setPadding(new Insets(30, 40, 40, 40));
        box.setMaxWidth(640);

        // Logo
        StackPane logo = new StackPane();
        logo.setPrefSize(84, 84);
        logo.setMinSize(84, 84);
        logo.setMaxSize(84, 84);
        logo.getStyleClass().add("empty-logo");
        logo.getChildren().add(Icons.fill(Icons.SPARK, 44, javafx.scene.paint.Color.WHITE));

        Label title = new Label("你好，我是 jagent Agent");
        title.getStyleClass().add("empty-title");

        Label subtitle = new Label("基于 jagent Agent SDK 客户端，支持流式输出与工具调用");
        subtitle.getStyleClass().add("empty-subtitle");

        FlowPane chips = new FlowPane();
        chips.setAlignment(Pos.CENTER);
        chips.setHgap(10);
        chips.setVgap(10);
        chips.setPadding(new Insets(16, 0, 0, 0));
        String[] suggestions = {
                "用 Java 写一个生产者-消费者示例",
                "解释一下 MCP 协议的工作原理",
                "帮我创建一个 README 模板",
                "写一个函数计算斐波那契数列",
                "什么是 Agent？它和普通 Chatbot 有什么区别？",
        };
        for (String s : suggestions) {
            HBox chip = new HBox(7);
            chip.getStyleClass().add("chip");
            chip.setAlignment(Pos.CENTER);
            chip.setPadding(new Insets(8, 14, 8, 14));
            chip.getChildren().addAll(
                    Icons.stroke(Icons.ARROW_RIGHT, 13, javafx.scene.paint.Color.web("#0052D9")),
                    new Label(s));
            chip.setOnMouseClicked(e -> {
                if (onSuggest != null) onSuggest.accept(s);
            });
            chips.getChildren().add(chip);
        }

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        Region spacer2 = new Region();
        VBox.setVgrow(spacer2, Priority.ALWAYS);

        box.getChildren().addAll(spacer, logo, title, subtitle, chips, spacer2);
        return box;
    }
}
