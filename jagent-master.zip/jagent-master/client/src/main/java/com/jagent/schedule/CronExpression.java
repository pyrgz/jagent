package com.jagent.schedule;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

/**
 * 标准 5 段 cron 表达式（分 时 日 月 周）：解析、中文描述与下次执行时间计算。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class CronExpression {

    private static final String[] MONTHS = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN",
            "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
    private static final String[] DAYS = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};

    public final String minute;
    public final String hour;
    public final String dayOfMonth;
    public final String month;
    public final String dayOfWeek;

    public CronExpression(String minute, String hour, String dayOfMonth, String month, String dayOfWeek) {
        this.minute = norm(minute);
        this.hour = norm(hour);
        this.dayOfMonth = norm(dayOfMonth);
        this.month = norm(month);
        this.dayOfWeek = norm(dayOfWeek);
    }

    public static CronExpression parse(String expr) {
        if (expr == null) throw new IllegalArgumentException("cron 为空");
        String[] parts = expr.trim().split("\\s+");
        if (parts.length != 5) throw new IllegalArgumentException("cron 必须为 5 段");
        return new CronExpression(parts[0], parts[1], parts[2], parts[3], parts[4]);
    }

    public String expression() {
        return minute + " " + hour + " " + dayOfMonth + " " + month + " " + dayOfWeek;
    }

    /** 从 after 的下一分钟开始逐分钟查找，上限 366 天；找不到返回 null。 */
    public ZonedDateTime next(ZonedDateTime after) {
        ZonedDateTime t = after.truncatedTo(ChronoUnit.MINUTES).plusMinutes(1);
        ZonedDateTime limit = t.plusDays(366);
        while (t.isBefore(limit)) {
            int dow = t.getDayOfWeek().getValue() % 7; // 周一=1…周日=7 → 0=周日
            if (matches(minute, t.getMinute(), 0, 59, null)
                    && matches(hour, t.getHour(), 0, 23, null)
                    && matches(dayOfMonth, t.getDayOfMonth(), 1, 31, null)
                    && matches(month, t.getMonthValue(), 1, 12, MONTHS)
                    && (matches(dayOfWeek, dow, 0, 6, DAYS)
                        || (dow == 0 && matches(dayOfWeek, 7, 0, 6, DAYS)))) {
                return t;
            }
            t = t.plusMinutes(1);
        }
        return null;
    }

    /** 尽力中文描述，无法识别时回退为原始表达式。 */
    public String describe() {
        try {
            if (minute.startsWith("*/")) {
                return "每 " + minute.substring(2) + " 分钟";
            }
            if ("*".equals(minute) && "*".equals(hour)) return "每分钟";
            if ("*".equals(hour)) return "每小时第 " + minute + " 分钟";

            String hm = pad(hour) + ":" + pad(minute);
            if (!"*".equals(dayOfWeek)) {
                return "每周" + dowName(dayOfWeek) + " " + hm;
            }
            if (!"*".equals(dayOfMonth)) {
                return "每月 " + dayOfMonth + " 日 " + hm;
            }
            return "每天 " + hm;
        } catch (Exception e) {
            return expression();
        }
    }

    private static boolean matches(String field, int value, int min, int max, String[] names) {
        if (field == null || field.isBlank()) return false;
        for (String part : field.split(",")) {
            part = part.trim();
            if (part.isEmpty()) continue;
            int step = 1;
            String base = part;
            int slash = part.indexOf('/');
            if (slash >= 0) {
                base = part.substring(0, slash);
                step = parseInt(part.substring(slash + 1), 1);
                if (step <= 0) step = 1;
            }
            int start, end;
            if ("*".equals(base)) {
                start = min;
                end = max;
            } else {
                int dash = base.indexOf('-');
                if (dash >= 0) {
                    start = parseVal(base.substring(0, dash), names, min, max);
                    end = parseVal(base.substring(dash + 1), names, min, max);
                } else {
                    start = end = parseVal(base, names, min, max);
                }
            }
            if (end < start) {
                int tmp = start;
                start = end;
                end = tmp;
            }
            for (int v = start; v <= end; v += step) {
                if (v == value) return true;
            }
        }
        return false;
    }

    private static int parseVal(String s, String[] names, int min, int max) {
        String t = s.trim();
        if (names != null) {
            String upper = t.toUpperCase();
            for (int i = 0; i < names.length; i++) {
                if (names[i].equals(upper)) return min + i;
            }
        }
        return parseInt(t, min);
    }

    private static String norm(String s) {
        return s == null || s.isBlank() ? "*" : s.trim();
    }

    private static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private static String pad(String s) {
        if (s.length() == 1 && Character.isDigit(s.charAt(0))) return "0" + s;
        return s;
    }

    private static String dowName(String f) {
        switch (f.trim()) {
            case "0":
            case "7":
                return "日";
            case "1":
                return "一";
            case "2":
                return "二";
            case "3":
                return "三";
            case "4":
                return "四";
            case "5":
                return "五";
            case "6":
                return "六";
            case "1-5":
                return "一至五（工作日）";
            default:
                return f;
        }
    }
}
