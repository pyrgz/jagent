

package com.jagent.knowledge.service;

import java.util.List;

/**
 * 知识库向量存储抽象：以 {@code kbId} 为命名空间，负责分块向量的写入、删除、清空与检索。
 *
 * <p>接口用语言中性的 {@code float[]} 表示向量，不暴露任何 langchain4j 存储类型，
 * 以便未来替换为 Elasticsearch / 数据库等实现（实现本接口即可，上层零改动）。</p>
 *      服务         │             嵌入接口地址             │       嵌入模型名       │
 *   ├──────────────────────┼──────────────────────────────────────┼────────────────────────┤
 *   │ OpenAI               │ https://api.openai.com/v1            │ text-embedding-3-small │
 *   ├──────────────────────┼──────────────────────────────────────┼────────────────────────┤
 *   │ 硅基流动 SiliconFlow │ https://api.siliconflow.cn/v1        │ BAAI/bge-m3            │
 *   ├──────────────────────┼──────────────────────────────────────┼────────────────────────┤
 *   │ 智谱                 │ https://open.bigmodel.cn/api/paas/v4 │ embedding-2
 *
 * @author azhu
 * @date 2026-10-24
 */
public interface KnowledgeStore {

    /** 一个已向量化的文本分块 */
    final class Chunk {
        public final String text;
        public final float[] vector;

        public Chunk(String text, float[] vector) {
            this.text = text;
            this.vector = vector;
        }
    }

    /** 检索命中结果 */
    final class SearchHit {
        public final String docId;
        public final String text;
        public final double score;

        public SearchHit(String docId, String text, double score) {
            this.docId = docId;
            this.text = text;
            this.score = score;
        }
    }

    /** 为指定知识库追加一批分块（docId 归属该文档）。 */
    void addChunks(String kbId, String docId, List<Chunk> chunks);

    /** 删除知识库内单个文档的全部分块。 */
    void removeDocument(String kbId, String docId);

    /** 清空某知识库的全部分块（保留库）。 */
    void clearBase(String kbId);

    /** 删除某知识库全部向量数据与本地文件。 */
    void deleteBase(String kbId);

    /** 在某知识库内向量检索 topK 条；无结果返回空列表。 */
    List<SearchHit> search(String kbId, float[] queryVector, int topK);
}
