package com.jagent.skill.model;

/**
 * 技能（Claude/CodeBuddy 技能：一个目录内含 SKILL.md，可附带脚本）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class Skill {
    /** 技能名（来自 frontmatter 的 name，缺失时回退到目录名） */
    public String name = "";
    /** 技能描述（来自 frontmatter 的 description） */
    public String description = "";
    /** 技能目录的绝对路径 */
    public String path = "";
    /** SKILL.md 正文（去除 frontmatter 后的 markdown 指令） */
    public String content = "";
    /** 来源：user（用户级） | project（项目级） */
    public String source = "user";
    /** 目录内是否包含脚本等非 SKILL.md 文件 */
    public boolean hasScripts = false;
    /** 是否已加载（其指令注入系统提示词）。运行时由 SkillService 填充，不持久化。 */
    public transient boolean loaded = false;
}
