package com.jagent.harness.checkpoint;

import com.jagent.harness.verify.VerifyDef;

import java.util.ArrayList;
import java.util.List;

/**
 * 一次 Harness 编排运行的 checkpoint。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class RunState {

    public String runId;
    public String pipeline;
    public String name;
    /** 本次运行的命令参数 */
    public String invocationInput = "";
    public boolean chain;

    /** running | ok | error */
    public String status = "running";
    /** passed | failed | null（未配置验收） */
    public String verification;

    public String startedAt;
    public String updatedAt;

    public List<StepState> steps = new ArrayList<>();
    public List<VerifyDef> verify = new ArrayList<>();
}
