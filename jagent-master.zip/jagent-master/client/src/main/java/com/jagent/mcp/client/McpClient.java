package com.jagent.mcp.client;

import com.jagent.mcp.model.McpToolDef;

import java.util.List;

/**
 * MCP 客户端抽象：stdio 本地进程与 Streamable HTTP 两种实现。
 *
 * @author azhu
 * @date 2026-10-24
 */
public interface McpClient extends AutoCloseable {

    /** 握手并声明客户端能力。 */
    void initialize() throws Exception;

    /** 获取服务端暴露的全部工具（自动处理分页）。 */
    List<McpToolDef> listTools() throws Exception;

    /** 调用工具，返回 tools/call 的 result 对象。 */
    com.google.gson.JsonObject callTool(String name, com.google.gson.JsonObject arguments) throws Exception;

    /** 服务端标识（serverInfo.name/version），用于日志。 */
    String serverInfo();

    @Override
    void close();
}
