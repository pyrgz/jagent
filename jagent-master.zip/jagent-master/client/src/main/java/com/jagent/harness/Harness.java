package com.jagent.harness;

/**
 * 业务 harness 抽象：每个业务模块（chat / knowledge / schedule / skill / workspace /
 * settings / connectivity）实现本接口，交由 {@link HarnessRegistry} 统一管理生命周期。
 *
 * <p>纯 Java，无 JavaFX 依赖，可被 headless 脚本直接调用。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public interface Harness {

    /** 唯一标识，如 "chat" / "knowledge" / "schedule"。 */
    String id();

    /** 显示名，如 "聊天" / "知识库"。 */
    String name();

    /** 初始化/启动（对应现有 bootstrap），默认空实现。 */
    default void initialize() {}

    /** 关闭/清理（对应现有 shutdown），默认空实现。 */
    default void shutdown() {}

    /**
     * 执行一次业务动作，供对话框命令 {@code /harness <id> <入参>} 调用。
     * 默认不支持；需要支持命令执行的 harness 重写此方法。
     *
     * @param input 命令参数（可能为空）
     * @return 展示到对话中的执行结果
     */
    default String execute(String input) throws Exception {
        return name() + "（" + id() + "）不支持 /harness 执行";
    }
}
