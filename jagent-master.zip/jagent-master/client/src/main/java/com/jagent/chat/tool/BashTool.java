package com.jagent.chat.tool;

import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;

import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

/**
 * 在工作目录中执行 shell 命令。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class BashTool extends BaseTool {

    private static final long TIMEOUT_SECONDS = 60;
    private static final int MAX_OUTPUT = 100_000;

    public BashTool(Path root) {
        super(root);
    }

    @Override
    public ToolSpecification specification() {
        return ToolSpecification.builder()
                .name("Bash")
                .description("在工作目录中执行一条 shell 命令，返回标准输出与错误（合并）。")
                .parameters(JsonObjectSchema.builder()
                        .addStringProperty("command", "要执行的 shell 命令")
                        .required("command")
                        .build())
                .build();
    }

    @Override
    public String execute(String argumentsJson) throws Exception {
        String command = arg(args(argumentsJson), "command");
        if (command == null || command.isBlank()) return "错误：缺少 command 参数";

        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        ProcessBuilder pb = new ProcessBuilder(
                windows ? new String[]{"cmd", "/c", command} : new String[]{"sh", "-c", command});
        pb.directory(root.toFile());
        pb.redirectErrorStream(true);

        Process proc = pb.start();
        // 在虚拟线程中读取输出，避免命令 hang 住时永久阻塞
        Process running = proc;
        java.util.concurrent.CompletableFuture<String> output = new java.util.concurrent.CompletableFuture<>();
        Thread.ofVirtual().name("bash-reader").start(() -> {
            try {
                output.complete(new String(running.getInputStream().readAllBytes(), StandardCharsets.UTF_8));
            } catch (Exception e) {
                output.completeExceptionally(e);
            }
        });

        boolean timeout = !proc.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        if (timeout) proc.destroyForcibly();

        String out;
        try {
            out = output.get(2, TimeUnit.SECONDS);
        } catch (Exception e) {
            out = "";
        }
        if (timeout) out += "\n[命令超时，已强制终止]";
        if (out.length() > MAX_OUTPUT) out = out.substring(0, MAX_OUTPUT) + "\n…（已截断）";
        int code = proc.isAlive() ? -1 : proc.exitValue();
        return (code == 0 ? "" : "退出码 " + code + "\n") + out;
    }

    @Override
    public boolean requiresPermission() {
        return true;
    }
}
