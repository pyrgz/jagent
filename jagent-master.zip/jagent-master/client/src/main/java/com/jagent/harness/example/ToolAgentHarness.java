package com.jagent.harness.example;

import com.jagent.chat.model.ChatRequest;
import com.jagent.chat.service.ChatBackend;
import com.jagent.chat.service.Langchain4jBackend;
import com.jagent.harness.Harness;
import com.jagent.harness.permission.HarnessPermissionPolicy;
import com.jagent.settings.service.SettingsService;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 实用 Harness 示例：让大模型在 Harness 中调用「内置工具 + MCP 工具」完成任务。
 *
 * <p>执行链路：</p>
 * <pre>
 * /harness agent &lt;任务&gt;
 *   → Langchain4jBackend 发起模型请求（携带 Read/Glob/Grep + MCP 工具定义）
 *   → 模型返回 tool_calls
 *   → Harness 自动审批只读工具 / MCP 工具（写操作自动拒绝）
 *   → 工具结果回传模型，循环直到给出最终回答
 * </pre>
 *
 * <p>示例：{@code /harness agent 现在几点？顺便统计工作目录里有多少个 Java 文件}。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ToolAgentHarness implements Harness {

    private static final long TIMEOUT_MINUTES = 5;

    private final Langchain4jBackend backend;
    private final SettingsService settings;

    public ToolAgentHarness(Langchain4jBackend backend, SettingsService settings) {
        this.backend = backend;
        this.settings = settings;
    }

    @Override
    public String id() {
        return "agent";
    }

    @Override
    public String name() {
        return "工具 Agent";
    }

    @Override
    public String execute(String input) throws Exception {
        if (input == null || input.isBlank()) {
            return usage();
        }
        if (!backend.isAvailable()) {
            return "模型直连未配置，请先在设置中填写接口地址、API Key 和模型名。";
        }

        // 可选开关：--allow-network 允许 curl/wget 发起 GET 请求
        boolean allowNetwork = false;
        String task = input.trim();
        while (task.startsWith("--")) {
            int end = task.indexOf(' ');
            String flag = end < 0 ? task : task.substring(0, end);
            if (!"--allow-network".equals(flag)) break;
            allowNetwork = true;
            task = end < 0 ? "" : task.substring(end + 1).trim();
        }
        if (task.isEmpty()) {
            return usage();
        }
        final boolean networkAllowed = allowNetwork;

        ChatRequest request = new ChatRequest();
        request.conversationId = "harness-agent-" + UUID.randomUUID();
        request.message = task;
        request.model = settings.settings().llmModel;
        request.cwd = settings.settings().cwd;
        request.permissionMode = "default";
        request.systemPromptAppend = "你是运行在 jagent Harness 中的工具型助手。"
                + "可以使用内置工具（Read/Glob/Grep）和 MCP 工具完成任务；"
                + "需要事实时先调用工具，不要编造；最终用中文简洁回答。";
        request.history = new ArrayList<>();

        CountDownLatch done = new CountDownLatch(1);
        StringBuilder answer = new StringBuilder();
        List<String> trace = new CopyOnWriteArrayList<>();
        AtomicReference<String> error = new AtomicReference<>();

        backend.chat(request, new ChatBackend.StreamListener() {
            @Override
            public void onText(String content) {
                if (content != null) answer.append(content);
            }

            @Override
            public void onTool(String id, String name, String inputJson) {
                trace.add("调用 " + name + " " + abbreviate(inputJson, 200));
            }

            @Override
            public void onPermissionRequest(String requestId, String toolName, String inputJson) {
                boolean allow = HarnessPermissionPolicy.permitted(toolName, inputJson, networkAllowed);
                trace.add("权限 " + toolName + " → " + (allow ? "自动允许" : "自动拒绝"));
                Thread.ofVirtual().name("harness-permission").start(() ->
                        backend.respondPermission(requestId, allow,
                                allow ? null : "Harness 权限策略拒绝：仅允许只读工具/MCP 工具"
                                        + "，只读 Bash 默认允许，联网需 --allow-network"));
            }

            @Override
            public void onDone(JsonObject data) {
                done.countDown();
            }

            @Override
            public void onError(String code, String message) {
                error.set(message);
                done.countDown();
            }
        });

        if (!done.await(TIMEOUT_MINUTES, TimeUnit.MINUTES)) {
            return "Agent 执行超时（" + TIMEOUT_MINUTES + " 分钟）。";
        }
        if (error.get() != null) {
            return "Agent 执行失败：" + error.get();
        }

        StringBuilder report = new StringBuilder();
        if (!trace.isEmpty()) {
            report.append("工具调用（").append(trace.size()).append("）：\n");
            for (int i = 0; i < trace.size(); i++) {
                report.append(i + 1).append(". ").append(trace.get(i)).append('\n');
            }
            report.append('\n');
        }
        String text = answer.toString().trim();
        report.append(text.isEmpty() ? "（模型没有返回内容）" : text);
        return report.toString().trim();
    }

    private static String usage() {
        return "用法：/harness agent [--allow-network] <任务>\n"
                + "示例：/harness agent 现在几点？顺便统计工作目录里有多少个 Java 文件\n"
                + "      /harness agent --allow-network 查询今天的金价并分析\n"
                + "\n权限策略：只读工具/MCP 工具默认允许；只读 Bash（pwd/ls/date/git status 等）默认允许；"
                + "联网 curl/wget 需显式 --allow-network；写操作始终拒绝。";
    }

    private static String abbreviate(String text, int limit) {
        if (text == null) return "";
        String flat = text.replace("\n", " ");
        return flat.length() <= limit ? flat : flat.substring(0, limit) + "…";
    }
}
