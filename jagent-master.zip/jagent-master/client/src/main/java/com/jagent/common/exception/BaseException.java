package com.jagent.common.exception;

/**
 * 公共异常基类：所有业务/系统异常的根，带可选错误码。
 * 采用非受检异常（{@link RuntimeException}），避免各层方法签名污染。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class BaseException extends RuntimeException {

    private final String code;

    public BaseException(String message) {
        super(message);
        this.code = null;
    }

    public BaseException(String code, String message) {
        super(message);
        this.code = code;
    }

    public BaseException(String message, Throwable cause) {
        super(message, cause);
        this.code = null;
    }

    public BaseException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    /** 错误码，可为 null。 */
    public String getCode() {
        return code;
    }
}
