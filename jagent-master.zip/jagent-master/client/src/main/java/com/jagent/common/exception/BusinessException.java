package com.jagent.common.exception;

/**
 * 业务异常：表示可预期的业务错误（参数非法、业务规则不满足、配置缺失等），
 * 通常用户可理解并可恢复。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class BusinessException extends BaseException {

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String code, String message) {
        super(code, message);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
