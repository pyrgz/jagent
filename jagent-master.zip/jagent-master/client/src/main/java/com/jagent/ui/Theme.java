package com.jagent.ui;

import javafx.scene.Scene;

import java.net.URL;
import java.util.List;
import java.util.Map;

/**
 * 界面主题：维护当前主题，并通过加载 / 重载 themes/*.css 切换。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class Theme {

    public static final List<String> ALL = List.of("light", "dark", "blue", "green", "purple");

    private static final Map<String, String> NAMES = Map.of(
            "light", "浅色",
            "dark", "深色",
            "blue", "蓝色",
            "green", "绿色",
            "purple", "紫色");

    private static final String BASE_CSS = "/css/app.css";
    private static final String THEME_CSS_FORMAT = "/css/themes/%s.css";

    private static volatile String current = "light";

    private Theme() {}

    public static String current() {
        return current;
    }

    public static void setCurrent(String key) {
        current = normalize(key);
    }

    public static String displayName(String key) {
        return NAMES.getOrDefault(normalize(key), "浅色");
    }

    /** 返回 key 的下一个主题（用于快捷切换按钮循环切换）。 */
    public static String next(String key) {
        int i = ALL.indexOf(normalize(key));
        if (i < 0) i = 0;
        return ALL.get((i + 1) % ALL.size());
    }

    private static String normalize(String key) {
        return (key == null || key.isBlank() || !ALL.contains(key)) ? "light" : key;
    }

    /** 给 scene 应用基础样式 + 当前主题（主窗口与各对话框共用）。 */
    public static void applyTo(Scene scene) {
        applyTo(scene, current);
    }

    /** 给 scene 应用基础样式 + 指定主题；会先移除旧主题文件实现"重新加载"。 */
    public static void applyTo(Scene scene, String key) {
        if (scene == null) return;
        String k = normalize(key);
        scene.getStylesheets().removeIf(Theme::isThemeCss);
        addStylesheet(scene, BASE_CSS);
        addStylesheet(scene, String.format(THEME_CSS_FORMAT, k));
    }

    /** 切换主题后重载当前主题样式（主场景调用）。 */
    public static void reload(Scene scene) {
        applyTo(scene, current);
    }

    private static boolean isThemeCss(String url) {
        return url != null && url.contains("/css/themes/");
    }

    private static void addStylesheet(Scene scene, String resource) {
        URL url = Theme.class.getResource(resource);
        if (url == null) return;
        String ext = url.toExternalForm();
        if (!scene.getStylesheets().contains(ext)) {
            scene.getStylesheets().add(ext);
        }
    }
}
