package com.jagent.chat.model;

/**
 * 模型信息
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ModelInfo {
    public String modelId;
    public String name;

    public ModelInfo() {}

    public ModelInfo(String modelId, String name) {
        this.modelId = modelId;
        this.name = name;
    }

    @Override
    public String toString() {
        return name != null && !name.isBlank() ? name : modelId;
    }
}
