package com.jagent.example;

import com.jagent.ServiceAssembler;
import com.jagent.chat.model.ChatMessage;
import com.jagent.chat.model.Conversation;
import com.jagent.chat.model.ToolCall;
import com.jagent.chat.service.ChatService;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;

/**
 * 完整的 headless Agent 示例：演示如何用 service 层编程式驱动一个带工具调用的 agent。
 *
 * <p>流程：
 * <ol>
 *   <li>复用 {@link ServiceAssembler} 组装 service（与 GUI 同一套 wiring）；</li>
 *   <li>切换到 langchain4j 后端（OpenAI 兼容 + Read/Write/Bash/Glob/Grep 工具）；</li>
 *   <li>注册 {@link ChatService.Listener}，打印流式事件（工具调用 / 结果 / 最终回答）；</li>
 *   <li>发送一个多步骤任务，等待完成并打印结果；</li>
 *   <li>关闭 harness，持久化数据。</li>
 * </ol>
 *
 * <p>运行（在 {@code client/} 目录，先 {@code mvn -o compile}）：
 * <pre>
 *   java -cp "target/classes:$(find lib -name '*.jar' ! -name '*javafx*' | tr '\n' ':')" \
 *        com.codebuddy.agent.example.AgentExample [可选的自定义任务]
 * </pre>
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class AgentExample {

    /** 默认演示任务：覆盖 Glob / Read / Grep / Write / Bash 五种工具。 */
    private static final String DEFAULT_TASK =
            "帮我做一个完整的演示："
            + "1) 用 Glob 找出当前工作目录下所有 .java 文件并统计数量；"
            + "2) 用 Read 读取 CLAUDE.md（如果存在）了解项目；"
            + "3) 用 Grep 统计代码里 'TODO' 出现的次数；"
            + "4) 把以上统计结果写成一份 Markdown 报告保存到 target/agent-report.md；"
            + "5) 用 Bash 验证报告文件已生成。"
            + "最后用一句话总结统计结果。";

    private static final long TIMEOUT_SECONDS = 300;

    private AgentExample() {}

    public static void main(String[] args) throws Exception {
        // 1. 组装 service（与 GUI 相同的组合根）
        ServiceAssembler.Services services = ServiceAssembler.assemble();

        // 2. 确保使用 langchain4j 后端（含工具调用；provider 默认即为 langchain4j）
        if (!services.langchain4j.isAvailable()) {
            System.err.println("langchain4j 未配置：请在 data/settings.json 中填写 llmBaseUrl/llmApiKey/llmModel。");
            return;
        }
        services.chat.setBackend(services.langchain4j);

        String task = args.length > 0 && !args[0].isBlank() ? args[0] : DEFAULT_TASK;
        printHeader(services, task);

        // 3. 注册监听器，打印事件
        CountDownLatch done = new CountDownLatch(1);
        StringBuilder thinking = new StringBuilder();
        services.chat.setListener(new ChatService.Listener() {
            @Override
            public void onToolAdded(Conversation conv, ChatMessage msg, ToolCall tool) {
                System.out.println("\n[工具] " + tool.name + "  " + pretty(tool.inputJson));
            }

            @Override
            public void onToolUpdated(Conversation conv, ChatMessage msg, ToolCall tool) {
                if (tool.result != null && !tool.result.isBlank()) {
                    System.out.println("[结果" + ("error".equals(tool.status) ? "·失败" : "") + "] "
                            + truncate(tool.result, 400));
                }
            }

            @Override
            public void onTextUpdated(Conversation conv, ChatMessage msg) {
                if (msg.thinking != null && !msg.thinking.isBlank()) {
                    thinking.setLength(0);
                    thinking.append(msg.thinking);
                }
            }

            @Override
            public void onFinished(Conversation conv, ChatMessage msg) {
                printFinal(thinking.toString(), msg.content);
                done.countDown();
            }

            @Override
            public void onPermissionRequest(String requestId, String toolName, String inputJson,
                                            BiConsumer<String, Boolean> responder) {
                System.out.println("[授权] " + toolName + " — 自动允许（headless 无交互）");
                responder.accept(toolName, true);
            }
        });

        // 4. 发送任务（bypassPermissions 让 Bash/Write 免弹窗直接执行）
        System.out.println("[发送] " + task + "\n");
        services.chat.send(task, "bypassPermissions");

        // 5. 等待完成
        if (!done.await(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
            System.err.println("任务超时（" + TIMEOUT_SECONDS + " 秒）未完成。");
        }

        // 6. 关闭（逆序关闭 harness，最后持久化数据）
        services.harnesses.shutdownAll();
    }

    // ================= 打印辅助 =================

    private static void printHeader(ServiceAssembler.Services services, String task) {
        var s = services.settings.settings();
        System.out.println("==============================================");
        System.out.println(" headless Agent 示例");
        System.out.println("==============================================");
        System.out.println("后端    : langchain4j");
        System.out.println("模型    : " + s.llmModel + " @ " + s.llmBaseUrl);
        System.out.println("工作目录: " + (s.cwd == null || s.cwd.isBlank() ? "(默认)" : s.cwd));
        System.out.println("----------------------------------------------");
    }

    private static void printFinal(String thinking, String content) {
        System.out.println("\n----------------------------------------------");
        if (thinking != null && !thinking.isBlank()) {
            System.out.println("[思考过程]");
            System.out.println(truncate(thinking, 1000));
            System.out.println();
        }
        System.out.println("[最终回答]");
        System.out.println(content == null ? "(空)" : content);
        System.out.println("==============================================");
    }

    private static String pretty(String json) {
        if (json == null || json.isBlank()) return "{}";
        try {
            return new com.google.gson.GsonBuilder().setPrettyPrinting().create()
                    .toJson(com.google.gson.JsonParser.parseString(json));
        } catch (Exception e) {
            return json;
        }
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…（已截断）";
    }
}
