package com.jagent.chat.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 会话（对话）
 *
 * @author azhu
 * @date 2026-10-24
 */
public class Conversation {
    public String id;
    public String title = "新会话";
    public String model = "";
    /** Agent SDK 会话 ID，用于恢复上下文 */
    public String sdkSessionId;
    /** 本会话使用的技能路径；为空表示不使用技能 */
    public String skillPath;
    public long createdAt = System.currentTimeMillis();
    public long updatedAt = System.currentTimeMillis();
    public List<ChatMessage> messages = new ArrayList<>();
    /** 消息是否已从独立文件加载（仅内存状态，不持久化） */
    public transient boolean messagesLoaded = true;
}
