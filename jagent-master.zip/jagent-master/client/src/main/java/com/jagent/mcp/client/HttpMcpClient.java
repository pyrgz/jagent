package com.jagent.mcp.client;

import com.jagent.mcp.model.McpServerConfig;
import com.jagent.mcp.model.McpToolDef;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Streamable HTTP 传输的 MCP 客户端：POST JSON-RPC，响应支持 application/json 与 text/event-stream。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class HttpMcpClient implements McpClient {

    private static final Logger log = LogManager.getLogger(HttpMcpClient.class);

    private final String name;
    private final String url;
    private final Map<String, String> headers;
    private final long timeoutSeconds;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();
    private final AtomicLong ids = new AtomicLong();

    private volatile String sessionId;
    private volatile String serverInfo = "";

    public HttpMcpClient(String name, McpServerConfig config) {
        this.name = name;
        this.url = config.url;
        this.headers = config.headers == null ? Map.of() : config.headers;
        this.timeoutSeconds = config.timeoutSeconds > 0 ? config.timeoutSeconds : 60;
    }

    @Override
    public void initialize() throws Exception {
        JsonObject result = request("initialize", JsonRpc.initializeParams());
        if (result.has("serverInfo") && result.get("serverInfo").isJsonObject()) {
            JsonObject info = result.getAsJsonObject("serverInfo");
            String n = str(info, "name");
            String v = str(info, "version");
            serverInfo = (n == null || n.isBlank() ? name : n) + (v == null || v.isBlank() ? "" : " " + v);
        } else {
            serverInfo = name;
        }
        sendNotification("notifications/initialized", null);
        log.info("MCP[{}] 初始化完成：{}", name, serverInfo);
    }

    @Override
    public List<McpToolDef> listTools() throws Exception {
        List<McpToolDef> tools = new ArrayList<>();
        String cursor = null;
        do {
            JsonObject params = new JsonObject();
            if (cursor != null && !cursor.isBlank()) params.addProperty("cursor", cursor);
            JsonObject result = request("tools/list", params);
            JsonArray arr = result.has("tools") && result.get("tools").isJsonArray()
                    ? result.getAsJsonArray("tools") : new JsonArray();
            for (JsonElement el : arr) {
                if (!el.isJsonObject()) continue;
                JsonObject tool = el.getAsJsonObject();
                String toolName = str(tool, "name");
                if (toolName == null || toolName.isBlank()) continue;
                JsonObject schema = tool.has("inputSchema") && tool.get("inputSchema").isJsonObject()
                        ? tool.getAsJsonObject("inputSchema") : new JsonObject();
                tools.add(new McpToolDef(toolName, str(tool, "description"), schema));
            }
            cursor = str(result, "nextCursor");
        } while (cursor != null && !cursor.isBlank());
        return tools;
    }

    @Override
    public JsonObject callTool(String toolName, JsonObject arguments) throws Exception {
        JsonObject params = new JsonObject();
        params.addProperty("name", toolName);
        params.add("arguments", arguments == null ? new JsonObject() : arguments);
        return request("tools/call", params);
    }

    @Override
    public String serverInfo() {
        return serverInfo == null || serverInfo.isBlank() ? name : serverInfo;
    }

    @Override
    public void close() {
        String sid = sessionId;
        if (sid == null || sid.isBlank()) return;
        sessionId = null;
        try {
            HttpRequest req = requestBuilder()
                    .header("Mcp-Session-Id", sid)
                    .timeout(Duration.ofSeconds(5))
                    .DELETE()
                    .build();
            http.send(req, HttpResponse.BodyHandlers.discarding());
        } catch (Exception ignored) {
        }
    }

    // ---- internals ----

    private JsonObject request(String method, JsonObject params) throws Exception {
        long id = ids.incrementAndGet();
        return exchange(JsonRpc.request(id, method, params), id, true);
    }

    private void sendNotification(String method, JsonObject params) throws Exception {
        exchange(JsonRpc.notification(method, params), -1, false);
    }

    private JsonObject exchange(JsonObject body, long id, boolean expectResponse) throws Exception {
        HttpRequest request = requestBuilder()
                .header("Content-Type", "application/json")
                .header("Accept", "application/json, text/event-stream")
                .timeout(Duration.ofSeconds(timeoutSeconds))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                .build();
        HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
        String sid = response.headers().firstValue("Mcp-Session-Id").orElse(null);
        if (sid != null && !sid.isBlank()) sessionId = sid;

        if (!expectResponse) {
            response.body().close();
            if (response.statusCode() >= 400) {
                throw new McpException("MCP[" + name + "] 初始化通知失败：HTTP " + response.statusCode());
            }
            return new JsonObject();
        }

        if (response.statusCode() >= 400) {
            String error = readAll(response.body());
            throw new McpException("MCP[" + name + "] HTTP " + response.statusCode()
                    + (error.isBlank() ? "" : "：" + abbreviate(error)));
        }

        String contentType = response.headers().firstValue("Content-Type").orElse("");
        try (InputStream in = response.body()) {
            if (contentType.contains("text/event-stream")) {
                return readSseWithTimeout(in, id);
            }
            String text = readAllWithTimeout(in);
            if (text.isBlank()) throw new McpException("MCP[" + name + "] 响应为空");
            return JsonRpc.resultOrThrow(JsonParser.parseString(text).getAsJsonObject());
        }
    }

    /** 在虚拟线程中读取响应体，避免服务端保持长连接导致永久阻塞。 */
    private String readAllWithTimeout(InputStream in) throws Exception {
        CompletableFuture<String> future = new CompletableFuture<>();
        Thread.ofVirtual().name("mcp-" + name + "-body").start(() -> {
            try {
                future.complete(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            } catch (Exception e) {
                future.completeExceptionally(e);
            }
        });
        try {
            return future.get(timeoutSeconds, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            closeQuietly(in);
            throw new McpException("MCP[" + name + "] 响应超时");
        }
    }

    private JsonObject readSseWithTimeout(InputStream in, long id) throws Exception {
        CompletableFuture<JsonObject> future = new CompletableFuture<>();
        Thread.ofVirtual().name("mcp-" + name + "-sse").start(() -> {
            try {
                future.complete(readSse(in, id));
            } catch (Exception e) {
                future.completeExceptionally(e);
            }
        });
        try {
            return future.get(timeoutSeconds, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            closeQuietly(in);
            throw new McpException("MCP[" + name + "] 响应超时");
        }
    }

    private static void closeQuietly(InputStream in) {
        try {
            in.close();
        } catch (IOException ignored) {
        }
    }

    private HttpRequest.Builder requestBuilder() {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url));
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getValue() != null) builder.header(e.getKey(), e.getValue());
        }
        if (sessionId != null && !sessionId.isBlank()) builder.header("Mcp-Session-Id", sessionId);
        return builder;
    }

    /** 从 SSE 流中读取与请求 id 匹配的响应。 */
    private JsonObject readSse(InputStream in, long id) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder data = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.isEmpty()) {
                JsonObject msg = parse(data);
                data.setLength(0);
                if (matches(msg, id)) return JsonRpc.resultOrThrow(msg);
                continue;
            }
            if (line.startsWith("data:")) {
                if (data.length() > 0) data.append('\n');
                data.append(line.substring(5).trim());
            }
        }
        JsonObject msg = parse(data);
        if (matches(msg, id)) return JsonRpc.resultOrThrow(msg);
        throw new McpException("MCP[" + name + "] 未收到匹配的响应（id=" + id + "）");
    }

    private static boolean matches(JsonObject msg, long id) {
        if (msg == null || !msg.has("id") || msg.get("id").isJsonNull() || !msg.get("id").isJsonPrimitive()) {
            return false;
        }
        try {
            return msg.get("id").getAsLong() == id;
        } catch (Exception e) {
            return false;
        }
    }

    private static JsonObject parse(StringBuilder data) {
        if (data.length() == 0) return null;
        try {
            return JsonParser.parseString(data.toString()).getAsJsonObject();
        } catch (Exception e) {
            return null;
        }
    }

    private static String readAll(InputStream in) {
        try (InputStream input = in) {
            return new String(input.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
    }

    private static String abbreviate(String s) {
        return s.length() <= 300 ? s : s.substring(0, 300) + "…";
    }
}
