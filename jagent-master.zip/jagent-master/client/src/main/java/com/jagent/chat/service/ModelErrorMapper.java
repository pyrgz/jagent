package com.jagent.chat.service;

import com.jagent.common.exception.BaseException;
import com.jagent.common.exception.BusinessException;
import com.jagent.common.exception.SystemException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.langchain4j.exception.AuthenticationException;
import dev.langchain4j.exception.HttpException;
import dev.langchain4j.exception.InternalServerException;
import dev.langchain4j.exception.InvalidRequestException;
import dev.langchain4j.exception.ModelNotFoundException;
import dev.langchain4j.exception.RateLimitException;
import dev.langchain4j.exception.TimeoutException;

import java.io.IOException;
import java.net.ConnectException;
import java.net.http.HttpTimeoutException;

/**
 * 模型调用异常转换：把底层异常翻译成可直接展示给用户的业务异常 / 系统异常，
 * 避免前端看到原始 JSON 或堆栈信息。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class ModelErrorMapper {

    /** 认证失败：API Key 无效、过期或未配置。 */
    public static final String AUTH_INVALID = "MODEL_AUTH_INVALID";
    /** 频率 / 额度受限。 */
    public static final String RATE_LIMIT = "MODEL_RATE_LIMIT";
    /** 模型不存在或无权访问。 */
    public static final String MODEL_NOT_FOUND = "MODEL_NOT_FOUND";
    /** 请求参数有误。 */
    public static final String BAD_REQUEST = "MODEL_BAD_REQUEST";
    /** 网络不可达。 */
    public static final String NETWORK = "MODEL_NETWORK";
    /** 模型服务不可用。 */
    public static final String SERVER_ERROR = "MODEL_SERVER_ERROR";
    /** 未归类的模型错误。 */
    public static final String UNKNOWN = "MODEL_ERROR";

    private ModelErrorMapper() {}

    /** 把异常（含 cause 链）转换为业务/系统异常。 */
    public static BaseException toUserError(Throwable t) {
        Throwable cause = rootCause(t);

        if (cause instanceof AuthenticationException) {
            return new BusinessException(AUTH_INVALID, "模型 API Key 无效或已过期，请在设置中重新填写 API Key。");
        }
        if (cause instanceof RateLimitException) {
            return new BusinessException(RATE_LIMIT, "模型请求过于频繁或额度不足，请稍后重试。");
        }
        if (cause instanceof ModelNotFoundException) {
            return new BusinessException(MODEL_NOT_FOUND, "模型不存在或当前 API Key 无权访问，请检查模型名称。");
        }
        if (cause instanceof InvalidRequestException) {
            return new BusinessException(BAD_REQUEST, "模型请求参数有误：" + detail(cause));
        }
        if (cause instanceof TimeoutException || cause instanceof HttpTimeoutException) {
            return new SystemException(NETWORK, "模型响应超时，请检查网络后重试。", cause);
        }
        if (cause instanceof InternalServerException) {
            return new SystemException(SERVER_ERROR, "模型服务内部错误，请稍后重试。", cause);
        }
        if (cause instanceof HttpException http) {
            return fromHttpStatus(http.statusCode(), cause);
        }
        if (cause instanceof ConnectException) {
            return new SystemException(NETWORK, "无法连接模型服务，请检查网络和接口地址。", cause);
        }
        if (cause instanceof IOException) {
            return new SystemException(NETWORK, "模型通信异常，请检查网络后重试。", cause);
        }
        return new SystemException(UNKNOWN, "模型调用失败：" + detail(cause), cause);
    }

    /** 按 HTTP 状态码转换为友好提示。 */
    public static BaseException fromHttpStatus(int status) {
        return fromHttpStatus(status, null);
    }

    private static BaseException fromHttpStatus(int status, Throwable cause) {
        if (status == 401 || status == 403) {
            return new BusinessException(AUTH_INVALID, "模型服务认证失败，请检查 API Key 或登录状态。");
        }
        if (status == 404) {
            return new BusinessException(MODEL_NOT_FOUND, "模型不存在或接口地址有误，请检查模型名称与接口地址。");
        }
        if (status == 429) {
            return new BusinessException(RATE_LIMIT, "模型请求过于频繁或额度不足，请稍后重试。");
        }
        if (status >= 500) {
            return new SystemException(SERVER_ERROR, "模型服务暂时不可用（HTTP " + status + "），请稍后重试。", cause);
        }
        String suffix = cause == null ? "" : "：" + detail(cause);
        return new BusinessException(BAD_REQUEST, "模型服务请求失败（HTTP " + status + "）" + suffix);
    }

    /** CodeBuddy 桥接服务下发的 error 事件。 */
    public static BaseException fromServer(String code, String message) {
        if ("AUTH_REQUIRED".equals(code)) {
            return new BusinessException(AUTH_INVALID, "登录已失效，请重新登录 CodeBuddy。");
        }
        String text = safeText(message, "模型调用失败，请稍后重试。");
        return new SystemException(code == null || code.isBlank() ? UNKNOWN : code, text);
    }

    // ---- helpers ----

    private static Throwable rootCause(Throwable t) {
        Throwable cur = t;
        while (cur != null && cur.getCause() != null && cur.getCause() != cur) {
            cur = cur.getCause();
        }
        return cur == null ? t : cur;
    }

    /** 从原始异常信息中提取可读内容，截断并脱敏 API Key。 */
    private static String detail(Throwable t) {
        if (t == null) return "未知错误";
        String msg = t.getMessage();
        if (msg == null || msg.isBlank()) return t.getClass().getSimpleName();
        msg = extractJsonMessage(msg);
        msg = msg.replaceAll("(?i)(api[_\\s-]?key[\"'\\s:=]+)[^\\s,}\"']+", "$1***");
        msg = msg.replaceAll("\\s+", " ").trim();
        return msg.length() > 200 ? msg.substring(0, 200) + "…" : msg;
    }

    private static String extractJsonMessage(String msg) {
        String trimmed = msg.trim();
        if (!trimmed.startsWith("{")) return msg;
        try {
            JsonObject obj = JsonParser.parseString(trimmed).getAsJsonObject();
            if (obj.has("error") && obj.get("error").isJsonObject()) {
                JsonObject err = obj.getAsJsonObject("error");
                if (err.has("message") && !err.get("message").isJsonNull()) {
                    return err.get("message").getAsString();
                }
            }
            if (obj.has("message") && !obj.get("message").isJsonNull()) {
                return obj.get("message").getAsString();
            }
        } catch (Exception ignored) {
        }
        return msg;
    }

    private static String safeText(String text, String fallback) {
        return text == null || text.isBlank() ? fallback : text;
    }
}
