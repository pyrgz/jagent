package com.jagent.harness.example;

import com.jagent.harness.Harness;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.function.Supplier;

/**
 * 业务场景 Harness 示例：生成 Git 项目日报（站会 / 交接用）。
 *
 * <p>在对话框中执行：</p>
 * <pre>
 * /harness report        // 最近 1 天
 * /harness report 7      // 最近 7 天
 * </pre>
 *
 * <p>统计维度：当前分支、提交列表、变更文件数与增删行数、未提交改动。
 * 仅依赖本机 git，不调用大模型。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ProjectDailyReportHarness implements Harness {

    private final Supplier<String> cwdSupplier;

    public ProjectDailyReportHarness(Supplier<String> cwdSupplier) {
        this.cwdSupplier = cwdSupplier;
    }

    @Override
    public String id() {
        return "report";
    }

    @Override
    public String name() {
        return "项目日报";
    }

    @Override
    public String execute(String input) throws Exception {
        Path cwd = resolveRoot();
        if (cwd == null) {
            return "工作目录不存在，无法生成日报。";
        }
        if (!"true".equals(run(cwd, "git", "rev-parse", "--is-inside-work-tree"))) {
            return "当前工作目录不是 Git 仓库：" + cwd;
        }

        int days = parseDays(input);
        String branch = run(cwd, "git", "rev-parse", "--abbrev-ref", "HEAD");
        String commits = run(cwd, "git", "log", "--since=" + days + ".days.ago",
                "--pretty=format:%h | %ad | %an | %s", "--date=short");
        String numstat = run(cwd, "git", "log", "--since=" + days + ".days.ago",
                "--pretty=tformat:", "--numstat");
        String status = run(cwd, "git", "status", "--porcelain");

        int files = 0;
        long added = 0;
        long deleted = 0;
        if (!numstat.isBlank()) {
            for (String line : numstat.split("\\R")) {
                String[] parts = line.split("\t");
                if (parts.length < 3) continue;
                files++;
                added += parseLong(parts[0]);
                deleted += parseLong(parts[1]);
            }
        }
        int uncommitted = status.isBlank() ? 0 : status.split("\\R").length;
        int commitCount = commits.isBlank() ? 0 : commits.split("\\R").length;

        StringBuilder sb = new StringBuilder("项目日报：").append(cwd).append('\n');
        sb.append("- 分支：").append(branch.isBlank() ? "（未知）" : branch).append('\n');
        sb.append("- 统计区间：最近 ").append(days).append(" 天\n");
        sb.append("- 提交：").append(commitCount).append(" 个\n");
        sb.append("- 变更：").append(files).append(" 个文件，+").append(added)
                .append(" / -").append(deleted).append('\n');
        sb.append("- 未提交改动：").append(uncommitted).append(" 个文件\n");

        if (commitCount == 0) {
            sb.append("\n最近 ").append(days).append(" 天没有提交。");
        } else {
            sb.append("\n提交明细：\n");
            String[] lines = commits.split("\\R");
            int limit = Math.min(lines.length, 20);
            for (int i = 0; i < limit; i++) {
                sb.append("- ").append(lines[i]).append('\n');
            }
            if (lines.length > limit) {
                sb.append("- …其余 ").append(lines.length - limit).append(" 条省略\n");
            }
        }
        return sb.toString().trim();
    }

    private Path resolveRoot() {
        String cwd = cwdSupplier == null ? null : cwdSupplier.get();
        Path root = (cwd == null || cwd.isBlank()) ? Path.of(System.getProperty("user.dir")) : Path.of(cwd);
        try {
            return Files.isDirectory(root) ? root.toAbsolutePath().normalize() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private static int parseDays(String input) {
        if (input == null || input.isBlank()) return 1;
        try {
            int days = Integer.parseInt(input.trim());
            return Math.max(1, Math.min(30, days));
        } catch (NumberFormatException e) {
            return 1;
        }
    }

    private static long parseLong(String value) {
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** 执行 git 命令并返回 stdout（15 秒超时或失败返回空串）。 */
    private static String run(Path cwd, String... command) {
        Process process = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(command)
                    .directory(cwd.toFile())
                    .redirectErrorStream(true);
            pb.environment().put("GIT_TERMINAL_PROMPT", "0");
            process = pb.start();

            // 在虚拟线程中读取输出，避免子进程卡死时永久阻塞
            Process running = process;
            java.util.concurrent.CompletableFuture<String> output = new java.util.concurrent.CompletableFuture<>();
            Thread.ofVirtual().name("git-reader").start(() -> {
                try {
                    output.complete(new String(running.getInputStream().readAllBytes(), StandardCharsets.UTF_8));
                } catch (Exception e) {
                    output.completeExceptionally(e);
                }
            });
            if (!process.waitFor(15, java.util.concurrent.TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return "";
            }
            return output.get(2, java.util.concurrent.TimeUnit.SECONDS).trim();
        } catch (Exception e) {
            return "";
        } finally {
            if (process != null && process.isAlive()) process.destroyForcibly();
        }
    }
}
