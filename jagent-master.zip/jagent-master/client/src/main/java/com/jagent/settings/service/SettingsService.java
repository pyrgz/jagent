package com.jagent.settings.service;

import com.jagent.common.util.ModelLog;
import com.jagent.harness.Harness;
import com.jagent.settings.model.AppSettings;
import com.jagent.store.Store;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 客户端设置：加载 / 保存 / 主题等偏好。纯 Java，无 UI 依赖。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class SettingsService implements Harness {

    private static final Logger log = LogManager.getLogger(SettingsService.class);

    @Override
    public String id() { return "settings"; }

    @Override
    public String name() { return "设置"; }

    @Override
    public void shutdown() { save(); }

    private final AppSettings settings;

    public SettingsService() {
        this.settings = Store.loadSettings();
        if (settings.cwd == null || settings.cwd.isBlank()) {
            settings.cwd = System.getProperty("user.dir");
        }
        ModelLog.setDebug(resolveDebug(settings));
        log.info("设置加载完成：provider={}, theme={}, cwd={}, debug={}",
                settings.provider, settings.theme, settings.cwd, settings.debug);
    }

    public AppSettings settings() {
        return settings;
    }

    public String theme() {
        return settings.theme == null || settings.theme.isBlank() ? "light" : settings.theme;
    }

    public void setTheme(String theme) {
        settings.theme = (theme == null || theme.isBlank()) ? "light" : theme;
        log.info("切换主题：{}", settings.theme);
        save();
    }

    /** 调试模式：开启后全量打印模型输入输出日志。 */
    public boolean debug() {
        return settings.debug;
    }

    public void setDebug(boolean debug) {
        settings.debug = debug;
        ModelLog.setDebug(debug);
        save();
    }

    public void save() {
        Store.saveSettings(settings);
        log.info("设置已保存：provider={}, model={}, debug={}",
                settings.provider, settings.model, settings.debug);
    }

    /** 系统属性 / 环境变量可强制覆盖设置项（便于 IDE 或无界面调试）。 */
    private static boolean resolveDebug(AppSettings s) {
        String prop = System.getProperty("jagent.debug");
        if (prop != null && !prop.isBlank()) return Boolean.parseBoolean(prop);
        String env = System.getenv("JAGENT_DEBUG");
        if (env != null && !env.isBlank()) return Boolean.parseBoolean(env);
        return s.debug;
    }
}
