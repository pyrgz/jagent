package com.jagent.chat.tool;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.file.Path;

/**
 * 工具基类：持有工作目录，提供路径解析与参数读取的公共逻辑。
 *
 * @author azhu
 * @date 2026-10-24
 */
public abstract class BaseTool implements Tool {

    /** 工具读写文件的工作目录（相对路径据此解析）。 */
    protected final Path root;

    protected BaseTool(Path root) {
        this.root = root;
    }

    /** 相对路径按工作目录解析，绝对路径原样返回（规范化）。 */
    protected Path resolve(String p) {
        Path path = Path.of(p);
        return (path.isAbsolute() ? path : root.resolve(path)).normalize();
    }

    protected static JsonObject args(String argumentsJson) {
        return JsonParser.parseString(argumentsJson).getAsJsonObject();
    }

    protected static String arg(JsonObject args, String key) {
        return args.has(key) && !args.get(key).isJsonNull() ? args.get(key).getAsString() : null;
    }
}
