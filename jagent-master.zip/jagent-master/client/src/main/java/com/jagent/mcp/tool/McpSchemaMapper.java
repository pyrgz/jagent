package com.jagent.mcp.tool;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.langchain4j.model.chat.request.json.JsonAnyOfSchema;
import dev.langchain4j.model.chat.request.json.JsonArraySchema;
import dev.langchain4j.model.chat.request.json.JsonBooleanSchema;
import dev.langchain4j.model.chat.request.json.JsonEnumSchema;
import dev.langchain4j.model.chat.request.json.JsonIntegerSchema;
import dev.langchain4j.model.chat.request.json.JsonNumberSchema;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;
import dev.langchain4j.model.chat.request.json.JsonRawSchema;
import dev.langchain4j.model.chat.request.json.JsonSchemaElement;
import dev.langchain4j.model.chat.request.json.JsonStringSchema;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 把 MCP tools/list 返回的 JSON Schema 转成 langchain4j 的工具参数结构。
 * 无法识别的关键字（anyOf/$ref 等）以 JsonRawSchema 原样透传。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class McpSchemaMapper {

    private McpSchemaMapper() {}

    public static JsonObjectSchema toObjectSchema(JsonObject schema) {
        JsonObjectSchema.Builder builder = JsonObjectSchema.builder();
        if (schema == null) return builder.build();

        String description = str(schema, "description");
        if (description != null) builder.description(description);

        if (schema.has("properties") && schema.get("properties").isJsonObject()) {
            for (Map.Entry<String, JsonElement> entry : schema.getAsJsonObject("properties").entrySet()) {
                builder.addProperty(entry.getKey(), toElement(entry.getValue()));
            }
        }
        if (schema.has("required") && schema.get("required").isJsonArray()) {
            List<String> required = new ArrayList<>();
            for (JsonElement el : schema.getAsJsonArray("required")) {
                if (el.isJsonPrimitive()) required.add(el.getAsString());
            }
            if (!required.isEmpty()) builder.required(required);
        }
        if (schema.has("additionalProperties") && schema.get("additionalProperties").isJsonPrimitive()) {
            builder.additionalProperties(schema.get("additionalProperties").getAsBoolean());
        }
        return builder.build();
    }

    private static JsonSchemaElement toElement(JsonElement element) {
        if (element == null || !element.isJsonObject()) return JsonStringSchema.builder().build();
        JsonObject object = element.getAsJsonObject();
        String description = str(object, "description");
        String type = typeOf(object);

        switch (type == null ? "" : type) {
            case "object":
                return toObjectSchema(object);
            case "array": {
                JsonElement items = object.get("items");
                JsonSchemaElement item = items != null && items.isJsonObject()
                        ? toElement(items) : JsonStringSchema.builder().build();
                JsonArraySchema.Builder builder = JsonArraySchema.builder().items(item);
                if (description != null) builder.description(description);
                return builder.build();
            }
            case "integer": {
                JsonIntegerSchema.Builder builder = JsonIntegerSchema.builder();
                if (description != null) builder.description(description);
                return builder.build();
            }
            case "number": {
                JsonNumberSchema.Builder builder = JsonNumberSchema.builder();
                if (description != null) builder.description(description);
                return builder.build();
            }
            case "boolean": {
                JsonBooleanSchema.Builder builder = JsonBooleanSchema.builder();
                if (description != null) builder.description(description);
                return builder.build();
            }
            case "string": {
                if (object.has("enum") && object.get("enum").isJsonArray()) {
                    List<String> values = new ArrayList<>();
                    for (JsonElement el : object.getAsJsonArray("enum")) {
                        if (el.isJsonPrimitive()) values.add(el.getAsString());
                    }
                    JsonEnumSchema.Builder builder = JsonEnumSchema.builder().enumValues(values);
                    if (description != null) builder.description(description);
                    return builder.build();
                }
                JsonStringSchema.Builder builder = JsonStringSchema.builder();
                if (description != null) builder.description(description);
                return builder.build();
            }
            case "anyOf":
            case "oneOf": {
                List<JsonSchemaElement> options = new ArrayList<>();
                JsonElement arr = object.has("anyOf") ? object.get("anyOf") : object.get("oneOf");
                if (arr != null && arr.isJsonArray()) {
                    for (JsonElement el : arr.getAsJsonArray()) options.add(toElement(el));
                }
                if (options.isEmpty()) return JsonRawSchema.from(object.toString());
                JsonAnyOfSchema.Builder builder = JsonAnyOfSchema.builder().anyOf(options);
                if (description != null) builder.description(description);
                return builder.build();
            }
            default:
                return JsonRawSchema.from(object.toString());
        }
    }

    /** type 可能是字符串或字符串数组（如 ["string","null"]）。 */
    private static String typeOf(JsonObject object) {
        if (!object.has("type")) return object.has("properties") ? "object" : null;
        JsonElement type = object.get("type");
        if (type.isJsonPrimitive()) return type.getAsString();
        if (type.isJsonArray()) {
            for (JsonElement el : type.getAsJsonArray()) {
                if (!el.isJsonPrimitive()) continue;
                String value = el.getAsString();
                if (!"null".equals(value)) return value;
            }
        }
        return null;
    }

    private static String str(JsonObject o, String key) {
        return o != null && o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
    }
}
