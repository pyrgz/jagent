package com.jagent.harness.audit;

import com.jagent.store.Store;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.UUID;

/**
 * Harness 执行审计：把每次业务动作的输入、输出、耗时、结果追加到
 * {@code data/harness-audit.jsonl}，用于事后归因与回归定位。
 *
 * <p>审计是强制层：由 {@code /harness} 命令入口统一记录，不依赖具体 harness 实现。</p>
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class HarnessAudit {

    private static final Logger log = LogManager.getLogger(HarnessAudit.class);
    private static final Gson GSON = new GsonBuilder().create();
    private static final Path FILE = Store.dataDir().resolve("harness-audit.jsonl");
    private static final Object LOCK = new Object();
    private static final int INPUT_LIMIT = 2000;
    private static final int OUTPUT_LIMIT = 4000;

    private HarnessAudit() {}

    /**
     * 记录一次 harness 执行。
     *
     * @param harnessId   harness 标识
     * @param harnessName 显示名
     * @param input       调用入参
     * @param output      执行结果
     * @param error       错误信息（成功为 null）
     * @param durationMs  耗时
     */
    public static void record(String harnessId, String harnessName, String input,
                              String output, String error, long durationMs) {
        JsonObject record = new JsonObject();
        record.addProperty("time", Instant.now().toString());
        record.addProperty("runId", UUID.randomUUID().toString());
        record.addProperty("harness", harnessId);
        record.addProperty("name", harnessName);
        record.addProperty("status", error == null ? "ok" : "error");
        record.addProperty("durationMs", durationMs);
        record.addProperty("input", truncate(input, INPUT_LIMIT));
        record.addProperty("output", truncate(output, OUTPUT_LIMIT));
        if (error != null) record.addProperty("error", truncate(error, INPUT_LIMIT));

        synchronized (LOCK) {
            try {
                Files.writeString(FILE, GSON.toJson(record) + System.lineSeparator(),
                        StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (Exception e) {
                log.warn("写入 harness 审计日志失败：{}", FILE, e);
            }
        }
    }

    private static String truncate(String text, int limit) {
        if (text == null) return "";
        return text.length() <= limit ? text : text.substring(0, limit) + "…（已截断）";
    }
}
