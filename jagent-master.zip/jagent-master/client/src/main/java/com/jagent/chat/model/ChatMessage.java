package com.jagent.chat.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 聊天消息
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ChatMessage {
    public String id;
    public String role; // user | assistant
    public String content = "";
    /** 模型思考过程（扩展思考/推理），与正式回答分开展示 */
    public String thinking = "";
    public List<ToolCall> toolCalls = new ArrayList<>();
    public boolean error;
    /** 本地命令消息（如 /harness），只展示、不发送给模型 */
    public boolean local;
    public String model;
    public long createdAt = System.currentTimeMillis();

    public ChatMessage() {}

    public ChatMessage(String id, String role) {
        this.id = id;
        this.role = role;
    }
}
