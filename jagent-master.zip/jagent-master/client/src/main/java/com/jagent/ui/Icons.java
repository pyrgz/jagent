package com.jagent.ui;

import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;

/**
 * 内置 SVG 图标（24x24 viewBox）
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class Icons {

    public static final String MENU = "M4 6h16M4 12h16M4 18h16";
    public static final String PLUS = "M12 5v14M5 12h14";
    public static final String SEND = "M12 19V5M5 12l7-7 7 7";
    public static final String STOP = "M7.5 7.5h9v9h-9z";
    public static final String TRASH = "M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2";
    public static final String SETTINGS = "M21 4h-7M10 4H3M14 2v4M21 12h-9M8 12H3M8 10v4M21 20h-5M8 20H3M16 18v4";
    public static final String CHECK = "M5 13l4 4L19 7";
    public static final String CLOSE = "M6 6l12 12M18 6L6 18";
    public static final String COPY = "M9 9h11v11H9zM5 15V5a1 1 0 0 1 1-1h9";
    public static final String SPARK = "M12 2l2.35 7.65L22 12l-7.65 2.35L12 22l-2.35-7.65L2 12l7.65-2.35z";
    public static final String REFRESH = "M21 12a9 9 0 1 1-2.6-6.4M21 3v6h-6";
    public static final String FOLDER = "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z";
    public static final String FILE = "M7 3h7l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zM14 3v4h4";
    public static final String CHAT = "M21 12a8 8 0 0 1-8 8H5l-2 2V12a8 8 0 0 1 8-8h2a8 8 0 0 1 8 8z";
    public static final String CHEVRON = "M6 9l6 6 6-6";
    public static final String ARROW_RIGHT = "M5 12h14M13 6l6 6-6 6";
    public static final String CLOCK = "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 2";
    public static final String GRID = "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z";
    public static final String PLUG = "M9 7V3M15 7V3M7 7h10v4a5 5 0 0 1-10 0zM12 16v5";
    public static final String PAINT = "M12 2.5C9 7 6.5 10.3 6.5 14a5.5 5.5 0 0 0 11 0C17.5 10.3 15 7 12 2.5z";
    public static final String BOOK = "M12 6c-2-1.5-4.5-2-8-2v14c3.5 0 6 .5 8 2 2-1.5 4.5-2 8-2V4c-3.5 0-6 .5-8 2zM12 6v14";

    private Icons() {}

    /** 生成指定尺寸的描边图标 */
    public static Node stroke(String d, double size, Color color) {
        return build(d, size, color, true, 2.1);
    }

    /** 生成指定尺寸的填充图标 */
    public static Node fill(String d, double size, Color color) {
        return build(d, size, color, false, 0);
    }

    private static Node build(String d, double size, Color color, boolean stroke, double strokeWidth) {
        SVGPath p = new SVGPath();
        p.setContent(d);
        if (stroke) {
            p.setFill(Color.TRANSPARENT);
            p.setStroke(color);
            p.setStrokeWidth(strokeWidth);
            p.setStrokeLineCap(StrokeLineCap.ROUND);
            p.setStrokeLineJoin(StrokeLineJoin.ROUND);
        } else {
            p.setFill(color);
        }
        double scale = size / 24.0;
        p.setScaleX(scale);
        p.setScaleY(scale);
        Group g = new Group(p);
        StackPane pane = new StackPane(g);
        pane.setPrefSize(size, size);
        pane.setMinSize(size, size);
        pane.setMaxSize(size, size);
        return pane;
    }
}
