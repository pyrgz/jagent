package com.jagent.common.util;

/**
 * 字符串通用工具。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class StringUtil {

    private StringUtil() {}

    public static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    public static boolean isNotBlank(String s) {
        return !isBlank(s);
    }

    /** 空串返回默认值。 */
    public static String defaultIfBlank(String s, String def) {
        return isBlank(s) ? def : s;
    }

    /** 超长截断并追加省略号；不超长原样返回。 */
    public static String truncate(String s, int maxLen) {
        if (s == null || s.length() <= maxLen) return s;
        return s.substring(0, maxLen) + "…";
    }
}
