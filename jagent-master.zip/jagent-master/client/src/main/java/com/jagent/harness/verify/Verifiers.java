package com.jagent.harness.verify;

import com.jagent.harness.HarnessPipeline;

import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * 内置验收规则：非空、包含文本、正则匹配，支持取反。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class Verifiers {

    private Verifiers() {}

    public static HarnessVerifier of(VerifyDef def) {
        return steps -> {
            int index = def.step - 1;
            if (index < 0 || index >= steps.size()) {
                return VerificationResult.fail("步骤不存在：" + def.step);
            }
            HarnessPipeline.StepResult step = steps.get(index);
            if (!step.ok()) {
                return VerificationResult.fail("第 " + def.step + " 步执行失败：" + step.error());
            }
            String output = step.output() == null ? "" : step.output();
            String type = def.type == null ? "" : def.type.trim();

            boolean passed;
            String label;
            switch (type) {
                case "nonEmpty" -> {
                    passed = !output.isBlank();
                    label = "第 " + def.step + " 步输出非空";
                }
                case "contains" -> {
                    String value = def.value == null ? "" : def.value;
                    passed = output.contains(value);
                    label = "第 " + def.step + " 步输出包含“" + value + "”";
                }
                case "regex" -> {
                    try {
                        passed = Pattern.compile(def.value == null ? "" : def.value).matcher(output).find();
                        label = "第 " + def.step + " 步输出匹配 /" + def.value + "/";
                    } catch (PatternSyntaxException e) {
                        return VerificationResult.fail("正则表达式无效：" + def.value);
                    }
                }
                default -> {
                    return VerificationResult.fail("未知验收类型：" + def.type);
                }
            }
            if (def.negate) {
                passed = !passed;
                label = "取反：" + label;
            }
            return passed ? VerificationResult.pass(label) : VerificationResult.fail(label);
        };
    }
}
