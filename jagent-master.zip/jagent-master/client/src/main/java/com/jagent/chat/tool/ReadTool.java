package com.jagent.chat.tool;

import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 读取文本文件内容。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ReadTool extends BaseTool {

    public ReadTool(Path root) {
        super(root);
    }

    @Override
    public ToolSpecification specification() {
        return ToolSpecification.builder()
                .name("Read")
                .description("读取指定路径的文本文件，返回文件全文。")
                .parameters(JsonObjectSchema.builder()
                        .addStringProperty("path", "文件的绝对路径或相对工作目录的路径")
                        .required("path")
                        .build())
                .build();
    }

    @Override
    public String execute(String argumentsJson) throws Exception {
        String p = arg(args(argumentsJson), "path");
        if (p == null || p.isBlank()) return "错误：缺少 path 参数";
        return Files.readString(resolve(p));
    }

    @Override
    public boolean requiresPermission() {
        return false;
    }
}
