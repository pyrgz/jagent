package com.jagent.ui;

import com.jagent.chat.model.Conversation;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * 左侧边栏：新建会话、会话列表、登录状态、设置入口
 *
 * @author azhu
 * @date 2026-10-24
 */
public class SidebarView {

    private final VBox root;
    private final ListView<Conversation> list;
    private final StackPane statusDot;
    private final Label statusLabel;
    private Runnable onStatusClick;

    /** 正在流式输出的会话 id 集合（并行流式时在侧边栏显示指示点）。 */
    private final Set<String> streamingIds = Collections.newSetFromMap(new ConcurrentHashMap<>());

    public SidebarView(Runnable onNewChat,
                      Consumer<Conversation> onSelect,
                      Consumer<Conversation> onDelete,
                      Runnable onSettings) {

        // ---------- 新建会话 ----------
        Button newChat = new Button("新建会话");
        newChat.getStyleClass().add("btn-new-chat");
        newChat.setGraphic(Icons.stroke(Icons.PLUS, 16, Color.web("#0052D9")));
        newChat.setAlignment(Pos.CENTER_LEFT);
        newChat.setMaxWidth(Double.MAX_VALUE);
        newChat.setOnAction(e -> onNewChat.run());

        // ---------- 会话列表 ----------
        list = new ListView<>();
        list.getStyleClass().add("conv-list");
        VBox.setVgrow(list, Priority.ALWAYS);
        list.setCellFactory(lv -> new ConvCell(onDelete, streamingIds::contains));
        list.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n != null && onSelect != null) onSelect.accept(n);
        });

        // ---------- 登录状态 ----------
        HBox statusChip = new HBox(8);
        statusChip.getStyleClass().add("status-chip");
        statusChip.setAlignment(Pos.CENTER_LEFT);
        statusChip.setPadding(new Insets(8, 10, 8, 10));
        statusDot = new StackPane();
        statusDot.getStyleClass().addAll("status-dot", "status-dot-off");
        statusDot.setPrefSize(8, 8);
        statusDot.setMinSize(8, 8);
        statusDot.setMaxSize(8, 8);
        statusLabel = new Label("正在连接服务…");
        statusLabel.getStyleClass().add("status-text");
        statusChip.getChildren().addAll(statusDot, statusLabel);
        statusChip.setOnMouseClicked(e -> {
            if (onStatusClick != null) onStatusClick.run();
        });

        // ---------- 设置按钮 ----------
        Button settings = new Button("设置");
        settings.getStyleClass().add("btn-ghost");
        settings.setGraphic(Icons.stroke(Icons.SETTINGS, 15, Color.web("#646A73")));
        settings.setAlignment(Pos.CENTER_LEFT);
        settings.setMaxWidth(Double.MAX_VALUE);
        settings.setOnAction(e -> onSettings.run());

        root = new VBox(10);
        root.getStyleClass().add("sidebar");
        root.setPadding(new Insets(14, 12, 14, 12));
        root.getChildren().addAll(newChat, list, statusChip, settings);
    }

    public Node node() {
        return root;
    }

    public void setOnSelect(Consumer<Conversation> onSelect) {
        list.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> {
            if (n != null) onSelect.accept(n);
        });
    }

    /** 刷新会话列表（保持选中态） */
    public void update(List<Conversation> conversations, String selectedId) {
        // 防止刷新时触发选择事件导致重复渲染
        list.getSelectionModel().clearSelection();
        list.getItems().setAll(conversations);
        if (selectedId != null) {
            for (int i = 0; i < conversations.size(); i++) {
                if (conversations.get(i).id.equals(selectedId)) {
                    list.getSelectionModel().select(i);
                    break;
                }
            }
        }
    }

    public void setOnStatusClick(Runnable onStatusClick) {
        this.onStatusClick = onStatusClick;
    }

    /** 标记某个会话是否正在流式输出（需在 FX 线程调用）。 */
    public void setStreaming(String convId, boolean streaming) {
        if (convId == null) return;
        if (streaming) {
            streamingIds.add(convId);
        } else {
            streamingIds.remove(convId);
        }
        list.refresh();
    }

    public void setStatus(boolean ok, String text) {
        statusDot.getStyleClass().setAll("status-dot", ok ? "status-dot-on" : "status-dot-off");
        statusLabel.setText(text);
    }

    // ---------------- 会话条目 ----------------

    private static class ConvCell extends ListCell<Conversation> {
        private final HBox card;
        private final Label title;
        private final Label time;
        private final StackPane streamingDot;
        private final StackPane del;
        private final Predicate<String> isStreaming;

        ConvCell(Consumer<Conversation> onDelete, Predicate<String> isStreaming) {
            this.isStreaming = isStreaming;
            setPrefWidth(0);
            title = new Label();
            title.getStyleClass().add("conv-title");
            title.setWrapText(true);
            time = new javafx.scene.control.Label();
            time.getStyleClass().add("conv-time");

            VBox texts = new VBox(2, title, time);

            streamingDot = new StackPane();
            streamingDot.getStyleClass().add("conv-streaming-dot");
            streamingDot.setPrefSize(6, 6);
            streamingDot.setMinSize(6, 6);
            streamingDot.setMaxSize(6, 6);

            del = new StackPane(Icons.stroke(Icons.TRASH, 14, Color.web("#98A0AB")));
            del.getStyleClass().add("conv-del");
            del.setPrefSize(24, 24);
            del.setMinSize(24, 24);
            del.setMaxSize(24, 24);

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            card = new HBox(6, texts, spacer, streamingDot, del);
            card.getStyleClass().add("conv-card");
            card.setPadding(new Insets(8, 10, 8, 10));
            card.setAlignment(Pos.CENTER_LEFT);
            del.setOnMouseClicked(e -> {
                Conversation c = getItem();
                if (c != null && onDelete != null) {
                    e.consume();
                    onDelete.accept(c);
                }
            });
            setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        }

        @Override
        protected void updateItem(Conversation c, boolean empty) {
            super.updateItem(c, empty);
            if (empty || c == null) {
                setGraphic(null);
            } else {
                title.setText(c.title == null || c.title.isBlank() ? "新会话" : c.title);
                time.setText(relativeTime(c.updatedAt));
                boolean streaming = isStreaming.test(c.id);
                streamingDot.setVisible(streaming);
                streamingDot.setManaged(streaming);
                setGraphic(card);
            }
        }
    }

    private static final DateTimeFormatter HHMM = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter MD = DateTimeFormatter.ofPattern("MM-dd HH:mm");

    static String relativeTime(long epochMillis) {
        try {
            LocalDateTime t = LocalDateTime.ofInstant(
                    java.time.Instant.ofEpochMilli(epochMillis),
                    java.time.ZoneId.systemDefault());
            LocalDateTime now = LocalDateTime.now();
            Duration d = Duration.between(t, now);
            if (d.toMinutes() < 1) return "刚刚";
            if (d.toMinutes() < 60) return d.toMinutes() + " 分钟前";
            if (t.toLocalDate().equals(now.toLocalDate())) return t.format(HHMM);
            if (t.toLocalDate().equals(now.toLocalDate().minusDays(1))) return "昨天 " + t.format(HHMM);
            if (t.toLocalDate().getYear() == now.getYear()) return t.format(MD);
            return t.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (Exception e) {
            return "";
        }
    }
}
