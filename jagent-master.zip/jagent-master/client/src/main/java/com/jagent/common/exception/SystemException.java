package com.jagent.common.exception;

/**
 * 系统异常：表示系统级错误（IO、网络、第三方服务异常等），
 * 通常非用户可恢复，需记录日志或提示稍后重试。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class SystemException extends BaseException {

    public SystemException(String message) {
        super(message);
    }

    public SystemException(String code, String message) {
        super(code, message);
    }

    public SystemException(String message, Throwable cause) {
        super(message, cause);
    }

    public SystemException(String code, String message, Throwable cause) {
        super(code, message, cause);
    }
}
