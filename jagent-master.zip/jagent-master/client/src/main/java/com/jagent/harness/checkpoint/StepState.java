package com.jagent.harness.checkpoint;

import com.jagent.harness.verify.VerifyDef;

/**
 * 编排中单个步骤的 checkpoint 状态。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class StepState {

    /** 0-based 步骤下标 */
    public int index;
    public String harness;
    public String name;
    /** 配置中的入参模板（可能含 ${prev} 等占位符） */
    public String inputTemplate;
    /** 步骤执行条件；为 null 表示无条件执行 */
    public VerifyDef when;

    /** pending | ok | error | skipped */
    public String status = "pending";
    public String output;
    public String error;
}
