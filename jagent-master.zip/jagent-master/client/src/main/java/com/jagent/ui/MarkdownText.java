package com.jagent.ui;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.input.Clipboard;
import javafx.scene.input.DataFormat;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.control.Tooltip;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 轻量 Markdown 渲染器（面向聊天消息）。
 * 支持：标题 / 加粗 / 斜体 / 行内代码 / 代码块（带复制）/ 引用 /
 * 有序无序列表 / 分隔线 / 链接（样式化）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class MarkdownText {

    private static final Pattern INLINE = Pattern.compile(
            "(`[^`\\n]+`)|(\\*\\*[^*\\n]+\\*\\*)|(\\*[^*\\n]+\\*)|(\\[[^\\]\\n]+\\]\\([^)\\s]+\\))");
    private static final Pattern UL = Pattern.compile("^[-*+]\\s+(.+)$");
    private static final Pattern OL = Pattern.compile("^(\\d+)[.)]\\s+(.+)$");
    private static final Pattern HR = Pattern.compile("^(-{3,}|\\*{3,}|_{3,})$");

    private MarkdownText() {}

    /**
     * 渲染 Markdown 文本。
     *
     * @param md        Markdown 源文本
     * @param streaming 是否处于流式输出状态（末尾显示光标）
     */
    public static Node render(String md, boolean streaming) {
        VBox root = new VBox(7);
        root.getStyleClass().add("md-root");
        if (md == null) md = "";

        String[] lines = md.replace("\r\n", "\n").replace("\r", "\n").split("\n", -1);
        List<String> para = new ArrayList<>();
        boolean inCode = false;
        StringBuilder code = new StringBuilder();
        String codeLang = "";

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String trimmed = line.trim();

            if (inCode) {
                if (trimmed.startsWith("```")) {
                    root.getChildren().add(codeBlock(codeLang, code.toString(), false));
                    inCode = false;
                    code.setLength(0);
                    codeLang = "";
                } else {
                    code.append(line).append('\n');
                }
                continue;
            }

            if (trimmed.startsWith("```")) {
                flushPara(root, para, false);
                inCode = true;
                codeLang = trimmed.substring(3).trim();
                continue;
            }

            if (trimmed.isEmpty()) {
                flushPara(root, para, false);
                continue;
            }

            if (HR.matcher(trimmed).matches()) {
                flushPara(root, para, false);
                root.getChildren().add(new Separator());
                continue;
            }

            if (trimmed.startsWith("#")) {
                flushPara(root, para, false);
                int level = 0;
                while (level < trimmed.length() && trimmed.charAt(level) == '#') level++;
                String text = trimmed.substring(Math.min(level, trimmed.length())).trim();
                Label h = new Label(text);
                h.setWrapText(true);
                h.setMaxWidth(Double.MAX_VALUE);
                h.getStyleClass().add("md-h" + Math.min(level, 4));
                root.getChildren().add(h);
                continue;
            }

            if (UL.matcher(trimmed).matches() || OL.matcher(trimmed).matches()) {
                flushPara(root, para, false);
                List<String[]> items = new ArrayList<>();
                while (i < lines.length) {
                    String t = lines[i].trim();
                    if (t.isEmpty()) break;
                    Matcher mu = UL.matcher(t);
                    Matcher mo = OL.matcher(t);
                    if (mu.matches()) {
                        items.add(new String[]{"•", mu.group(1)});
                    } else if (mo.matches()) {
                        items.add(new String[]{mo.group(1) + ".", mo.group(2)});
                    } else {
                        break;
                    }
                    i++;
                }
                i--; // 抵消外层 for 的自增
                VBox list = new VBox(3);
                list.getStyleClass().add("md-list");
                for (String[] item : items) {
                    HBox row = new HBox(6);
                    Text bullet = new Text(item[0]);
                    bullet.getStyleClass().add("md-bullet");
                    TextFlow tf = new TextFlow();
                    addInline(tf, item[1]);
                    row.getChildren().addAll(bullet, tf);
                    list.getChildren().add(row);
                }
                root.getChildren().add(list);
                continue;
            }

            if (trimmed.startsWith(">")) {
                flushPara(root, para, false);
                List<String> quote = new ArrayList<>();
                while (i < lines.length && lines[i].trim().startsWith(">")) {
                    quote.add(lines[i].trim().replaceFirst("^>\\s?", ""));
                    i++;
                }
                i--;
                VBox q = new VBox(3);
                q.getStyleClass().add("md-quote");
                for (String ql : quote) {
                    TextFlow tf = new TextFlow();
                    addInline(tf, ql);
                    q.getChildren().add(tf);
                }
                root.getChildren().add(q);
                continue;
            }

            para.add(trimmed);
        }

        flushPara(root, para, streaming);
        if (inCode && code.length() > 0) {
            // 流式中未闭合的代码块
            root.getChildren().add(codeBlock(codeLang, code.toString(), streaming));
        }
        return root;
    }

    private static void flushPara(VBox root, List<String> para, boolean streaming) {
        if (para.isEmpty()) return;
        String joined = String.join("\n", para);
        para.clear();
        TextFlow tf = new TextFlow();
        tf.getStyleClass().add("md-para");
        addInline(tf, joined);
        if (streaming) {
            Text cursor = new Text("▍");
            cursor.getStyleClass().add("md-cursor");
            tf.getChildren().add(cursor);
        }
        root.getChildren().add(tf);
    }

    /** 解析行内元素：`code`、**bold**、*italic*、[text](url) */
    private static void addInline(TextFlow tf, String text) {
        if (text == null || text.isEmpty()) return;
        Matcher m = INLINE.matcher(text);
        int last = 0;
        while (m.find()) {
            if (m.start() > last) {
                tf.getChildren().add(plain(text.substring(last, m.start())));
            }
            String g = m.group();
            if (g.startsWith("`")) {
                Label chip = new Label(g.substring(1, g.length() - 1));
                chip.getStyleClass().add("md-code-chip");
                tf.getChildren().add(chip);
            } else if (g.startsWith("**")) {
                Text t = plain(g.substring(2, g.length() - 2));
                t.getStyleClass().add("md-bold");
                tf.getChildren().add(t);
            } else if (g.startsWith("[")) {
                int split = g.indexOf("](");
                String label = g.substring(1, split);
                Text t = plain(label);
                t.getStyleClass().add("md-link");
                t.setUnderline(true);
                tf.getChildren().add(t);
            } else {
                Text t = plain(g.substring(1, g.length() - 1));
                t.getStyleClass().add("md-italic");
                tf.getChildren().add(t);
            }
            last = m.end();
        }
        if (last < text.length()) {
            tf.getChildren().add(plain(text.substring(last)));
        }
    }

    private static Text plain(String s) {
        Text t = new Text(s);
        t.getStyleClass().add("md-text");
        return t;
    }

    private static Node codeBlock(String lang, String code, boolean streaming) {
        VBox box = new VBox(4);
        box.getStyleClass().add("md-code-block");

        HBox bar = new HBox();
        bar.setAlignment(Pos.CENTER_LEFT);
        Label langLabel = new Label(lang == null || lang.isBlank() ? "code" : lang);
        langLabel.getStyleClass().add("md-code-lang");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        StackPane copyBtn = new StackPane(Icons.stroke(Icons.COPY, 13, Color.web("#9AA3B2")));
        copyBtn.getStyleClass().add("md-copy-btn");
        copyBtn.setPickOnBounds(false);
        Tooltip.install(copyBtn, new Tooltip("复制代码"));
        final String codeText = code;
        copyBtn.setOnMouseClicked(e -> {
            Clipboard.getSystemClipboard().setContent(Map.of(DataFormat.PLAIN_TEXT, codeText));
        });
        bar.getChildren().addAll(langLabel, spacer, copyBtn);

        TextFlow tf = new TextFlow();
        tf.getStyleClass().add("md-code-flow");
        Text t = new Text(code + (streaming ? "▍" : ""));
        t.getStyleClass().add("md-code-text");
        tf.getChildren().add(t);

        box.getChildren().addAll(bar, tf);
        return box;
    }
}
