package com.jagent.chat.tool;

import com.google.gson.JsonObject;
import dev.langchain4j.agent.tool.ToolSpecification;
import dev.langchain4j.model.chat.request.json.JsonObjectSchema;

import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * 按 glob 模式查找文件。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class GlobTool extends BaseTool {

    public GlobTool(Path root) {
        super(root);
    }

    @Override
    public ToolSpecification specification() {
        return ToolSpecification.builder()
                .name("Glob")
                .description("按 glob 模式（如 **/*.java）查找文件，返回匹配的相对路径列表。")
                .parameters(JsonObjectSchema.builder()
                        .addStringProperty("pattern", "glob 模式，如 **/*.java")
                        .addStringProperty("path", "搜索起点目录（可选，默认工作目录）")
                        .required("pattern")
                        .build())
                .build();
    }

    @Override
    public String execute(String argumentsJson) throws Exception {
        JsonObject a = args(argumentsJson);
        String pattern = arg(a, "pattern");
        if (pattern == null || pattern.isBlank()) return "错误：缺少 pattern 参数";
        String base = arg(a, "path");
        Path start = base == null || base.isBlank() ? root : resolve(base);

        PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + pattern);
        List<String> matches = new ArrayList<>();
        if (Files.isDirectory(start)) {
            try (Stream<Path> stream = Files.walk(start)) {
                stream.filter(Files::isRegularFile)
                        .filter(p -> matcher.matches(start.relativize(p)))
                        .limit(500)
                        .forEach(p -> matches.add(start.relativize(p).toString()));
            }
        }
        return matches.isEmpty() ? "未找到匹配文件" : String.join("\n", matches);
    }

    @Override
    public boolean requiresPermission() {
        return false;
    }
}
