package com.jagent.settings.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 模型服务商预设（OpenAI 兼容接口），持久化到 data/providers.json。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class ProviderPreset {
    public String name = "";
    public String baseUrl = "";
    public List<String> models = new ArrayList<>();
}
