package com.jagent.common.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Type;

/**
 * Gson 封装：统一序列化/反序列化入口。
 *
 * @author azhu
 * @date 2026-10-24
 */
public final class JsonUtil {

    private static final Gson PRETTY = new GsonBuilder().setPrettyPrinting().create();
    private static final Gson COMPACT = new Gson();

    private JsonUtil() {}

    public static String toJson(Object obj) {
        return PRETTY.toJson(obj);
    }

    public static String toCompactJson(Object obj) {
        return COMPACT.toJson(obj);
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        return PRETTY.fromJson(json, clazz);
    }

    public static <T> T fromJson(String json, Type type) {
        return PRETTY.fromJson(json, type);
    }
}
