package com.jagent.workspace.model;

/**
 * 工作区文件树节点（纯内存模型，不持久化）。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class FileNode {
    public String name;
    public String path;
    public boolean directory;
    public long size;

    public FileNode() {}

    public FileNode(String name, String path, boolean directory, long size) {
        this.name = name;
        this.path = path;
        this.directory = directory;
        this.size = size;
    }
}
