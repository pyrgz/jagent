package com.jagent.mcp.model;

import com.google.gson.JsonObject;

/**
 * MCP Server 通过 tools/list 返回的单个工具定义。
 *
 * @author azhu
 * @date 2026-10-24
 */
public record McpToolDef(String name, String description, JsonObject inputSchema) {
}
