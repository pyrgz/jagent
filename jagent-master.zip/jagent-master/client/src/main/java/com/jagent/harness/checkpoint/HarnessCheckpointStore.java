package com.jagent.harness.checkpoint;

import com.jagent.harness.verify.VerifyDef;
import com.jagent.store.Store;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Harness checkpoint 存储：每次编排运行保存为 data/harness-runs/&lt;runId&gt;.json。
 * 每个步骤完成后立即落盘，失败后可用 {@code --resume <runId>} 从检查点继续。
 *
 * @author azhu
 * @date 2026-10-24
 */
public class HarnessCheckpointStore {

    private static final Logger log = LogManager.getLogger(HarnessCheckpointStore.class);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final Path dir;

    public HarnessCheckpointStore() {
        this(Store.dataDir().resolve("harness-runs"));
    }

    public HarnessCheckpointStore(Path dir) {
        this.dir = dir;
    }

    public Path dir() {
        return dir;
    }

    public RunState create(String pipeline, String name, String input, boolean chain,
                           List<StepState> steps, List<VerifyDef> verify) {
        RunState state = new RunState();
        state.runId = Instant.now().toEpochMilli() + "-" + UUID.randomUUID().toString().substring(0, 8);
        state.pipeline = pipeline;
        state.name = name;
        state.invocationInput = input == null ? "" : input;
        state.chain = chain;
        state.startedAt = Instant.now().toString();
        state.updatedAt = state.startedAt;
        state.steps = steps == null ? new ArrayList<>() : steps;
        state.verify = verify == null ? new ArrayList<>() : verify;
        return state;
    }

    public void save(RunState state) {
        if (state == null || state.runId == null) return;
        state.updatedAt = Instant.now().toString();
        try {
            Files.createDirectories(dir);
            Files.writeString(fileOf(state.runId), GSON.toJson(state), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.warn("保存 harness checkpoint 失败：{}", state.runId, e);
        }
    }

    public RunState load(String runId) {
        if (runId == null || runId.isBlank()) return null;
        Path file = fileOf(runId.trim());
        if (!Files.isRegularFile(file)) return null;
        try {
            return GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), RunState.class);
        } catch (Exception e) {
            log.warn("读取 harness checkpoint 失败：{}", runId, e);
            return null;
        }
    }

    /** 最近的运行记录（按 updatedAt 倒序）。 */
    public List<RunState> recent(int limit) {
        List<RunState> runs = new ArrayList<>();
        if (!Files.isDirectory(dir)) return runs;
        try (var stream = Files.list(dir)) {
            stream.filter(p -> p.getFileName().toString().endsWith(".json")).forEach(p -> {
                try {
                    RunState state = GSON.fromJson(Files.readString(p, StandardCharsets.UTF_8), RunState.class);
                    if (state != null && state.runId != null) runs.add(state);
                } catch (Exception ignored) {
                }
            });
        } catch (Exception e) {
            log.warn("读取 harness checkpoint 目录失败：{}", dir, e);
            return runs;
        }
        runs.sort(Comparator.comparing((RunState s) -> s.updatedAt == null ? "" : s.updatedAt).reversed());
        return runs.size() <= limit ? runs : new ArrayList<>(runs.subList(0, limit));
    }

    private Path fileOf(String runId) {
        String safe = runId.replaceAll("[^a-zA-Z0-9._-]", "_");
        return dir.resolve(safe + ".json");
    }
}
