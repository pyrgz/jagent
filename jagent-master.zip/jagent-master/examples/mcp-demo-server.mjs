#!/usr/bin/env node
/**
 * 最小可用的 MCP Server 示例（stdio 传输，无第三方依赖）。
 * 用法：node examples/mcp-demo-server.mjs
 *
 * 提供 3 个工具：
 *   - now        获取当前时间
 *   - echo       原样返回输入文本
 *   - roll_dice  掷骰子（默认 6 面）
 */
import readline from 'node:readline';

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });

const send = (obj) => process.stdout.write(JSON.stringify(obj) + '\n');
const ok = (id, result) => send({ jsonrpc: '2.0', id, result });
const fail = (id, code, message) => send({ jsonrpc: '2.0', id, error: { code, message } });

const tools = [
  {
    name: 'now',
    description: '获取当前日期和时间',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'echo',
    description: '原样返回输入的文本',
    inputSchema: {
      type: 'object',
      properties: { text: { type: 'string', description: '要返回的文本' } },
      required: ['text'],
    },
  },
  {
    name: 'roll_dice',
    description: '掷骰子并返回点数',
    inputSchema: {
      type: 'object',
      properties: { sides: { type: 'integer', description: '骰子面数，默认 6' } },
    },
  },
];

rl.on('line', (line) => {
  if (!line.trim()) return;
  let msg;
  try {
    msg = JSON.parse(line);
  } catch {
    return;
  }
  if (msg.id === undefined) return; // 通知消息无需响应

  const { id, method, params } = msg;
  switch (method) {
    case 'initialize':
      ok(id, {
        protocolVersion: params?.protocolVersion || '2025-06-18',
        capabilities: { tools: {} },
        serverInfo: { name: 'jagent-demo-mcp', version: '1.0.0' },
      });
      break;

    case 'tools/list':
      ok(id, { tools });
      break;

    case 'tools/call': {
      const name = params?.name;
      const args = params?.arguments || {};
      if (name === 'now') {
        ok(id, { content: [{ type: 'text', text: new Date().toString() }] });
      } else if (name === 'echo') {
        ok(id, { content: [{ type: 'text', text: String(args.text ?? '') }] });
      } else if (name === 'roll_dice') {
        const sides = Number(args.sides) > 1 ? Number(args.sides) : 6;
        ok(id, { content: [{ type: 'text', text: String(1 + Math.floor(Math.random() * sides)) }] });
      } else {
        fail(id, -32602, `未知工具：${name}`);
      }
      break;
    }

    case 'ping':
      ok(id, {});
      break;

    default:
      fail(id, -32601, `未知方法：${method}`);
  }
});
